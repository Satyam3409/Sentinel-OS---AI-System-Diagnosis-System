"""Isolation Forest anomaly detection for system resource behaviour.

Design notes
------------
*   The engine is trained on a **clearly labelled synthetic baseline** of healthy
    desktop workloads so that anomaly detection works from the very first second
    the application runs (cold-start handling).
*   Once enough real samples have been collected it is re-trained on the real
    history, blended with the synthetic baseline so that the model keeps a
    notion of "normal" that is broader than the current session.
*   Until a model exists, a rule-based / z-score detector provides coverage.
*   An anomaly is *never* presented as proof of malware - only as unusual
    resource behaviour that deserves inspection.
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import numpy as np
from sklearn.ensemble import IsolationForest

from app import config

FEATURES = [
    "cpu_percent",
    "memory_percent",
    "swap_percent",
    "disk_read_mb_s",
    "disk_write_mb_s",
    "process_count",
    "cpu_delta",
]

FEATURE_UNITS = {
    "cpu_percent": "%",
    "memory_percent": "%",
    "swap_percent": "%",
    "disk_read_mb_s": "MB/s",
    "disk_write_mb_s": "MB/s",
    "process_count": "count",
    "cpu_delta": "%",
}

# Human readable metric label per feature
FEATURE_LABELS = {
    "cpu_percent": "CPU utilisation",
    "memory_percent": "Memory utilisation",
    "swap_percent": "Swap utilisation",
    "disk_read_mb_s": "Disk read throughput",
    "disk_write_mb_s": "Disk write throughput",
    "process_count": "Process count",
    "cpu_delta": "CPU change rate",
}

SENSITIVITY_TO_CONTAMINATION = {
    # sensitivity -> contamination (higher sensitivity = more alerts)
    0.0: 0.01,
    0.25: 0.03,
    0.5: 0.06,
    0.75: 0.10,
    1.0: 0.15,
}

# 0.5 is the neutral default and maps to the 0.06 contamination rate above.
DEFAULT_SENSITIVITY = 0.5


def contamination_for_sensitivity(sensitivity: float) -> float:
    """Linearly interpolate the sensitivity -> contamination curve.

    The curve is deliberately non-linear in effect: a small sensitivity change
    near the top produces a much smaller alert-rate change than the same change
    near the bottom, which keeps the detector usable across the whole slider.
    """
    points = sorted(SENSITIVITY_TO_CONTAMINATION.items())
    value = float(np.clip(sensitivity, 0.0, 1.0))
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if value <= x1:
            span = (x1 - x0) or 1.0
            return float(y0 + (y1 - y0) * (value - x0) / span)
    return float(points[-1][1])


def sample_to_features(sample: dict[str, Any], previous: Optional[dict[str, Any]] = None) -> dict[str, float]:
    cpu = float(sample.get("cpu_percent", 0.0))
    prev_cpu = float(previous.get("cpu_percent", cpu)) if previous else cpu
    return {
        "cpu_percent": cpu,
        "memory_percent": float(sample.get("memory_percent", 0.0)),
        "swap_percent": float(sample.get("swap_percent", 0.0)),
        "disk_read_mb_s": float(sample.get("disk_read_mb_s", 0.0)),
        "disk_write_mb_s": float(sample.get("disk_write_mb_s", 0.0)),
        "process_count": float(sample.get("process_count", 0)),
        "cpu_delta": abs(cpu - prev_cpu),
    }


def synthetic_baseline(n: int = 1200, seed: int = 42) -> np.ndarray:
    """Synthetic *healthy desktop* workload used for cold-start training.

    This data is generated, not measured. It is labelled as synthetic everywhere
    it is surfaced in the API and UI.
    """
    rng = np.random.default_rng(seed)
    cpu = np.clip(rng.normal(18, 9, n) + rng.exponential(5, n), 1, 98)
    memory = np.clip(rng.normal(48, 10, n), 12, 95)
    swap = np.clip(rng.normal(6, 5, n) + np.maximum(memory - 75, 0) * 0.9, 0, 95)
    disk_read = np.clip(rng.exponential(1.6, n), 0, 60)
    disk_write = np.clip(rng.exponential(2.1, n), 0, 60)
    processes = np.clip(rng.normal(210, 45, n), 60, 600)
    cpu_delta = np.clip(np.abs(rng.normal(6, 5, n)), 0, 70)
    return np.column_stack([cpu, memory, swap, disk_read, disk_write, processes, cpu_delta])


class AnomalyEngine:
    """Thread-safe Isolation Forest wrapper with persistence and inference."""

    def __init__(self, model_path: Optional[Path] = None) -> None:
        self.model_path = Path(model_path or config.MODEL_PATH)
        self._lock = threading.RLock()
        self.model: Optional[IsolationForest] = None
        self._feature_means: dict[str, float] = {}
        self._feature_stds: dict[str, float] = {}
        self._p1: dict[str, float] = {}
        self._p99: dict[str, float] = {}
        self.trained_samples = 0
        self.trained_at: Optional[str] = None
        self.training_source = "untrained"
        self.sensitivity: float = DEFAULT_SENSITIVITY
        self.enabled: bool = config.ML_ENABLED
        self.last_score: Optional[float] = None
        self.last_severity: Optional[str] = None
        self.last_is_anomaly: bool = False
        self.last_features: dict[str, float] = {}
        self._previous_sample: Optional[dict[str, Any]] = None
        self._last_real_training_size = 0

    # -- helpers -----------------------------------------------------------
    @property
    def contamination(self) -> float:
        return contamination_for_sensitivity(self.sensitivity)

    @property
    def model_ready(self) -> bool:
        return self.model is not None

    def set_sensitivity(self, sensitivity: float) -> None:
        with self._lock:
            self.sensitivity = float(np.clip(sensitivity, 0.0, 1.0))

    def mode(self) -> str:
        if not self.enabled:
            return "disabled"
        if self.model_ready:
            return "unsupervised-learning"
        return "rule-based-cold-start"

    # -- training ----------------------------------------------------------
    def train(self, data: np.ndarray, source: str, persist: bool = True) -> dict[str, Any]:
        if data.ndim != 2 or data.shape[1] != len(FEATURES):
            raise ValueError(f"expected 2-D array with {len(FEATURES)} features, got {data.shape}")
        if len(data) < 10:
            raise ValueError("need at least 10 samples to train")
        with self._lock:
            model = IsolationForest(
                n_estimators=160,
                max_samples=min(512, len(data)),
                contamination=self.contamination,
                random_state=42,
                n_jobs=1,
            )
            model.fit(data)
            self.model = model
            self._feature_means = {f: float(np.mean(data[:, i])) for i, f in enumerate(FEATURES)}
            self._feature_stds = {
                f: float(np.std(data[:, i]) or 1.0) for i, f in enumerate(FEATURES)
            }
            self._p1 = {f: float(np.percentile(data[:, i], 1)) for i, f in enumerate(FEATURES)}
            self._p99 = {f: float(np.percentile(data[:, i], 99)) for i, f in enumerate(FEATURES)}
            self.trained_samples = int(len(data))
            self.trained_at = datetime.now().isoformat(timespec="seconds")
            self.training_source = source
        if persist:
            self.save()
        return {
            "trained_samples": self.trained_samples,
            "trained_at": self.trained_at,
            "training_source": self.training_source,
            "contamination": self.contamination,
        }

    def train_cold_start(self) -> dict[str, Any]:
        """Train on the synthetic healthy baseline (works with zero real data)."""
        data = synthetic_baseline()
        return self.train(data, source="synthetic-healthy-baseline", persist=True)

    def maybe_retrain(self, samples: list[dict[str, Any]], min_samples: Optional[int] = None) -> bool:
        """Blend real history with the synthetic baseline once enough data exists."""
        min_samples = min_samples or config.ML_MIN_TRAIN_SAMPLES
        if len(samples) < min_samples:
            return False
        if len(samples) - self._last_real_training_size < max(20, min_samples // 3):
            return False
        real = self._samples_to_matrix(samples)
        baseline = synthetic_baseline(n=max(400, len(real)))
        blended = np.vstack([baseline, real])
        try:
            self.train(blended, source="synthetic-baseline+real-history", persist=True)
        except ValueError:
            return False
        self._last_real_training_size = len(samples)
        return True

    @staticmethod
    def _samples_to_matrix(samples: list[dict[str, Any]]) -> np.ndarray:
        rows = []
        prev: Optional[dict[str, Any]] = None
        for s in samples:
            feat = sample_to_features(s, prev)
            rows.append([feat[f] for f in FEATURES])
            prev = s
        return np.asarray(rows, dtype=float)

    # -- persistence -------------------------------------------------------
    def save(self) -> None:
        if self.model is None:
            return
        try:
            import joblib

            payload = {
                "model": self.model,
                "means": self._feature_means,
                "stds": self._feature_stds,
                "p1": self._p1,
                "p99": self._p99,
                "trained_samples": self.trained_samples,
                "trained_at": self.trained_at,
                "training_source": self.training_source,
                "features": FEATURES,
            }
            self.model_path.parent.mkdir(parents=True, exist_ok=True)
            joblib.dump(payload, self.model_path)
        except Exception:
            # Persistence is best-effort; inference continues in memory.
            pass

    def load(self) -> bool:
        if not self.model_path.exists():
            return False
        try:
            import joblib

            payload = joblib.load(self.model_path)
            if payload.get("features") != FEATURES:
                return False
            with self._lock:
                self.model = payload["model"]
                self._feature_means = payload.get("means", {})
                self._feature_stds = payload.get("stds", {})
                self._p1 = payload.get("p1", {})
                self._p99 = payload.get("p99", {})
                self.trained_samples = payload.get("trained_samples", 0)
                self.trained_at = payload.get("trained_at")
                self.training_source = payload.get("training_source", "persisted-model")
            return True
        except Exception:
            return False

    # -- inference ---------------------------------------------------------
    def evaluate(self, sample: dict[str, Any]) -> dict[str, Any]:
        """Score a single metric sample and describe any unusual behaviour."""
        features = sample_to_features(sample, self._previous_sample)
        self._previous_sample = sample
        self.last_features = features

        if not self.enabled:
            return self._disabled_result(features)

        if self.model_ready:
            result = self._model_result(features)
        else:
            result = self._rule_based_result(features)

        self.last_score = result["score"]
        self.last_severity = result["severity"]
        self.last_is_anomaly = result["is_anomaly"]
        return result

    def _disabled_result(self, features: dict[str, float]) -> dict[str, Any]:
        return {
            "timestamp": time.time(),
            "detected_at": datetime.now().isoformat(timespec="seconds"),
            "is_anomaly": False,
            "score": 0.0,
            "severity": "info",
            "metric": "cpu_percent",
            "observed_value": features["cpu_percent"],
            "expected_range": [0.0, 100.0],
            "evidence": "Anomaly detection is disabled in settings.",
            "explanation": "Enable ML anomaly detection to score live resource behaviour.",
            "model": "disabled",
            "features": features,
        }

    def _model_result(self, features: dict[str, float]) -> dict[str, Any]:
        assert self.model is not None
        vector = np.asarray([[features[f] for f in FEATURES]], dtype=float)
        raw = float(self.model.decision_function(vector)[0])
        label = int(self.model.predict(vector)[0])  # -1 == anomaly
        # Map decision_function (~[-0.5, 0.5]) to a 0..1 anomaly score
        score = float(np.clip(0.5 - raw, 0.0, 1.0))
        is_anomaly = label == -1

        # Which feature deviates the most from the learned distribution?
        deviations = {}
        for f in FEATURES:
            std = self._feature_stds.get(f, 1.0) or 1.0
            deviations[f] = abs(features[f] - self._feature_means.get(f, 0.0)) / std
        top_feature = max(deviations, key=deviations.get) if deviations else "cpu_percent"
        severity = self._severity_from(score, is_anomaly, top_feature, features)

        low = self._p1.get(top_feature, 0.0)
        high = self._p99.get(top_feature, 100.0)
        observed = features[top_feature]
        direction = "above" if observed > high else ("below" if observed < low else "within")
        evidence = (
            f"{FEATURE_LABELS[top_feature]} observed at {observed:.2f}{FEATURE_UNITS[top_feature]}; "
            f"learned healthy 1st-99th percentile is {low:.2f}-{high:.2f}{FEATURE_UNITS[top_feature]} "
            f"({direction} the learned range). z-score deviation {deviations[top_feature]:.2f}."
        )
        return {
            "timestamp": time.time(),
            "detected_at": datetime.now().isoformat(timespec="seconds"),
            "is_anomaly": is_anomaly,
            "score": round(score, 4),
            "severity": severity,
            "metric": top_feature,
            "observed_value": round(float(observed), 3),
            "expected_range": [round(low, 3), round(high, 3)],
            "evidence": evidence,
            "explanation": self._explain(top_feature, is_anomaly, severity, direction),
            "model": f"IsolationForest(n_estimators=160, contamination={self.contamination:.3f})",
            "features": features,
        }

    def _rule_based_result(self, features: dict[str, float]) -> dict[str, Any]:
        """Cold-start detector: static engineering thresholds + change rate."""
        checks = [
            ("cpu_percent", 90.0, "critical", "CPU utilisation exceeded 90%"),
            ("memory_percent", 90.0, "critical", "Memory utilisation exceeded 90%"),
            ("swap_percent", 60.0, "high", "Swap utilisation exceeded 60% - memory pressure"),
            ("disk_write_mb_s", 120.0, "high", "Sustained disk write above 120 MB/s"),
            ("disk_read_mb_s", 120.0, "high", "Sustained disk read above 120 MB/s"),
            ("cpu_delta", 55.0, "medium", "Abrupt CPU change greater than 55 points between samples"),
        ]
        triggered = [
            (f, features.get(f, 0.0), threshold, sev, msg)
            for f, threshold, sev, msg in checks
            if features.get(f, 0.0) >= threshold
        ]
        if triggered:
            feature, value, threshold, sev, msg = max(triggered, key=lambda t: t[1] / max(t[2], 1.0))
            score = float(np.clip(value / max(threshold, 1.0) * 0.5, 0.0, 1.0))
            severity = self._bump(sev, self.sensitivity)
            evidence = (
                f"{msg}. Observed {value:.2f}{FEATURE_UNITS[feature]} "
                f"against the cold-start threshold of {threshold:.2f}{FEATURE_UNITS[feature]}."
            )
        else:
            feature, value, threshold, sev, severity = "cpu_percent", features.get("cpu_percent", 0.0), 90.0, "info", "info"
            score = float(np.clip(features.get("cpu_percent", 0.0) / 100.0 * 0.4, 0, 1))
            evidence = (
                "Rule-based cold-start detector active: all engineering thresholds satisfied "
                f"(CPU {features.get('cpu_percent', 0):.1f}%, memory {features.get('memory_percent', 0):.1f}%, "
                f"swap {features.get('swap_percent', 0):.1f}%)."
            )
        return {
            "timestamp": time.time(),
            "detected_at": datetime.now().isoformat(timespec="seconds"),
            "is_anomaly": bool(triggered),
            "score": round(score, 4),
            "severity": severity,
            "metric": feature,
            "observed_value": round(float(value), 3),
            "expected_range": [0.0, 90.0],
            "evidence": evidence,
            "explanation": self._explain(feature, bool(triggered), severity, "above"),
            "model": "rule-based-cold-start (IsolationForest not yet trained)",
            "features": features,
        }

    def _severity_from(self, score: float, is_anomaly: bool, feature: str, features: dict[str, float]) -> str:
        if not is_anomaly:
            return "info"
        severity = "low"
        if score >= 0.28:
            severity = "medium"
        if score >= 0.42:
            severity = "high"
        if score >= 0.58:
            severity = "critical"
        # Escalate when an absolute safety threshold is breached as well.
        if feature == "cpu_percent" and features[feature] >= 95:
            severity = "critical"
        elif feature == "memory_percent" and features[feature] >= 95:
            severity = "critical"
        return self._bump(severity, self.sensitivity)

    @staticmethod
    def _bump(severity: str, sensitivity: float) -> str:
        order = ["info", "low", "medium", "high", "critical"]
        idx = order.index(severity) if severity in order else 0
        # Low sensitivity pushes severity down, high sensitivity pushes it up.
        if sensitivity >= 0.75 and idx < len(order) - 1:
            idx += 1
        elif sensitivity <= 0.25 and idx > 0:
            idx -= 1
        return order[idx]

    @staticmethod
    def _explain(feature: str, is_anomaly: bool, severity: str, direction: str) -> str:
        label = FEATURE_LABELS.get(feature, feature)
        if not is_anomaly:
            return (
                f"{label} is consistent with the learned healthy pattern for this machine. "
                "No action required."
            )
        base = (
            f"{label} is statistically unusual ({direction} the learned healthy distribution) "
            f"and was classified as a {severity} deviation."
        )
        guidance = {
            "cpu_percent": " Sustained high CPU usually means a foreground application, indexing job, or background service is competing for processor time. Inspect the Process Explorer sorted by CPU.",
            "memory_percent": " High memory usage suggests accumulation by running applications or a large workload. Inspect Process Explorer sorted by memory and check for steadily growing processes (possible leak pattern).",
            "swap_percent": " Swap activity rises when physical memory is exhausted. This directly degrades responsiveness because paging happens on disk.",
            "disk_read_mb_s": " Elevation in disk reads can indicate background scanning, indexing, or a large file operation.",
            "disk_write_mb_s": " Elevation in disk writes can indicate logging, backup, caching, or an application writing excessively.",
            "process_count": " A jump in process count can indicate a launcher spawning child processes, a script loop, or an application starting many worker threads/processes.",
            "cpu_delta": " A very abrupt CPU change between two samples indicates a sudden workload start or stop, which is worth correlating with your own activity.",
        }
        return base + guidance.get(feature, "") + (
            " This is a statistical observation about resource behaviour - it is not evidence of malware."
        )

    # -- status ------------------------------------------------------------
    def status(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "model_ready": self.model_ready,
            "mode": self.mode(),
            "trained_samples": self.trained_samples,
            "trained_at": self.trained_at,
            "training_source": self.training_source,
            "sensitivity": round(float(self.sensitivity), 3),
            "contamination": round(self.contamination, 3),
            "last_score": round(float(self.last_score), 4) if self.last_score is not None else None,
            "last_severity": self.last_severity,
            "is_anomaly": self.last_is_anomaly,
            "recent_events": [],
        }

    def export_state(self) -> str:
        return json.dumps(self.status(), indent=2)


anomaly_engine = AnomalyEngine()

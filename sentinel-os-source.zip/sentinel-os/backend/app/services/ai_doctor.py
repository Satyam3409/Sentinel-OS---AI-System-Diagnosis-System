"""SENTINEL AI DOCTOR - Google Gemini integration with a local rule-based fallback.

Guarantees
----------
*   The API key is read only from the backend environment (`GEMINI_API_KEY`).
    It is never sent to or referenced by frontend code.
*   The model is always given *measured* structured metrics; it is explicitly
    forbidden from inventing numbers.
*   The model's JSON is validated and repaired before being returned.
*   Any failure (missing key, timeout, network error, invalid payload, refusal)
    falls back to a local deterministic diagnostic engine, so the AI Doctor
    always answers - even fully offline.
"""

from __future__ import annotations

import json
import re
import time
from datetime import datetime
from typing import Any, Optional

import httpx

from app import config
from app.services.monitor import monitor
from app.services.processes import top_processes
from app.services.recommendations import build_recommendations

SYSTEM_INSTRUCTION = """You are SENTINEL AI DOCTOR, the diagnostic assistant inside a Windows system \
monitoring product called SENTINEL OS.

Rules you must never break:
1. Only use the numeric measurements provided in the SYSTEM TELEMETRY block. Never invent, estimate, \
round-up, or extrapolate a measurement that was not given to you.
2. If a value is missing or reported as unavailable, say it is unavailable instead of guessing.
3. You are not permitted to claim that an anomaly proves malware, a virus, or an intrusion. Describe \
resource behaviour only, and treat unusual behaviour as something to inspect.
4. Never instruct the user to run shell commands, delete files, edit the registry, disable antivirus, \
or terminate processes automatically. Recommendations must be read-only and reversible by the user.
5. Refer to processes by the names and PIDs that appear in the telemetry.

Respond with a single JSON object and nothing else, using exactly this schema:
{
  "summary": "2-4 sentence plain-language diagnosis referencing measured values",
  "evidence": ["specific measured observation", "..."],
  "possible_causes": ["cause", "..."],
  "confidence": 0.0,
  "recommended_actions": ["read-only action the user can take", "..."],
  "safety_considerations": ["what could go wrong / what not to do", "..."]
}
"confidence" is a number between 0 and 1 reflecting how strongly the measured evidence supports the \
diagnosis."""


def _collect_telemetry(include_history: bool = True) -> dict[str, Any]:
    snapshot = monitor.snapshot_for_analysis()
    try:
        cpu_hogs = top_processes(limit=5, by="cpu")
    except Exception:
        cpu_hogs = []
    try:
        mem_hogs = top_processes(limit=5, by="memory")
    except Exception:
        mem_hogs = []
    telemetry: dict[str, Any] = {
        "captured_at": snapshot["timestamp"],
        "cpu": {
            "utilization_percent": snapshot["cpu_percent"],
            "per_core_percent": snapshot["cpu_per_core"],
            "frequency_mhz": snapshot["cpu_frequency_mhz"],
        },
        "memory": {
            "utilization_percent": snapshot["memory_percent"],
            "used_mb": snapshot["memory_used_mb"],
            "total_mb": snapshot["memory_total_mb"],
            "available_mb": snapshot["memory_available_mb"],
            "swap_used_mb": snapshot["swap_used_mb"],
            "swap_percent": snapshot["swap_percent"],
        },
        "disk": {
            "read_mb_s": snapshot["disk_read_mb_s"],
            "write_mb_s": snapshot["disk_write_mb_s"],
            "partitions": snapshot["disk_partitions"],
        },
        "network": {
            "upload_kb_s": snapshot["net_upload_kb_s"],
            "download_kb_s": snapshot["net_download_kb_s"],
        },
        "processes": {
            "count": snapshot["process_count"],
            "top_cpu": [
                {"pid": p["pid"], "name": p["name"], "cpu_percent": p["cpu_percent"]} for p in cpu_hogs
            ],
            "top_memory": [
                {"pid": p["pid"], "name": p["name"], "memory_mb": p["memory_mb"]} for p in mem_hogs
            ],
        },
        "collection_warnings": snapshot.get("data_warnings", []),
    }
    if include_history:
        history = monitor.get_history(limit=30)
        points = history.get("points", [])
        if points:
            cpu_values = [p["cpu_percent"] for p in points]
            mem_values = [p["memory_percent"] for p in points]
            telemetry["recent_trend"] = {
                "window_samples": len(points),
                "sample_interval_seconds": monitor.sample_interval,
                "cpu": {
                    "min": round(min(cpu_values), 2),
                    "max": round(max(cpu_values), 2),
                    "avg": round(sum(cpu_values) / len(cpu_values), 2),
                    "last": round(cpu_values[-1], 2),
                },
                "memory": {
                    "min": round(min(mem_values), 2),
                    "max": round(max(mem_values), 2),
                    "avg": round(sum(mem_values) / len(mem_values), 2),
                    "last": round(mem_values[-1], 2),
                },
            }
    return telemetry


def _format_telemetry_block(telemetry: dict[str, Any], metrics: dict[str, Any] | None = None) -> str:
    if metrics is None:
        metrics = monitor.snapshot_for_analysis()
    lines = [
        "SYSTEM TELEMETRY (measured - the only numbers you may use):",
        f"- Captured at: {telemetry['captured_at']}",
        f"- CPU utilisation: {telemetry['cpu']['utilization_percent']}%",
        f"- CPU per-core: {telemetry['cpu']['per_core_percent']}",
        f"- CPU frequency: {telemetry['cpu']['frequency_mhz']} MHz",
        f"- Memory: {telemetry['memory']['utilization_percent']}% "
        f"({telemetry['memory']['used_mb']} MB used of {telemetry['memory']['total_mb']} MB, "
        f"{telemetry['memory']['available_mb']} MB available)",
        f"- Swap: {telemetry['memory']['swap_percent']}% ({telemetry['memory']['swap_used_mb']} MB)",
        f"- Disk read: {telemetry['disk']['read_mb_s']} MB/s, write: {telemetry['disk']['write_mb_s']} MB/s",
    ]
    for part in telemetry["disk"]["partitions"]:
        lines.append(
            f"- Partition {part['mountpoint']} ({part['device']}): {part['used_gb']} GB used of "
            f"{part['total_gb']} GB ({part['percent']}%), {part['free_gb']} GB free"
        )
    lines += [
        f"- Network: {telemetry['network']['upload_kb_s']} KB/s up, "
        f"{telemetry['network']['download_kb_s']} KB/s down",
        f"- Process count: {telemetry['processes']['count']}",
        "- Top processes by CPU: "
        + (", ".join(f"{p['name']} (PID {p['pid']}) {p['cpu_percent']}%" for p in telemetry["processes"]["top_cpu"]) or "unavailable"),
        "- Top processes by memory: "
        + (", ".join(f"{p['name']} (PID {p['pid']}) {p['memory_mb']} MB" for p in telemetry["processes"]["top_memory"]) or "unavailable"),
    ]
    trend = telemetry.get("recent_trend")
    if trend:
        lines.append(
            f"- Recent trend over {trend['window_samples']} samples "
            f"({trend['sample_interval_seconds']}s apart): "
            f"CPU min {trend['cpu']['min']}% / avg {trend['cpu']['avg']}% / max {trend['cpu']['max']}%; "
            f"memory min {trend['memory']['min']}% / avg {trend['memory']['avg']}% / max {trend['memory']['max']}%"
        )
    if telemetry.get("collection_warnings"):
        lines.append(f"- Metric collection warnings: {telemetry['collection_warnings']}")

    recommendations = build_recommendations()
    if recommendations["items"]:
        lines.append("")
        lines.append("RULE-BASED FINDINGS already computed by SENTINEL (use and cite these):")
        for item in recommendations["items"][:6]:
            lines.append(f"- [{item['severity']}] {item['trigger']} :: {item['evidence']}")

    if metrics.get("anomaly"):
        anomaly = metrics["anomaly"]
        lines.append("")
        lines.append(
            f"ANOMALY ENGINE: mode={anomaly.get('mode')}, is_anomaly={anomaly.get('is_anomaly')}, "
            f"severity={anomaly.get('last_severity')}, score={anomaly.get('last_score')}"
        )
    return "\n".join(lines)


def _extract_json(text: str) -> Optional[dict[str, Any]]:
    """Parse model output into JSON, tolerating markdown fences and prose."""
    if not text:
        return None
    cleaned = text.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", cleaned, re.DOTALL)
    if fence:
        cleaned = fence.group(1).strip()
    try:
        parsed = json.loads(cleaned)
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        pass
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end > start:
        try:
            parsed = json.loads(cleaned[start : end + 1])
            return parsed if isinstance(parsed, dict) else None
        except json.JSONDecodeError:
            return None
    return None


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, (list, tuple)):
        out = []
        for item in value:
            if isinstance(item, str) and item.strip():
                out.append(item.strip())
            elif isinstance(item, dict):
                out.append(json.dumps(item, ensure_ascii=False))
            elif item is not None:
                out.append(str(item))
        return out
    return [str(value)]


def _validate_report(payload: dict[str, Any], question: str, telemetry: dict[str, Any]) -> dict[str, Any]:
    """Validate/repair the model's structured answer."""
    summary = payload.get("summary")
    if not isinstance(summary, str) or not summary.strip():
        summary = "The model returned an incomplete diagnosis; see the evidence section for measured values."
    try:
        confidence = float(payload.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))

    evidence = _as_list(payload.get("evidence"))
    if not evidence:
        evidence = [
            f"CPU utilisation measured at {telemetry['cpu']['utilization_percent']}%",
            f"Memory utilisation measured at {telemetry['memory']['utilization_percent']}% "
            f"({telemetry['memory']['available_mb']} MB available)",
        ]
    causes = _as_list(payload.get("possible_causes")) or [
        "Insufficient structured output from the model to attribute a cause."
    ]
    actions = _as_list(payload.get("recommended_actions")) or [
        "Review the Process Explorer sorted by CPU and memory to identify the dominant workload."
    ]
    safety = _as_list(payload.get("safety_considerations")) or [
        "SENTINEL OS performs read-only analysis. Nothing is terminated, deleted, or modified automatically."
    ]
    return {
        "summary": summary.strip(),
        "evidence": evidence,
        "possible_causes": causes,
        "confidence": round(confidence, 2),
        "recommended_actions": actions,
        "safety_considerations": safety,
    }


# --- local fallback ---------------------------------------------------------

def local_diagnostic(question: str, telemetry: dict[str, Any], reason: str = "") -> dict[str, Any]:
    """Deterministic rule-based diagnostic used when Gemini is unavailable."""
    cpu = telemetry["cpu"]["utilization_percent"]
    mem = telemetry["memory"]
    disk = telemetry["disk"]
    net = telemetry["network"]
    procs = telemetry["processes"]
    trend = telemetry.get("recent_trend")
    recommendations = build_recommendations()
    q = question.lower()

    evidence: list[str] = [
        f"CPU utilisation measured at {cpu}% ({len(telemetry['cpu']['per_core_percent'])} logical cores reported)",
        f"Memory utilisation measured at {mem['utilization_percent']}% - "
        f"{mem['used_mb']} MB used of {mem['total_mb']} MB, {mem['available_mb']} MB available",
        f"Swap utilisation measured at {mem['swap_percent']}% ({mem['swap_used_mb']} MB)",
        f"Disk throughput measured at {disk['read_mb_s']} MB/s read and {disk['write_mb_s']} MB/s write",
        f"Process table contains {procs['count']} processes",
    ]
    if procs["top_cpu"]:
        evidence.append(
            "Top CPU consumers measured: "
            + ", ".join(f"{p['name']} (PID {p['pid']}) {p['cpu_percent']}%" for p in procs["top_cpu"][:3])
        )
    if procs["top_memory"]:
        evidence.append(
            "Top memory consumers measured: "
            + ", ".join(f"{p['name']} (PID {p['pid']}) {p['memory_mb']} MB" for p in procs["top_memory"][:3])
        )
    if trend:
        evidence.append(
            f"CPU over the last {trend['window_samples']} samples averaged {trend['cpu']['avg']}% "
            f"(max {trend['cpu']['max']}%); memory averaged {trend['memory']['avg']}% (max {trend['memory']['max']}%)"
        )
    for part in disk["partitions"]:
        if part["percent"] >= 80:
            evidence.append(
                f"Partition {part['mountpoint']} is {part['percent']}% full with only {part['free_gb']} GB free"
            )

    causes: list[str] = []
    if cpu >= 70:
        causes.append(
            "CPU contention: foreground or background workloads are competing for processor time "
            f"(measured utilisation {cpu}%)."
        )
    if mem["utilization_percent"] >= 75:
        causes.append(
            f"Memory pressure: physical memory is {mem['utilization_percent']}% used, leaving "
            f"{mem['available_mb']} MB available, which pushes the system towards paging."
        )
    if mem["swap_percent"] >= 35:
        causes.append(
            f"Active paging: swap is {mem['swap_percent']}% used, indicating the working set exceeds RAM."
        )
    if disk["write_mb_s"] >= 60 or disk["read_mb_s"] >= 60:
        causes.append("Heavy disk I/O: storage is busy, which increases latency for unrelated operations.")
    for part in disk["partitions"]:
        if part["percent"] >= 85:
            causes.append(
                f"Storage saturation on {part['mountpoint']} ({part['percent']}% full) limiting cache and page-file growth."
            )
    if procs["count"] > 350:
        causes.append(f"High process count ({procs['count']}) adds scheduling and bookkeeping overhead.")
    if not causes:
        causes.append(
            "No dominant bottleneck was identified from the measured values; resource utilisation is within "
            "nominal desktop ranges for every monitored subsystem."
        )

    actions: list[str] = []
    if "ram" in q or "memory" in q:
        actions.append("Sort Process Explorer by memory and review the largest consumers listed above.")
    if "cpu" in q:
        actions.append("Sort Process Explorer by CPU and confirm the top consumer matches work you started.")
    if "slow" in q or "performance" in q or not actions:
        actions.append("Correlate the peak times in Live Monitor with the applications you were using.")
    actions.append("Re-run this diagnosis while the problem is occurring so the comparison uses live values.")
    actions.append("Use the Performance Lab to measure a bounded workload and observe recovery afterwards.")
    if cpu >= 70:
        actions.append("Close applications you are not using to reduce CPU contention.")
    if mem["utilization_percent"] >= 75:
        actions.append("Close unused memory-heavy applications, then re-measure available memory.")
    for part in disk["partitions"]:
        if part["percent"] >= 85:
            actions.append(
                f"Investigate files on {part['mountpoint']} using Windows Storage Settings and remove "
                "only files you own that you no longer need."
            )

    confidence = 0.55
    if recommendations["items"]:
        confidence = min(0.85, 0.55 + 0.05 * len(recommendations["items"]))
    if not telemetry["cpu"]["per_core_percent"]:
        confidence -= 0.1

    if cpu >= 85 or mem["utilization_percent"] >= 90:
        headline = "Significant resource saturation detected"
    elif cpu >= 60 or mem["utilization_percent"] >= 70:
        headline = "Moderate resource pressure detected"
    else:
        headline = "No significant resource bottleneck detected"

    summary = (
        f"{headline}. Measured CPU utilisation is {cpu}%, memory utilisation is "
        f"{mem['utilization_percent']}% with {mem['available_mb']} MB available, and swap is "
        f"{mem['swap_percent']}% used. "
    )
    if cpu >= 70 or mem["utilization_percent"] >= 75:
        summary += (
            "The dominant measured constraint is "
            + ("processor contention" if cpu >= mem["utilization_percent"] else "memory pressure")
            + ", which is the most likely explanation for the reported symptom."
        )
    else:
        summary += (
            "All monitored subsystems are within nominal desktop ranges, so the reported symptom is not "
            "explained by system-wide resource saturation. Consider application-specific causes."
        )
    if reason:
        summary += f" (Generated by the offline rule-based engine: {reason}.)"

    return {
        "summary": summary,
        "evidence": evidence,
        "possible_causes": causes,
        "confidence": round(max(0.0, min(1.0, confidence)), 2),
        "recommended_actions": actions,
        "safety_considerations": [
            "SENTINEL OS analysis is read-only: it never terminates processes, deletes files, edits the "
            "registry, or changes system configuration.",
            "Never terminate a process you cannot identify - system services and drivers can cause instability.",
            "An anomalous resource pattern is a statistical observation about behaviour, not proof of malware. "
            "Use an up-to-date antivirus product for security verdicts.",
            "Long uptimes and high utilisation can also be legitimate: verify against the work you were doing.",
        ],
    }


# --- Gemini -----------------------------------------------------------------

async def call_gemini(question: str, telemetry: dict[str, Any], timeout: Optional[float] = None) -> dict[str, Any]:
    """Call the Gemini generateContent REST endpoint. Raises on failure."""
    if not config.gemini_configured():
        raise RuntimeError("GEMINI_API_KEY is not configured on the backend")

    telemetry_block = _format_telemetry_block(telemetry)
    prompt = f"{telemetry_block}\n\nUSER QUESTION: {question}\n\nReturn only the JSON object."
    url = f"{config.GEMINI_BASE_URL}/models/{config.GEMINI_MODEL}:generateContent"
    payload = {
        "system_instruction": {"parts": [{"text": SYSTEM_INSTRUCTION}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.25,
            "topP": 0.9,
            "maxOutputTokens": 1400,
            "responseMimeType": "application/json",
        },
        "safetySettings": [
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"}
        ],
    }
    async with httpx.AsyncClient(timeout=timeout or config.GEMINI_TIMEOUT) as client:
        response = await client.post(
            url,
            json=payload,
            headers={
                "Content-Type": "application/json",
                "x-goog-api-key": config.GEMINI_API_KEY,
            },
        )
    if response.status_code >= 400:
        detail = response.text[:300]
        raise RuntimeError(f"Gemini API returned HTTP {response.status_code}: {detail}")

    data = response.json()
    candidates = data.get("candidates") or []
    if not candidates:
        blocked = (data.get("promptFeedback") or {}).get("blockReason")
        raise RuntimeError(f"Gemini returned no candidates (blockReason={blocked})")
    parts = (candidates[0].get("content") or {}).get("parts") or []
    text = "".join(part.get("text", "") for part in parts)
    parsed = _extract_json(text)
    if parsed is None:
        raise RuntimeError("Gemini response was not valid JSON")
    return _validate_report(parsed, question, telemetry)


async def diagnose(question: str, include_history: bool = True) -> dict[str, Any]:
    """Produce a diagnostic report, preferring Gemini and falling back locally."""
    started = time.perf_counter()
    telemetry = _collect_telemetry(include_history=include_history)
    notice: Optional[str] = None
    degraded = False

    if config.gemini_configured():
        try:
            report = await call_gemini(question, telemetry)
            engine = "gemini"
            model = config.GEMINI_MODEL
        except Exception as exc:
            degraded = True
            reason = f"Gemini unavailable ({type(exc).__name__}: {exc})"
            notice = reason
            report = local_diagnostic(question, telemetry, reason=reason)
            engine = "local-fallback"
            model = None
    else:
        degraded = True
        reason = "GEMINI_API_KEY not configured - using the local rule-based diagnostic engine"
        notice = reason
        report = local_diagnostic(question, telemetry, reason=reason)
        engine = "local-fallback"
        model = None

    latency_ms = round((time.perf_counter() - started) * 1000, 1)
    report.update(
        {
            "timestamp": time.time(),
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "engine": engine,
            "model": model,
            "question": question,
            "degraded": degraded,
            "notice": notice,
            "latency_ms": latency_ms,
        }
    )
    return report

"""Real Windows system monitoring built on psutil.

The monitor keeps an in-memory ring buffer of metric samples, computes
throughput deltas for disk/network, and produces a health report.

Every collector is defensive: on Windows some counters require elevated
privileges, so failures are captured and reported as *partial data* instead of
crashing the API.
"""

from __future__ import annotations

import platform
import socket
import sys
import threading
import time
from collections import deque
from datetime import datetime
from typing import Any, Optional

import psutil

from app import config


class MonitorError(RuntimeError):
    """Raised when a metric can genuinely not be collected."""


def _mb(value_bytes: float) -> float:
    return round(value_bytes / (1024 * 1024), 2)


def _gb(value_bytes: float) -> float:
    return round(value_bytes / (1024 * 1024 * 1024), 2)


def is_admin() -> bool:
    if platform.system() != "Windows":
        import os

        return hasattr(os, "geteuid") and os.geteuid() == 0
    try:
        import ctypes

        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


class SystemMonitor:
    """Collects, caches and serves real system metrics."""

    def __init__(self, sample_interval: Optional[float] = None) -> None:
        self.sample_interval = sample_interval or config.SAMPLE_INTERVAL
        self.history: deque[dict[str, Any]] = deque(maxlen=config.HISTORY_MAX_POINTS)
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._last_disk: Optional[Any] = None
        self._last_net: Optional[Any] = None
        self._last_sample_ts: float = 0.0
        self._process_count = 0
        self._warnings: set[str] = set()
        self._last_error: Optional[str] = None
        self.started_at: Optional[float] = None
        self.samples_collected = 0
        # Prime cpu_percent so the first real reading is meaningful.
        try:
            psutil.cpu_percent(interval=None, percpu=True)
            psutil.cpu_percent(interval=None)
        except Exception as exc:  # pragma: no cover - platform dependent
            self._warnings.add(f"cpu priming failed: {exc}")

    # -- lifecycle ---------------------------------------------------------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self.started_at = time.time()
        self._thread = threading.Thread(target=self._loop, name="sentinel-monitor", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.collect_sample()
            except Exception as exc:  # pragma: no cover - defensive
                self._last_error = str(exc)
            self._stop.wait(self.sample_interval)

    # -- collection --------------------------------------------------------
    def collect_sample(self) -> dict[str, Any]:
        """Collect one sample, append to history, and return it."""
        now = time.time()
        try:
            cpu = psutil.cpu_percent(interval=None)
        except Exception as exc:
            self._warnings.add(f"cpu_percent unavailable: {exc}")
            cpu = 0.0
        try:
            mem = psutil.virtual_memory()
            memory_percent = float(mem.percent)
        except Exception as exc:
            self._warnings.add(f"memory unavailable: {exc}")
            memory_percent = 0.0
        try:
            swap = psutil.swap_memory()
            swap_percent = float(swap.percent)
        except Exception as exc:
            self._warnings.add(f"swap unavailable: {exc}")
            swap_percent = 0.0

        disk = self._disk_rates()
        net = self._net_rates()
        try:
            self._process_count = len(psutil.pids())
        except Exception as exc:
            self._warnings.add(f"process enumeration failed: {exc}")

        sample = {
            "timestamp": now,
            "cpu_percent": round(float(cpu), 2),
            "memory_percent": round(memory_percent, 2),
            "swap_percent": round(swap_percent, 2),
            "disk_read_mb_s": disk["read_mb_s"],
            "disk_write_mb_s": disk["write_mb_s"],
            "net_upload_kb_s": net["upload_kb_s"],
            "net_download_kb_s": net["download_kb_s"],
            "process_count": self._process_count,
        }
        with self._lock:
            self.history.append(sample)
            self._last_sample_ts = now
            self.samples_collected += 1
        return sample

    def _disk_rates(self) -> dict[str, float]:
        out = {"read_mb_s": 0.0, "write_mb_s": 0.0, "read_mb_total": 0.0, "write_mb_total": 0.0}
        try:
            counters = psutil.disk_io_counters()
        except (psutil.AccessDenied, NotImplementedError, OSError) as exc:
            self._warnings.add(f"disk io counters unavailable: {exc}")
            return out
        except Exception as exc:  # pragma: no cover
            self._warnings.add(f"disk io counters error: {exc}")
            return out
        if counters is None:
            return out
        out["read_mb_total"] = _mb(counters.read_bytes)
        out["write_mb_total"] = _mb(counters.write_bytes)
        delta_t = time.time() - self._last_sample_ts if self._last_sample_ts else 0.0
        if self._last_disk is not None and delta_t > 0:
            read_delta = max(counters.read_bytes - self._last_disk.read_bytes, 0)
            write_delta = max(counters.write_bytes - self._last_disk.write_bytes, 0)
            out["read_mb_s"] = round(read_delta / (1024 * 1024) / delta_t, 3)
            out["write_mb_s"] = round(write_delta / (1024 * 1024) / delta_t, 3)
        self._last_disk = counters
        return out

    def _net_rates(self) -> dict[str, float]:
        out = {
            "upload_kb_s": 0.0,
            "download_kb_s": 0.0,
            "bytes_sent_mb": 0.0,
            "bytes_recv_mb": 0.0,
            "packets_sent": 0,
            "packets_recv": 0,
        }
        try:
            counters = psutil.net_io_counters()
        except (psutil.AccessDenied, NotImplementedError, OSError) as exc:
            self._warnings.add(f"network counters unavailable: {exc}")
            return out
        except Exception as exc:  # pragma: no cover
            self._warnings.add(f"network counters error: {exc}")
            return out
        if counters is None:
            return out
        out["bytes_sent_mb"] = _mb(counters.bytes_sent)
        out["bytes_recv_mb"] = _mb(counters.bytes_recv)
        out["packets_sent"] = int(counters.packets_sent)
        out["packets_recv"] = int(counters.packets_recv)
        delta_t = time.time() - self._last_sample_ts if self._last_sample_ts else 0.0
        if self._last_net is not None and delta_t > 0:
            sent_delta = max(counters.bytes_sent - self._last_net.bytes_sent, 0)
            recv_delta = max(counters.bytes_recv - self._last_net.bytes_recv, 0)
            out["upload_kb_s"] = round(sent_delta / 1024 / delta_t, 2)
            out["download_kb_s"] = round(recv_delta / 1024 / delta_t, 2)
        self._last_net = counters
        return out

    # -- read models -------------------------------------------------------
    def cpu_metrics(self) -> dict[str, Any]:
        try:
            per_core = [round(float(v), 2) for v in psutil.cpu_percent(interval=None, percpu=True)]
        except Exception as exc:
            self._warnings.add(f"per-core cpu unavailable: {exc}")
            per_core = []
        freq = None
        try:
            f = psutil.cpu_freq()
            if f:
                freq = round(float(f.current), 1)
        except Exception as exc:
            self._warnings.add(f"cpu frequency unavailable: {exc}")
        load = None
        try:
            if hasattr(psutil, "getloadavg"):
                load = [round(v, 2) for v in psutil.getloadavg()]
        except Exception:
            load = None
        return {
            "percent": round(float(psutil.cpu_percent(interval=None)), 2),
            "per_core": per_core,
            "core_count_logical": psutil.cpu_count(logical=True) or 0,
            "core_count_physical": psutil.cpu_count(logical=False) or 0,
            "frequency_mhz": freq,
            "load_avg": load,
        }

    def memory_metrics(self) -> dict[str, Any]:
        mem = psutil.virtual_memory()
        try:
            swap = psutil.swap_memory()
        except Exception as exc:
            self._warnings.add(f"swap unavailable: {exc}")
            swap = None
        return {
            "total_mb": _mb(mem.total),
            "used_mb": _mb(mem.total - mem.available),
            "available_mb": _mb(mem.available),
            "percent": round(float(mem.percent), 2),
            "swap_total_mb": _mb(swap.total) if swap else 0.0,
            "swap_used_mb": _mb(swap.used) if swap else 0.0,
            "swap_percent": round(float(swap.percent), 2) if swap else 0.0,
        }

    def disk_metrics(self) -> dict[str, Any]:
        rates = self._disk_rates()
        partitions: list[dict[str, Any]] = []
        try:
            for part in psutil.disk_partitions(all=False):
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                except (PermissionError, OSError):
                    # Removable / not-ready drives raise on Windows - skip them.
                    continue
                partitions.append(
                    {
                        "device": part.device,
                        "mountpoint": part.mountpoint,
                        "fstype": part.fstype or "unknown",
                        "total_gb": _gb(usage.total),
                        "used_gb": _gb(usage.used),
                        "free_gb": _gb(usage.free),
                        "percent": round(float(usage.percent), 2),
                    }
                )
        except Exception as exc:
            self._warnings.add(f"disk partitions unavailable: {exc}")
        return {**rates, "partitions": partitions}

    def network_metrics(self) -> dict[str, Any]:
        return self._net_rates()

    def system_info(self) -> dict[str, Any]:
        boot = psutil.boot_time()
        try:
            uname = platform.uname()
        except Exception:  # pragma: no cover
            uname = None
        return {
            "hostname": socket.gethostname(),
            "platform": platform.system(),
            "platform_release": getattr(uname, "release", platform.release()),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "processor": platform.processor() or "unknown",
            "python_version": sys.version.split()[0],
            "boot_time": boot,
            "uptime_seconds": round(time.time() - boot, 1),
            "user": psutil.Process().username() if hasattr(psutil, "Process") else "",
            "is_admin": is_admin(),
        }

    # -- aggregate ---------------------------------------------------------
    def health_report(
        self,
        cpu: dict[str, Any],
        memory: dict[str, Any],
        disk: dict[str, Any],
        processes: int,
    ) -> dict[str, Any]:
        score = 100
        reasons: list[str] = []
        if cpu["percent"] >= 90:
            score -= 30
            reasons.append(f"CPU utilisation critical at {cpu['percent']}%")
        elif cpu["percent"] >= 75:
            score -= 18
            reasons.append(f"CPU utilisation elevated at {cpu['percent']}%")
        elif cpu["percent"] >= 55:
            score -= 8
            reasons.append(f"CPU utilisation moderate at {cpu['percent']}%")

        if memory["percent"] >= 92:
            score -= 30
            reasons.append(f"Memory pressure critical at {memory['percent']}%")
        elif memory["percent"] >= 80:
            score -= 18
            reasons.append(f"Memory pressure elevated at {memory['percent']}%")
        elif memory["percent"] >= 65:
            score -= 8
            reasons.append(f"Memory usage moderate at {memory['percent']}%")

        if memory.get("swap_percent", 0) >= 50:
            score -= 12
            reasons.append(f"Swap in heavy use at {memory['swap_percent']}% - indicates memory pressure")

        for part in disk.get("partitions", []):
            if part["percent"] >= 92:
                score -= 12
                reasons.append(f"Disk {part['mountpoint']} almost full ({part['percent']}%)")
                break
            if part["percent"] >= 85:
                score -= 6
                reasons.append(f"Disk {part['mountpoint']} filling up ({part['percent']}%)")
                break

        if processes > 400:
            score -= 5
            reasons.append(f"High process count ({processes}) may indicate background bloat")

        score = max(0, min(100, score))
        if score >= 90:
            status = "optimal"
        elif score >= 75:
            status = "good"
        elif score >= 60:
            status = "fair"
        elif score >= 40:
            status = "degraded"
        else:
            status = "critical"
        if not reasons:
            reasons.append("All monitored subsystems are within nominal operating ranges")
        return {
            "score": score,
            "status": status,
            "reasons": reasons,
            "partial_data": bool(self._warnings),
        }

    def get_summary(self) -> dict[str, Any]:
        cpu = self.cpu_metrics()
        memory = self.memory_metrics()
        disk = self.disk_metrics()
        network = self.network_metrics()
        system = self.system_info()
        processes = self._process_count or len(psutil.pids())
        return {
            "source": "live",
            "timestamp": time.time(),
            "cpu": cpu,
            "memory": memory,
            "disk": disk,
            "network": network,
            "system": system,
            "process_count": processes,
            "health": self.health_report(cpu, memory, disk, processes),
        }

    def get_history(
        self,
        limit: int = 120,
        since: Optional[float] = None,
        metric: Optional[str] = None,
    ) -> dict[str, Any]:
        with self._lock:
            points = list(self.history)
        if since is not None:
            points = [p for p in points if p["timestamp"] >= since]
        points = points[-limit:]
        if metric and metric != "all":
            filtered = [
                {"timestamp": p["timestamp"], "value": p.get(metric, 0.0)} for p in points
            ]
            return {
                "metric": metric,
                "count": len(filtered),
                "points": filtered,
                "generated_at": datetime.now().isoformat(timespec="seconds"),
            }
        return {
            "metric": "all",
            "count": len(points),
            "points": points,
            "generated_at": datetime.now().isoformat(timespec="seconds"),
        }

    @property
    def warnings(self) -> list[str]:
        return sorted(self._warnings)

    @property
    def last_error(self) -> Optional[str]:
        return self._last_error

    @property
    def process_count(self) -> int:
        return self._process_count

    def snapshot_for_analysis(self) -> dict[str, Any]:
        """Compact, structured view of the current machine state."""
        cpu = self.cpu_metrics()
        memory = self.memory_metrics()
        disk = self.disk_metrics()
        network = self.network_metrics()
        return {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "cpu_percent": cpu["percent"],
            "cpu_per_core": cpu["per_core"],
            "cpu_frequency_mhz": cpu["frequency_mhz"],
            "memory_percent": memory["percent"],
            "memory_used_mb": memory["used_mb"],
            "memory_total_mb": memory["total_mb"],
            "memory_available_mb": memory["available_mb"],
            "swap_percent": memory["swap_percent"],
            "swap_used_mb": memory["swap_used_mb"],
            "disk_read_mb_s": disk["read_mb_s"],
            "disk_write_mb_s": disk["write_mb_s"],
            "disk_partitions": disk["partitions"],
            "net_upload_kb_s": network["upload_kb_s"],
            "net_download_kb_s": network["download_kb_s"],
            "process_count": self._process_count,
            "data_warnings": self.warnings,
        }


# Singleton used by the API layer
monitor = SystemMonitor()

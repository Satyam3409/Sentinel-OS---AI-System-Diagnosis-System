"""Performance Lab - bounded, safe, user-confirmed stress experiments.

Safety model
------------
*   Experiments require an explicit ``confirmed=true`` flag from the UI.
*   CPU load is produced with a fixed number of daemon threads that stop after a
    hard timeout (also clamped against a server-side maximum).
*   Memory load allocates in bounded chunks, never more than the server-side cap,
    never more than 25% of currently *available* memory, and is released even if
    the experiment is stopped early.
*   If the process crashes, the threads are daemon threads, so the interpreter
    exit reclaims them. Nothing is left running in the background.
"""

from __future__ import annotations

import threading
import time
import uuid
from datetime import datetime
from typing import Any, Optional

import psutil

from app import config
from app.services.monitor import monitor


class ExperimentManager:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._threads: list[threading.Thread] = []
        self._stop_event = threading.Event()
        self._buffer: list[bytearray] = []
        self._id: Optional[str] = None
        self._kind: Optional[str] = None
        self._started_ts: Optional[float] = None
        self._started_at: Optional[str] = None
        self._duration = 0
        self._workers = 0
        self._memory_mb = 0
        self._baseline: dict[str, float] = {}
        self._peak: dict[str, float] = {}
        self._current: dict[str, float] = {}
        self._recovery: Optional[dict[str, float]] = None
        self._samples = 0
        self._message = "No experiment has been run yet."
        self._watchdog: Optional[threading.Thread] = None

    # -- helpers -----------------------------------------------------------
    @property
    def running(self) -> bool:
        with self._lock:
            if self._id is None:
                return False
            elapsed = time.time() - (self._started_ts or 0)
            return elapsed < self._duration

    def _limits(self) -> dict[str, dict[str, int]]:
        mem = psutil.virtual_memory()
        safe_memory_mb = int(min(config.LAB_MAX_MEMORY_MB, max(64, (mem.available / (1024 * 1024)) * 0.25)))
        return {
            "cpu": {
                "max_workers": config.LAB_MAX_CPU_WORKERS,
                "max_duration_seconds": config.LAB_MAX_CPU_SECONDS,
                "available_logical_cores": psutil.cpu_count(logical=True) or 1,
            },
            "memory": {
                "max_memory_mb": safe_memory_mb,
                "configured_max_mb": config.LAB_MAX_MEMORY_MB,
                "max_duration_seconds": config.LAB_MAX_MEMORY_SECONDS,
                "available_mb": round(mem.available / (1024 * 1024), 1),
            },
        }

    def snapshot_metrics(self) -> dict[str, float]:
        summary = monitor.get_summary()
        return {
            "cpu_percent": summary["cpu"]["percent"],
            "memory_percent": summary["memory"]["percent"],
            "available_mb": summary["memory"]["available_mb"],
            "process_count": float(summary["process_count"]),
        }

    # -- control -----------------------------------------------------------
    def start(self, kind: str, workers: int, duration: int, memory_mb: int, confirmed: bool) -> dict[str, Any]:
        if not confirmed:
            raise PermissionError(
                "Performance experiments require explicit confirmation (confirmed=true) in the request."
            )
        if kind not in {"cpu", "memory"}:
            raise ValueError("kind must be 'cpu' or 'memory'")
        with self._lock:
            if self.running:
                raise RuntimeError("an experiment is already running; stop it before starting another")

            mem = psutil.virtual_memory()
            if kind == "cpu":
                workers = max(1, min(int(workers), config.LAB_MAX_CPU_WORKERS))
                duration = max(3, min(int(duration), config.LAB_MAX_CPU_SECONDS))
                memory_mb = 0
            else:
                safe_cap = int(min(config.LAB_MAX_MEMORY_MB, max(64, (mem.available / (1024 * 1024)) * 0.25)))
                memory_mb = max(16, min(int(memory_mb), safe_cap))
                duration = max(3, min(int(duration), config.LAB_MAX_MEMORY_SECONDS))
                workers = 1

            self._stop_event.clear()
            self._buffer = []
            self._threads = []
            self._id = uuid.uuid4().hex[:12]
            self._kind = kind
            self._started_ts = time.time()
            self._started_at = datetime.now().isoformat(timespec="seconds")
            self._duration = duration
            self._workers = workers
            self._memory_mb = memory_mb
            self._samples = 0
            self._recovery = None
            self._peak = {}
            self._baseline = self.snapshot_metrics()
            self._current = dict(self._baseline)
            self._message = (
                f"{kind.upper()} experiment started: {duration}s"
                + (f", {workers} worker thread(s)" if kind == "cpu" else f", {memory_mb} MB target")
            )

            target = self._cpu_worker if kind == "cpu" else self._memory_worker
            for index in range(workers):
                thread = threading.Thread(
                    target=target,
                    name=f"sentinel-lab-{kind}-{index}",
                    daemon=True,
                )
                thread.start()
                self._threads.append(thread)

            self._watchdog = threading.Thread(target=self._watch, name="sentinel-lab-watch", daemon=True)
            self._watchdog.start()

            return self.status()

    def stop(self, reason: str = "stopped by user") -> dict[str, Any]:
        with self._lock:
            if self._id is None:
                raise RuntimeError("no experiment to stop")
            self._stop_event.set()
            self._release_memory()
            self._capture_recovery()
            self._message = f"Experiment {reason} after {self._elapsed():.1f}s"
            # threads exit on their own; mark finished by expiring the id's timer
            self._id = None
            self._kind = None
            return self.status()

    def _elapsed(self) -> float:
        return time.time() - (self._started_ts or time.time())

    def _release_memory(self) -> None:
        self._buffer = []

    # -- workers -----------------------------------------------------------
    def _cpu_worker(self) -> None:
        deadline = time.time() + self._duration
        while not self._stop_event.is_set() and time.time() < deadline:
            # Bounded busy work with a tiny sleep so the OS scheduler can still
            # run the rest of the machine (including this API) smoothly.
            end = time.time() + 0.05
            accumulator = 0.0
            while time.time() < end and not self._stop_event.is_set():
                for i in range(2000):
                    accumulator += (i * i) % 7
            _ = accumulator
            time.sleep(0.005)

    def _memory_worker(self) -> None:
        chunk_mb = 16
        total_mb = self._memory_mb
        deadline = time.time() + self._duration
        allocated = 0
        while allocated < total_mb and not self._stop_event.is_set():
            size = min(chunk_mb, total_mb - allocated)
            try:
                block = bytearray(size * 1024 * 1024)
                # Touch pages so the OS actually commits the memory.
                block[::4096] = b"\x01" * len(block[::4096])
            except MemoryError:
                self._message = "Memory allocation stopped early: the operating system refused the request."
                break
            self._buffer.append(block)
            allocated += size
            time.sleep(0.05)
        while not self._stop_event.is_set() and time.time() < deadline:
            time.sleep(0.1)
        self._release_memory()

    def _watch(self) -> None:
        deadline = time.time() + self._duration
        while not self._stop_event.is_set() and time.time() < deadline:
            metrics = self.snapshot_metrics()
            with self._lock:
                self._current = metrics
                self._samples += 1
                for key, value in metrics.items():
                    if key == "available_mb":
                        current_peak = self._peak.get(key, float("inf"))
                        self._peak[key] = min(current_peak, value)
                    else:
                        self._peak[key] = max(self._peak.get(key, 0.0), value)
            time.sleep(0.5)

        # Timeout reached: clean up deterministically.
        with self._lock:
            if self._id is not None and not self._stop_event.is_set():
                self._stop_event.set()
                self._release_memory()
                self._capture_recovery()
                self._message = f"Experiment completed its {self._duration}s safety timeout and was cleaned up"
                self._id = None
                self._kind = None

    def _capture_recovery(self) -> None:
        # Sample immediately after cleanup starts; a second reading is taken on
        # the next status() call to show genuine recovery.
        time.sleep(0.8)
        self._recovery = self.snapshot_metrics()

    # -- reporting ---------------------------------------------------------
    def status(self) -> dict[str, Any]:
        with self._lock:
            running = self._id is not None and self._elapsed() < self._duration
            remaining = max(0.0, self._duration - self._elapsed()) if self._id else 0.0
            return {
                "id": self._id,
                "kind": self._kind,
                "running": running,
                "started_at": self._started_at,
                "started_ts": self._started_ts,
                "duration_seconds": self._duration,
                "seconds_remaining": round(remaining, 1),
                "workers": self._workers,
                "memory_mb": self._memory_mb,
                "baseline": dict(self._baseline),
                "peak": dict(self._peak),
                "current": dict(self._current),
                "recovery": dict(self._recovery) if self._recovery else None,
                "samples": self._samples,
                "message": self._message,
                "limits": self._limits(),
            }

    def cleanup(self) -> None:
        """Release everything. Called on application shutdown."""
        self._stop_event.set()
        self._release_memory()
        for thread in self._threads:
            if thread.is_alive():
                thread.join(timeout=1.0)


experiment_manager = ExperimentManager()

"""Background orchestration: sample -> score -> persist.

A single daemon task drives the whole pipeline so that every consumer (REST,
WebSocket, AI Doctor, forecasting) reads from one consistent state.
"""

from __future__ import annotations

import asyncio
import threading
import time
from collections import deque
from datetime import datetime
from typing import Any, Optional

import psutil

from app import config
from app.database import db
from app.ml.anomaly import anomaly_engine
from app.services.experiments import experiment_manager
from app.services.monitor import monitor


class Orchestrator:
    def __init__(self) -> None:
        self.recent_anomalies: deque[dict[str, Any]] = deque(maxlen=40)
        self.recent_samples: deque[dict[str, Any]] = deque(maxlen=300)
        self._task: Optional[asyncio.Task] = None
        self._stop = threading.Event()
        self._persist_counter = 0
        self._subscribers: set[asyncio.Queue] = set()
        self._lock = asyncio.Lock()
        self.ticks = 0
        self.last_tick: Optional[float] = None
        self.started_at: Optional[float] = None

    # -- pub/sub for WebSockets -------------------------------------------
    async def subscribe(self) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue(maxsize=30)
        async with self._lock:
            self._subscribers.add(queue)
        return queue

    async def unsubscribe(self, queue: asyncio.Queue) -> None:
        async with self._lock:
            self._subscribers.discard(queue)

    async def _broadcast(self, payload: dict[str, Any]) -> None:
        async with self._lock:
            subscribers = list(self._subscribers)
        for queue in subscribers:
            try:
                queue.put_nowait(payload)
            except asyncio.QueueFull:
                # Slow consumer: drop the oldest frame rather than blocking the pipeline.
                try:
                    queue.get_nowait()
                    queue.put_nowait(payload)
                except Exception:
                    pass

    # -- lifecycle ---------------------------------------------------------
    def bootstrap(self) -> dict[str, Any]:
        """Prepare database and ML model. Runs once at startup."""
        db.init_db()
        settings = db.get_settings()
        anomaly_engine.enabled = bool(config.ML_ENABLED)
        anomaly_engine.set_sensitivity(float(settings.get("sensitivity", 0.5)))

        loaded = anomaly_engine.load()
        source = "persisted-model" if loaded else "none"
        if not loaded:
            try:
                anomaly_engine.train_cold_start()
                source = "synthetic-healthy-baseline"
            except Exception as exc:  # pragma: no cover - defensive
                source = f"cold-start-training-failed: {exc}"
        # Warm up the real model with whatever history we already have on disk.
        try:
            samples = db.fetch_samples(limit=600)
            if samples:
                self.recent_samples.extend(samples)
                if anomaly_engine.maybe_retrain(samples):
                    source = anomaly_engine.training_source
                else:
                    anomaly_engine.train(anomaly_engine._samples_to_matrix(samples), source="real-history", persist=True)
                    source = "real-history"
        except Exception:
            pass
        db.apply_retention(int(settings.get("retention_days", config.RETENTION_DAYS)))
        if hasattr(anomaly_engine, "_last_real_training_size"):
            anomaly_engine._last_real_training_size = len(list(self.recent_samples))
        return {
            "db_path": str(config.DB_PATH),
            "model_ready": anomaly_engine.model_ready,
            "model_source": source,
        }

    def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop.clear()
        self.started_at = time.time()
        monitor.start()
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
            self._task = None
        monitor.stop()
        experiment_manager.cleanup()

    # -- main loop ---------------------------------------------------------
    async def _loop(self) -> None:
        # Small warm-up so the CPU percentage has a valid delta on first tick.
        await asyncio.sleep(0.2)
        while not self._stop.is_set():
            try:
                await self.tick()
            except Exception:  # pragma: no cover - never let the loop die
                pass
            await asyncio.sleep(max(0.5, monitor.sample_interval))

    async def tick(self) -> dict[str, Any]:
        sample = monitor.collect_sample()
        evaluation = anomaly_engine.evaluate(sample)
        self.recent_samples.append(sample)
        self.ticks += 1
        self.last_tick = time.time()

        event = None
        if evaluation["is_anomaly"]:
            # Avoid flooding the history with the same consecutive condition.
            if not self.recent_anomalies or (
                self.recent_anomalies[-1]["metric"] != evaluation["metric"]
                or time.time() - self.recent_anomalies[-1]["timestamp"] > 30
            ):
                try:
                    event_id = db.insert_anomaly(evaluation)
                    evaluation["id"] = event_id
                except Exception:
                    evaluation["id"] = None
                event = evaluation
                self.recent_anomalies.append(evaluation)

        self._persist_counter += 1
        persist_every = max(1, int(round(15.0 / max(monitor.sample_interval, 0.5))))
        if self._persist_counter % persist_every == 0:
            try:
                db.insert_samples([sample])
            except Exception:
                pass
            try:
                samples = [dict(s) for s in self.recent_samples]
                if anomaly_engine.maybe_retrain(samples):
                    pass
            except Exception:
                pass

        payload = {
            "type": "metrics",
            "timestamp": sample["timestamp"],
            "sample": sample,
            "summary": self._light_summary(),
            "anomaly": {
                "is_anomaly": evaluation["is_anomaly"],
                "score": evaluation["score"],
                "severity": evaluation["severity"],
                "metric": evaluation["metric"],
                "explanation": evaluation["explanation"] if evaluation["is_anomaly"] else "",
            },
            "experiment": experiment_manager.status() if experiment_manager.running else None,
            "events": [event] if event else [],
            "ticks": self.ticks,
        }
        await self._broadcast(payload)
        return payload

    def _light_summary(self) -> dict[str, Any]:
        """Cheap subset of the summary for high-frequency WebSocket frames."""
        try:
            uptime = round(time.time() - psutil.boot_time(), 1)
        except Exception:
            uptime = 0.0
        memory = monitor.memory_metrics()
        return {
            "source": "live",
            "timestamp": time.time(),
            "cpu_percent": round(float(psutil.cpu_percent(interval=None)), 2),
            "memory_percent": round(memory["percent"], 2),
            "swap_percent": round(memory["swap_percent"], 2),
            "process_count": monitor.process_count,
            "uptime_seconds": uptime,
        }

    def recent_anomaly_payloads(self, limit: int = 10) -> list[dict[str, Any]]:
        items = list(self.recent_anomalies)[-limit:]
        return list(reversed(items))

    def current_status(self) -> dict[str, Any]:
        return {
            "monitor_running": monitor.running,
            "ticks": self.ticks,
            "last_tick": self.last_tick,
            "started_at": self.started_at,
            "sample_interval": monitor.sample_interval,
            "history_points": len(monitor.history),
            "subscribers": len(self._subscribers),
            "server_time": time.time(),
            "server_time_iso": datetime.now().isoformat(timespec="seconds"),
        }


orchestrator = Orchestrator()

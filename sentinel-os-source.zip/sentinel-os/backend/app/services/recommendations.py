"""Evidence-based recommendation engine.

Every recommendation is derived from measured values, carries the evidence that
triggered it, and is strictly read-only. No recommendation executes anything.
"""

from __future__ import annotations

import time
from typing import Any

from app.services.monitor import monitor
from app.services.processes import top_processes


def _pct(value: float) -> str:
    return f"{value:.1f}%"


def _fmt_process(p: dict[str, Any], field: str, unit: str) -> str:
    if field == "cpu_percent":
        value = p["cpu_percent"]
    elif field == "memory_mb":
        value = p["memory_mb"]
        unit = "MB"
    else:
        value = p[field]
    return f"{p['name']} (PID {p['pid']}) at {value}{unit}"


def build_recommendations(summary: dict[str, Any] | None = None) -> dict[str, Any]:
    """Generate recommendations from a live system summary."""
    summary = summary or monitor.get_summary()
    cpu = summary["cpu"]["percent"]
    mem = summary["memory"]
    disk = summary["disk"]
    system = summary.get("system", {})
    items: list[dict[str, Any]] = []

    def add(
        rid: str,
        severity: str,
        trigger: str,
        evidence: str,
        explanation: str,
        action: str,
        risk: str,
        verification: str,
    ) -> None:
        items.append(
            {
                "id": rid,
                "severity": severity,
                "trigger": trigger,
                "evidence": evidence,
                "explanation": explanation,
                "suggested_action": action,
                "risk": risk,
                "verification": verification,
                "read_only": True,
            }
        )

    # --- CPU pressure -----------------------------------------------------
    cpu_threshold = 70.0
    if cpu >= cpu_threshold:
        try:
            hogs = top_processes(limit=5, by="cpu")
        except Exception:
            hogs = []
        hog_text = ", ".join(_fmt_process(p, "cpu_percent", "%") for p in hogs[:3]) or "no dominant process identified"
        severity = "critical" if cpu >= 90 else ("high" if cpu >= 80 else "medium")
        add(
            "cpu-pressure",
            severity,
            f"CPU utilisation at {_pct(cpu)} (threshold {_pct(cpu_threshold)})",
            f"Measured CPU utilisation {_pct(cpu)}; top consumers: {hog_text}. "
            f"Logical cores: {summary['cpu'].get('core_count_logical')}, "
            f"current frequency: {summary['cpu'].get('frequency_mhz') or 'unavailable'} MHz.",
            "Sustained high CPU means the processor scheduler is contended. Every process gets a smaller "
            "share of CPU time, which shows up as sluggish UI and delayed responses.",
            "Open Process Explorer, sort by CPU, and identify whether the top consumer matches work you "
            "intentionally started. If it does not, investigate that application before taking any action.",
            "Closing the wrong process can lose unsaved work. SENTINEL OS will not terminate processes for you.",
            f"Re-check CPU utilisation after the workload finishes; it should fall below {_pct(cpu_threshold)}.",
        )

    # --- Memory pressure --------------------------------------------------
    mem_threshold = 75.0
    if mem["percent"] >= mem_threshold:
        try:
            mem_hogs = top_processes(limit=5, by="memory")
        except Exception:
            mem_hogs = []
        hog_text = ", ".join(_fmt_process(p, "memory_mb", "MB") for p in mem_hogs[:3]) or "no dominant process identified"
        severity = "critical" if mem["percent"] >= 92 else ("high" if mem["percent"] >= 85 else "medium")
        add(
            "memory-pressure",
            severity,
            f"Memory utilisation at {_pct(mem['percent'])} (threshold {_pct(mem_threshold)})",
            f"Used {mem['used_mb']} MB of {mem['total_mb']} MB; available {mem['available_mb']} MB. "
            f"Largest consumers: {hog_text}.",
            "Physical memory is close to exhaustion. When free memory runs out the OS starts paging, which is "
            "orders of magnitude slower than RAM access.",
            "Review the memory-heavy processes listed above, confirm they are expected, and close applications "
            "you no longer need.",
            "Ending a process abruptly can cause data loss or system instability if it is a driver or service.",
            "Available memory should increase and memory utilisation should drop once the application is closed.",
        )

    # --- Swap pressure ----------------------------------------------------
    if mem.get("swap_percent", 0) >= 35:
        add(
            "swap-pressure",
            "high" if mem["swap_percent"] >= 60 else "medium",
            f"Swap utilisation at {_pct(mem['swap_percent'])}",
            f"Swap used {mem['swap_used_mb']} MB of {mem['swap_total_mb']} MB ({_pct(mem['swap_percent'])}), "
            f"with physical memory at {_pct(mem['percent'])}.",
            "Swap in active use is the clearest concrete indicator of memory pressure: the machine is moving "
            "pages between RAM and disk to keep working.",
            "Investigate memory pressure first (see the memory recommendation), then consider whether the "
            "machine needs a memory upgrade for the workloads you run.",
            "Changing swap configuration affects system stability and should be done through Windows system "
            "settings, not by SENTINEL OS.",
            "After loading reduces, swap used should stabilise or fall.",
        )

    # --- Disk capacity ----------------------------------------------------
    for part in disk.get("partitions", []):
        if part["percent"] >= 80:
            safe_mount = part["mountpoint"].replace(":", "").replace("\\", "").replace("/", "") or "root"
            add(
                f"disk-capacity-{safe_mount}",
                "critical" if part["percent"] >= 92 else "high",
                f"Disk {part['mountpoint']} at {_pct(part['percent'])} capacity",
                f"{part['used_gb']} GB used of {part['total_gb']} GB on {part['device']} "
                f"({part['fstype']}), {part['free_gb']} GB free.",
                "Low free space degrades performance: the OS cannot grow the page file, applications cannot "
                "write caches, and file fragmentation increases.",
                "Investigate which directories consume the most space using Windows Storage Settings, then "
                "remove files you own that you no longer need.",
                "Do not delete system or application files blindly. Low disk space does not justify deleting "
                "anything SENTINEL OS identifies without your review.",
                "Free space should increase after you remove files you identified.",
            )

    # --- Disk I/O ---------------------------------------------------------
    if disk["write_mb_s"] >= 60 or disk["read_mb_s"] >= 60:
        dominant = "write" if disk["write_mb_s"] >= disk["read_mb_s"] else "read"
        value = disk["write_mb_s"] if dominant == "write" else disk["read_mb_s"]
        add(
            "disk-io",
            "medium" if value < 120 else "high",
            f"High disk {dominant} throughput of {value:.1f} MB/s",
            f"Measured disk read {disk['read_mb_s']} MB/s and write {disk['write_mb_s']} MB/s.",
            "Heavy disk activity can bottleneck otherwise idle systems, and on mechanical drives it also "
            "increases latency for every other disk operation.",
            "Correlate the activity with known tasks such as backup, sync clients, indexing, or builds.",
            "Stopping a system service mid-operation can corrupt data; verify the workload source first.",
            "Disk throughput should return to a low idle level once the operation completes.",
        )

    # --- Storage health (free space overall) ------------------------------
    if disk.get("partitions"):
        total = sum(p["total_gb"] for p in disk["partitions"])
        free = sum(p["free_gb"] for p in disk["partitions"])
        if total > 0:
            free_ratio = free / total * 100
            if free_ratio < 20:
                add(
                    "storage-overall",
                    "medium",
                    f"Only {_pct(free_ratio)} of total storage is free",
                    f"{free:.1f} GB free across {len(disk['partitions'])} partition(s) totalling {total:.1f} GB.",
                    "Aggregate free space below roughly 20% tends to degrade write performance across the system.",
                    "Plan a storage review: identify large downloads, caches, and obsolete installers.",
                    "Read-only analysis only. SENTINEL OS does not delete files.",
                    "Free space ratio should rise after a storage review.",
                )

    # --- Process count ----------------------------------------------------
    if summary.get("process_count", 0) > 350:
        add(
            "process-count",
            "low",
            f"{summary['process_count']} processes running",
            f"Process table contains {summary['process_count']} entries.",
            "A very large process count increases scheduling overhead and memory used by kernel bookkeeping.",
            "Open Process Explorer and review background applications that start automatically.",
            "Disabling startup items changes your environment; verify each item's purpose first.",
            "Process count should decrease after disabling genuinely unneeded startup applications.",
        )

    # --- Uptime -----------------------------------------------------------
    uptime_days = system.get("uptime_seconds", 0) / 86400
    if uptime_days >= 7:
        add(
            "uptime",
            "low",
            f"System uptime is {uptime_days:.1f} days",
            f"Boot time {system.get('boot_time')} corresponds to {uptime_days:.1f} days of uptime.",
            "Long uptimes allow caches, handles, and memory to accumulate in user-mode applications.",
            "Plan a restart at a convenient time to clear accumulated state.",
            "A restart interrupts your work and closes unsaved documents. Save everything first.",
            "Memory and handle counts typically drop after a restart.",
        )

    items.sort(key=lambda r: ["info", "low", "medium", "high", "critical"].index(r["severity"]), reverse=True)
    return {"timestamp": time.time(), "count": len(items), "items": items}

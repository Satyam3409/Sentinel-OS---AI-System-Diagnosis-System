"""Short-term trend forecasting for CPU and memory.

Uses ordinary least squares on the recent window plus a moving-average
correction, then reports an honest accuracy figure from a hold-out split.
Predictions are explicitly refused when there is not enough data.
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import Any, Optional

import numpy as np

MIN_SAMPLES = 20
HORIZON = 10


def _series(
    samples: list[dict[str, Any]],
    key: str,
    label: str,
    unit: str,
    horizon: int = HORIZON,
) -> dict[str, Any]:
    values = np.asarray([float(s[key]) for s in samples], dtype=float)
    timestamps = np.asarray([float(s["timestamp"]) for s in samples], dtype=float)
    if len(values) < MIN_SAMPLES:
        return {
            "metric": label,
            "unit": unit,
            "horizon": horizon,
            "history": [
                {"timestamp": float(t), "value": round(float(v), 2), "kind": "actual"}
                for t, v in zip(timestamps, values)
            ],
            "forecast": [],
            "slope_per_minute": 0.0,
            "confidence": 0.0,
            "method": "OLS + moving average",
            "sufficient_data": False,
            "message": (
                f"Only {len(values)} of {MIN_SAMPLES} required samples are available. "
                "Forecasting is disabled until enough real measurements have been recorded."
            ),
        }

    # Interval between samples (seconds) taken from real timestamps.
    deltas = np.diff(timestamps)
    step = float(np.median(deltas)) if deltas.size else 2.0
    step = step if step > 0 else 2.0

    # Fit on all but the last `horizon` samples so we can measure real error.
    holdout = min(horizon, max(3, len(values) // 5))
    train_x = np.arange(len(values) - holdout, dtype=float)
    train_y = values[: len(values) - holdout]
    test_x = np.arange(len(values) - holdout, len(values), dtype=float)
    test_y = values[len(values) - holdout :]

    slope, intercept = np.polyfit(train_x, train_y, 1)
    predicted_test = slope * test_x + intercept
    mae = float(np.mean(np.abs(predicted_test - test_y)))
    rmse = float(np.sqrt(np.mean((predicted_test - test_y) ** 2)))
    mean_abs = float(np.mean(np.abs(test_y))) or 1.0
    mape = float(np.mean(np.abs((predicted_test - test_y) / np.maximum(np.abs(test_y), 1e-6)))) * 100

    # Refit on the full series for the actual forecast.
    full_x = np.arange(len(values), dtype=float)
    slope, intercept = np.polyfit(full_x, values, 1)
    recent_avg = float(np.mean(values[-5:]))
    trend_anchor = slope * (len(values) - 1) + intercept
    # Blend the regression projection with the recent mean to avoid over-reacting
    # to a single noisy sample.
    blended_anchor = 0.7 * trend_anchor + 0.3 * recent_avg

    future_x = np.arange(len(values), len(values) + horizon, dtype=float)
    last_ts = float(timestamps[-1])
    forecast_values = [blended_anchor + slope * (fx - (len(values) - 1)) for fx in future_x]
    forecast_values = [float(np.clip(v, 0.0, 100.0)) for v in forecast_values]

    history = [
        {"timestamp": float(t), "value": round(float(v), 2), "kind": "actual"}
        for t, v in zip(timestamps, values)
    ]
    forecast = [
        {
            "timestamp": last_ts + step * (i + 1),
            "value": round(v, 2),
            "kind": "predicted",
        }
        for i, v in enumerate(forecast_values)
    ]

    # Confidence degrades with error and with the size of the extrapolation.
    error_component = max(0.0, 1.0 - (mae / 10.0))
    data_component = min(1.0, len(values) / 120.0)
    confidence = float(np.clip(0.45 * error_component + 0.55 * data_component, 0.05, 0.97))

    return {
        "metric": label,
        "unit": unit,
        "horizon": horizon,
        "history": history,
        "forecast": forecast,
        "slope_per_minute": round(float(slope) * (60.0 / step), 3),
        "confidence": round(confidence, 3),
        "method": f"OLS linear trend + moving-average blend (hold-out of {holdout} samples)",
        "sufficient_data": True,
        "message": (
            f"Projected {label.lower()} {horizon * step:.0f}s ahead. "
            f"Trend {slope * (60.0 / step):+.2f} {unit}/min."
        ),
        "error": {
            "mae": round(mae, 3),
            "rmse": round(rmse, 3),
            "mape_percent": round(mape, 2),
            "holdout_samples": holdout,
        },
    }


def build_forecast(samples: Optional[list[dict[str, Any]]] = None, horizon: int = HORIZON) -> dict[str, Any]:
    samples = samples or []
    return {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "available_samples": len(samples),
        "required_samples": MIN_SAMPLES,
        "series": [
            _series(samples, "cpu_percent", "CPU utilisation", "%", horizon),
            _series(samples, "memory_percent", "Memory utilisation", "%", horizon),
        ],
        "generated_ts": time.time(),
    }

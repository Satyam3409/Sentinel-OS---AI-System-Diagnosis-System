"""Read-only process enumeration.

SENTINEL OS never terminates processes. This module only inspects them.
Permission errors (common for SYSTEM-owned processes on Windows) are handled
by degrading the individual field rather than failing the whole listing.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Optional

import psutil

from app import config


def _safe(fn, default=None):
    try:
        return fn()
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, OSError):
        return default
    except Exception:
        return default


_SNAPSHOT_LOCK = threading.Lock()
_SNAPSHOT: dict[str, Any] = {
    "rows": [],
    "skipped": 0,
    "captured_at": 0.0,
    "taken_at": 0.0,
    "duration": 0.0,
    "built": False,
}


def _enumerate_rows() -> tuple[list[dict[str, Any]], int, float]:
    """Measure every running process once and return the raw, unsorted rows.

    On Windows each `status` / `memory_info` lookup is a separate kernel call, so
    sweeping ~370 processes costs several seconds. Parallelising the lookups does
    not help (the cost is not GIL-bound), so the sweep result is memoised instead.
    """
    cpu_count = psutil.cpu_count(logical=True) or 1
    total_memory = float(psutil.virtual_memory().total) or 1.0
    rows: list[dict[str, Any]] = []
    skipped = 0

    for proc in psutil.process_iter(["pid", "name", "username", "status", "memory_info", "num_threads", "create_time"]):
        try:
            info = proc.info
            pid = info.get("pid")
            if pid is None:
                continue
            name = info.get("name") or f"pid-{pid}"
            mem_info = info.get("memory_info")
            memory_bytes = float(mem_info.rss) if mem_info is not None else 0.0
            cpu_percent = 0.0
            try:
                # process_iter fills info but not cpu_percent reliably; use the
                # cached value from psutil's process cache.
                cpu_percent = float(proc.cpu_percent(interval=None))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                cpu_percent = 0.0
            # psutil returns 0-100*cores for processes; normalise to a share of
            # total machine CPU capacity so the column reads like Task Manager.
            cpu_normalised = round(cpu_percent / cpu_count, 2)
            rows.append(
                {
                    "pid": int(pid),
                    "name": name,
                    "username": info.get("username"),
                    "status": info.get("status"),
                    "cpu_percent": cpu_normalised,
                    "memory_percent": round(memory_bytes / total_memory * 100, 3),
                    "memory_mb": round(memory_bytes / (1024 * 1024), 2),
                    "num_threads": info.get("num_threads"),
                    "create_time": info.get("create_time"),
                    "exe": None,
                    "cmdline": None,
                }
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            skipped += 1
            continue
        except Exception:
            skipped += 1
            continue

    return rows, skipped, time.time()


def _snapshot_rows() -> tuple[list[dict[str, Any]], int, float]:
    """Return the current process snapshot, re-measuring only when it has expired.

    The lock makes this single-flight: concurrent callers wait for one sweep
    rather than each starting their own.

    The freshness window is `max(PROCESS_CACHE_TTL, how long the last sweep
    took)`. A sweep is only ever re-run after it has been idle for at least as
    long as it took to produce, so a monitoring tool can never end up sweeping
    processes back-to-back and hogging the CPU it is supposed to be measuring.
    The age is counted from the moment a sweep *finished*, not when it started.
    """
    now = time.monotonic()
    with _SNAPSHOT_LOCK:
        window = max(config.PROCESS_CACHE_TTL, _SNAPSHOT["duration"])
        fresh = _SNAPSHOT["built"] and (now - _SNAPSHOT["taken_at"]) < window
        if not fresh:
            started = time.monotonic()
            rows, skipped, captured_at = _enumerate_rows()
            _SNAPSHOT.update(
                rows=rows,
                skipped=skipped,
                captured_at=captured_at,
                taken_at=time.monotonic(),
                duration=time.monotonic() - started,
                built=True,
            )
        return _SNAPSHOT["rows"], _SNAPSHOT["skipped"], _SNAPSHOT["captured_at"]


def collect_processes(
    limit: Optional[int] = None,
    sort: str = "cpu",
    search: Optional[str] = None,
    status: Optional[str] = None,
) -> dict[str, Any]:
    """Return a snapshot of running processes.

    sort: "cpu" | "memory" | "name" | "pid"
    """
    limit = limit or config.PROCESS_LIMIT

    rows, skipped, captured_at = _snapshot_rows()
    # Work on a copy: the cached list is shared between callers.
    rows = list(rows)

    if search:
        needle = search.lower()
        rows = [r for r in rows if needle in r["name"].lower() or needle == str(r["pid"])]
    if status and status != "all":
        rows = [r for r in rows if (r["status"] or "").lower() == status.lower()]

    if sort == "memory":
        rows.sort(key=lambda r: r["memory_mb"], reverse=True)
    elif sort == "name":
        rows.sort(key=lambda r: r["name"].lower())
    elif sort == "pid":
        rows.sort(key=lambda r: r["pid"])
    else:
        rows.sort(key=lambda r: (r["cpu_percent"], r["memory_mb"]), reverse=True)

    total = len(rows)
    return {
        "timestamp": captured_at,
        "total": total,
        "returned": min(total, limit),
        "processes": rows[:limit],
        "skipped": skipped,
    }


def get_process_detail(pid: int) -> Optional[dict[str, Any]]:
    """Detailed view of a single process. Returns None when it no longer exists."""
    try:
        proc = psutil.Process(pid)
    except (psutil.NoSuchProcess, ValueError):
        return None

    with proc.oneshot():
        mem_info = _safe(lambda: proc.memory_info())
        detail = {
            "pid": pid,
            "name": _safe(lambda: proc.name(), f"pid-{pid}"),
            "username": _safe(lambda: proc.username()),
            "status": _safe(lambda: proc.status()),
            "cpu_percent": round(float(_safe(lambda: proc.cpu_percent(interval=None), 0.0) or 0.0), 2),
            "memory_percent": round(float(_safe(lambda: proc.memory_percent(), 0.0) or 0.0), 3),
            "memory_mb": round((mem_info.rss if mem_info else 0) / (1024 * 1024), 2),
            "num_threads": _safe(lambda: proc.num_threads()),
            "create_time": _safe(lambda: proc.create_time()),
            "exe": _safe(lambda: proc.exe()),
            "cmdline": " ".join(_safe(lambda: proc.cmdline(), []) or []),
            "cwd": _safe(lambda: proc.cwd()),
            "nice": _safe(lambda: proc.nice()),
            "connections": len(_safe(lambda: proc.net_connections(), []) or []),
            "open_files": len(_safe(lambda: proc.open_files(), []) or []),
            "read_only": True,
            "note": "SENTINEL OS exposes process data read-only. Termination is intentionally not implemented.",
        }
    # Normalise CPU to a share of total machine capacity for display consistency.
    cpu_count = psutil.cpu_count(logical=True) or 1
    detail["cpu_percent"] = round(detail["cpu_percent"] / cpu_count, 2)
    return detail


def top_processes(limit: int = 5, by: str = "cpu") -> list[dict[str, Any]]:
    data = collect_processes(limit=limit, sort=by)
    return data["processes"]

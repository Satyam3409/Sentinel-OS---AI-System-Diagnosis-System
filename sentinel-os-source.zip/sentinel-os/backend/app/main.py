"""SENTINEL OS - AI-Powered System Intelligence & Diagnostics Platform.

FastAPI application entry point.

Run locally:
    uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload

The monitoring agent runs inside this process: it samples real Windows metrics
with psutil on a background task and broadcasts them over WebSocket.
"""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app import config
from app.api import ai, anomaly, experiments, forecast, history, processes, recommendations, settings, system, ws
from app.services.orchestrator import orchestrator

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
)
logger = logging.getLogger("sentinel")

API_PREFIX = "/api"

DESCRIPTION = """
**SENTINEL OS** - AI-Powered System Intelligence & Diagnostics Platform.

All metrics returned by this API are measured from the local machine using `psutil`.
A cloud-hosted preview cannot access unrestricted local Windows metrics: the agent
must run on the machine being monitored (see `README.md`).

Safety model: the API is **read-only**. It never terminates processes, deletes
files, edits the registry, or disables security features.
"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting SENTINEL OS monitoring agent...")
    info = orchestrator.bootstrap()
    logger.info("Database ready at %s", info["db_path"])
    logger.info("Anomaly model ready: %s (source: %s)", info["model_ready"], info["model_source"])
    if not config.gemini_configured():
        logger.warning(
            "GEMINI_API_KEY is not set - the AI Doctor will use its offline rule-based engine. "
            "Copy backend/.env.example to backend/.env and add your key to enable Gemini."
        )
    else:
        logger.info("Gemini configured (model: %s)", config.GEMINI_MODEL)
    orchestrator.start()
    logger.info("Monitoring every %.1fs on http://%s:%s", config.SAMPLE_INTERVAL, config.HOST, config.PORT)
    try:
        yield
    finally:
        logger.info("Shutting down SENTINEL OS monitoring agent...")
        await orchestrator.stop()


app = FastAPI(
    title=config.APP_NAME,
    description=DESCRIPTION,
    version=config.APP_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# Restricted CORS: only the local frontend origins are permitted.
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.ALLOWED_ORIGINS,
    allow_origin_regex=r"^http://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# --- API routers ------------------------------------------------------------
app.include_router(system.router, prefix=API_PREFIX)
app.include_router(processes.router, prefix=API_PREFIX)
app.include_router(anomaly.router, prefix=API_PREFIX)
app.include_router(ai.router, prefix=API_PREFIX)
app.include_router(recommendations.router, prefix=API_PREFIX)
app.include_router(history.router, prefix=API_PREFIX)
app.include_router(experiments.router, prefix=API_PREFIX)
app.include_router(forecast.router, prefix=API_PREFIX)
app.include_router(settings.router, prefix=API_PREFIX)
app.include_router(ws.router)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Convert unexpected errors into structured JSON instead of a traceback page."""
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_error",
            "detail": str(exc),
            "path": request.url.path,
            "hint": "Check the backend console for the full traceback.",
        },
    )


@app.get("/api", tags=["meta"])
def api_index() -> dict:
    return {
        "name": config.APP_NAME,
        "version": config.APP_VERSION,
        "docs": "/docs",
        "endpoints": {
            "health": "/api/health",
            "summary": "/api/system/summary",
            "history": "/api/system/history",
            "disks": "/api/system/disks",
            "network": "/api/system/network",
            "processes": "/api/processes",
            "anomaly": "/api/anomaly/status",
            "ai_doctor": "/api/ai/doctor",
            "recommendations": "/api/recommendations",
            "history_store": "/api/history/events",
            "lab": "/api/lab/status",
            "forecast": "/api/forecast",
            "settings": "/api/settings",
            "about": "/api/about",
            "ws_metrics": "/ws/metrics",
            "ws_processes": "/ws/processes",
        },
        "server_time": time.time(),
    }


# --- Optional: serve a production build of the frontend from this process ----
DIST_DIR = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
if DIST_DIR.exists():
    app.mount("/assets", StaticFiles(directory=DIST_DIR / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa(full_path: str):
        candidate = DIST_DIR / full_path
        if full_path and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(DIST_DIR / "index.html")


def main() -> None:
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=config.HOST,
        port=config.PORT,
        reload=False,
        log_level="info",
    )


if __name__ == "__main__":
    main()

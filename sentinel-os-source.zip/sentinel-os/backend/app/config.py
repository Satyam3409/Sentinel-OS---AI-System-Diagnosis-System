"""Application configuration for the SENTINEL OS monitoring backend.

All values can be overridden through environment variables (see .env.example).
The backend is localhost-first by design: it binds to 127.0.0.1 and only allows
the local frontend origins through CORS.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent  # sentinel-os/backend
BACKEND_ROOT = BASE_DIR

load_dotenv(BACKEND_ROOT / ".env")

APP_NAME = "SENTINEL OS"
APP_VERSION = "1.0.0"


def _get_bool(key: str, default: bool) -> bool:
    raw = os.getenv(key)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _get_int(key: str, default: int) -> int:
    try:
        return int(os.getenv(key, str(default)))
    except ValueError:
        return default


def _get_float(key: str, default: float) -> float:
    try:
        return float(os.getenv(key, str(default)))
    except ValueError:
        return default


# --- Networking -------------------------------------------------------------
HOST: str = os.getenv("SENTINEL_HOST", "127.0.0.1")
PORT: int = _get_int("SENTINEL_PORT", 8000)

ALLOWED_ORIGINS: list[str] = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:4173",
    "http://127.0.0.1:4173",
    f"http://localhost:{PORT}",
    f"http://127.0.0.1:{PORT}",
]

# --- Monitoring -------------------------------------------------------------
SAMPLE_INTERVAL: float = _get_float("SENTINEL_SAMPLE_INTERVAL", 2.0)
HISTORY_MAX_POINTS: int = _get_int("SENTINEL_HISTORY_MAX_POINTS", 900)
PROCESS_LIMIT: int = _get_int("SENTINEL_PROCESS_LIMIT", 250)
# A full process sweep costs a kernel call per process on Windows, so the
# resulting snapshot is memoised for this many seconds and shared by every
# consumer (Process Explorer, recommendations, AI Doctor).
PROCESS_CACHE_TTL: float = _get_float("SENTINEL_PROCESS_CACHE_TTL", 2.0)

# --- Database ---------------------------------------------------------------
DATA_DIR = Path(os.getenv("SENTINEL_DATA_DIR", str(BACKEND_ROOT / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "sentinel.db"

RETENTION_DAYS: int = _get_int("SENTINEL_RETENTION_DAYS", 30)
MAX_ANOMALY_ROWS: int = _get_int("SENTINEL_MAX_ANOMALY_ROWS", 5000)
MAX_REPORT_ROWS: int = _get_int("SENTINEL_MAX_REPORT_ROWS", 1000)

# --- Machine learning -------------------------------------------------------
MODEL_PATH = DATA_DIR / "isolation_forest.joblib"
ML_ENABLED: bool = _get_bool("SENTINEL_ML_ENABLED", True)
ML_MIN_TRAIN_SAMPLES: int = _get_int("SENTINEL_ML_MIN_TRAIN_SAMPLES", 60)
ML_CONTAMINATION: float = _get_float("SENTINEL_ML_CONTAMINATION", 0.06)

# --- Gemini AI --------------------------------------------------------------
GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
GEMINI_TIMEOUT: float = _get_float("GEMINI_TIMEOUT", 30.0)
GEMINI_BASE_URL: str = os.getenv(
    "GEMINI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta"
)

# --- Performance Lab safety limits -----------------------------------------
LAB_MAX_CPU_WORKERS: int = _get_int("SENTINEL_LAB_MAX_CPU_WORKERS", 4)
LAB_MAX_CPU_SECONDS: int = _get_int("SENTINEL_LAB_MAX_CPU_SECONDS", 120)
LAB_MAX_MEMORY_MB: int = _get_int("SENTINEL_LAB_MAX_MEMORY_MB", 1024)
LAB_MAX_MEMORY_SECONDS: int = _get_int("SENTINEL_LAB_MAX_MEMORY_SECONDS", 120)


def gemini_configured() -> bool:
    """True when a Gemini API key is present in the backend environment."""
    return bool(GEMINI_API_KEY)

"""SQLite persistence layer (no ORM required at this scale).

Tables
------
anomaly_events   : every anomaly (and near-miss) raised by the ML engine
diagnostic_reports: AI / local-fallback diagnostic answers
metric_samples   : downsampled real metrics for trend analysis and forecasting
settings         : key/value user settings
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

from app import config

_lock = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS anomaly_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp REAL NOT NULL,
    detected_at TEXT NOT NULL,
    is_anomaly INTEGER NOT NULL DEFAULT 0,
    score REAL NOT NULL DEFAULT 0,
    severity TEXT NOT NULL DEFAULT 'info',
    metric TEXT NOT NULL,
    observed_value REAL NOT NULL DEFAULT 0,
    expected_low REAL NOT NULL DEFAULT 0,
    expected_high REAL NOT NULL DEFAULT 0,
    evidence TEXT NOT NULL DEFAULT '',
    explanation TEXT NOT NULL DEFAULT '',
    model TEXT NOT NULL DEFAULT '',
    features TEXT NOT NULL DEFAULT '{}',
    acknowledged INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_anomaly_ts ON anomaly_events(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_anomaly_sev ON anomaly_events(severity);

CREATE TABLE IF NOT EXISTS diagnostic_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp REAL NOT NULL,
    created_at TEXT NOT NULL,
    engine TEXT NOT NULL,
    model TEXT,
    question TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    evidence TEXT NOT NULL DEFAULT '[]',
    possible_causes TEXT NOT NULL DEFAULT '[]',
    confidence REAL NOT NULL DEFAULT 0,
    recommended_actions TEXT NOT NULL DEFAULT '[]',
    safety_considerations TEXT NOT NULL DEFAULT '[]',
    degraded INTEGER NOT NULL DEFAULT 0,
    notice TEXT,
    latency_ms REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_report_ts ON diagnostic_reports(timestamp DESC);

CREATE TABLE IF NOT EXISTS metric_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp REAL NOT NULL,
    cpu_percent REAL NOT NULL,
    memory_percent REAL NOT NULL,
    swap_percent REAL NOT NULL DEFAULT 0,
    disk_read_mb_s REAL NOT NULL DEFAULT 0,
    disk_write_mb_s REAL NOT NULL DEFAULT 0,
    net_upload_kb_s REAL NOT NULL DEFAULT 0,
    net_download_kb_s REAL NOT NULL DEFAULT 0,
    process_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_samples_ts ON metric_samples(timestamp DESC);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""


def _connect(db_path: Optional[Path] = None) -> sqlite3.Connection:
    path = Path(db_path) if db_path else config.DB_PATH
    conn = sqlite3.connect(path, timeout=10.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: Optional[Path] = None) -> None:
    """Create tables if they do not exist. Safe to call repeatedly."""
    with _lock:
        conn = _connect(db_path)
        try:
            conn.executescript(SCHEMA)
            conn.commit()
        finally:
            conn.close()


def reset_db(db_path: Optional[Path] = None) -> None:
    """Drop every table. Used by tests and the 'clear history' action."""
    with _lock:
        conn = _connect(db_path)
        try:
            conn.executescript(
                "DROP TABLE IF EXISTS anomaly_events;"
                "DROP TABLE IF EXISTS diagnostic_reports;"
                "DROP TABLE IF EXISTS metric_samples;"
                "DROP TABLE IF EXISTS settings;"
            )
            conn.commit()
        finally:
            conn.close()
        init_db(db_path)


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


# --- anomaly events ---------------------------------------------------------

def insert_anomaly(event: dict[str, Any], db_path: Optional[Path] = None) -> int:
    with _lock:
        conn = _connect(db_path)
        try:
            cur = conn.execute(
                """
                INSERT INTO anomaly_events (timestamp, detected_at, is_anomaly, score,
                    severity, metric, observed_value, expected_low, expected_high,
                    evidence, explanation, model, features, acknowledged)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    event.get("timestamp", time.time()),
                    event.get("detected_at", _now_iso()),
                    1 if event.get("is_anomaly") else 0,
                    float(event.get("score", 0.0)),
                    event.get("severity", "info"),
                    event.get("metric", "unknown"),
                    float(event.get("observed_value", 0.0)),
                    float(event.get("expected_low", 0.0)),
                    float(event.get("expected_high", 0.0)),
                    event.get("evidence", ""),
                    event.get("explanation", ""),
                    event.get("model", ""),
                    json.dumps(event.get("features", {})),
                    1 if event.get("acknowledged") else 0,
                ),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()


def fetch_anomalies(
    limit: int = 100,
    offset: int = 0,
    severity: Optional[str] = None,
    search: Optional[str] = None,
    since: Optional[float] = None,
    only_anomalies: bool = False,
    db_path: Optional[Path] = None,
) -> tuple[int, list[dict[str, Any]]]:
    where: list[str] = []
    params: list[Any] = []
    if severity and severity != "all":
        where.append("severity = ?")
        params.append(severity)
    if since is not None:
        where.append("timestamp >= ?")
        params.append(since)
    if only_anomalies:
        where.append("is_anomaly = 1")
    if search:
        where.append("(metric LIKE ? OR evidence LIKE ? OR explanation LIKE ?)")
        params.extend([f"%{search}%"] * 3)
    clause = f"WHERE {' AND '.join(where)}" if where else ""

    with _lock:
        conn = _connect(db_path)
        try:
            total = conn.execute(
                f"SELECT COUNT(*) AS c FROM anomaly_events {clause}", params
            ).fetchone()["c"]
            rows = conn.execute(
                f"SELECT * FROM anomaly_events {clause} ORDER BY timestamp DESC LIMIT ? OFFSET ?",
                [*params, limit, offset],
            ).fetchall()
        finally:
            conn.close()
    return int(total), [_anomaly_row_to_dict(r) for r in rows]


def acknowledge_anomaly(event_id: int, acknowledged: bool = True, db_path: Optional[Path] = None) -> bool:
    with _lock:
        conn = _connect(db_path)
        try:
            cur = conn.execute(
                "UPDATE anomaly_events SET acknowledged = ? WHERE id = ?",
                (1 if acknowledged else 0, event_id),
            )
            conn.commit()
            return cur.rowcount > 0
        finally:
            conn.close()


def delete_anomaly(event_id: int, db_path: Optional[Path] = None) -> bool:
    with _lock:
        conn = _connect(db_path)
        try:
            cur = conn.execute("DELETE FROM anomaly_events WHERE id = ?", (event_id,))
            conn.commit()
            return cur.rowcount > 0
        finally:
            conn.close()


def _anomaly_row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    d["is_anomaly"] = bool(d["is_anomaly"])
    d["acknowledged"] = int(d["acknowledged"])
    try:
        d["features"] = json.loads(d["features"] or "{}")
    except json.JSONDecodeError:
        d["features"] = {}
    d["expected_range"] = [d.pop("expected_low", 0.0), d.pop("expected_high", 0.0)]
    return d


# --- diagnostic reports -----------------------------------------------------

def insert_report(report: dict[str, Any], db_path: Optional[Path] = None) -> int:
    with _lock:
        conn = _connect(db_path)
        try:
            cur = conn.execute(
                """
                INSERT INTO diagnostic_reports (timestamp, created_at, engine, model, question,
                    summary, evidence, possible_causes, confidence, recommended_actions,
                    safety_considerations, degraded, notice, latency_ms)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    report.get("timestamp", time.time()),
                    report.get("created_at", _now_iso()),
                    report.get("engine", "local-fallback"),
                    report.get("model"),
                    report.get("question", ""),
                    report.get("summary", ""),
                    json.dumps(report.get("evidence", [])),
                    json.dumps(report.get("possible_causes", [])),
                    float(report.get("confidence", 0.0)),
                    json.dumps(report.get("recommended_actions", [])),
                    json.dumps(report.get("safety_considerations", [])),
                    1 if report.get("degraded") else 0,
                    report.get("notice"),
                    float(report.get("latency_ms", 0.0)),
                ),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()


def fetch_reports(
    limit: int = 50,
    offset: int = 0,
    search: Optional[str] = None,
    engine: Optional[str] = None,
    since: Optional[float] = None,
    db_path: Optional[Path] = None,
) -> tuple[int, list[dict[str, Any]]]:
    where: list[str] = []
    params: list[Any] = []
    if search:
        where.append("(question LIKE ? OR summary LIKE ?)")
        params.extend([f"%{search}%"] * 2)
    if engine and engine != "all":
        where.append("engine = ?")
        params.append(engine)
    if since is not None:
        where.append("timestamp >= ?")
        params.append(since)
    clause = f"WHERE {' AND '.join(where)}" if where else ""

    with _lock:
        conn = _connect(db_path)
        try:
            total = conn.execute(
                f"SELECT COUNT(*) AS c FROM diagnostic_reports {clause}", params
            ).fetchone()["c"]
            rows = conn.execute(
                f"SELECT * FROM diagnostic_reports {clause} ORDER BY timestamp DESC LIMIT ? OFFSET ?",
                [*params, limit, offset],
            ).fetchall()
        finally:
            conn.close()
    return int(total), [_report_row_to_dict(r) for r in rows]


def get_report(report_id: int, db_path: Optional[Path] = None) -> Optional[dict[str, Any]]:
    with _lock:
        conn = _connect(db_path)
        try:
            row = conn.execute(
                "SELECT * FROM diagnostic_reports WHERE id = ?", (report_id,)
            ).fetchone()
        finally:
            conn.close()
    return _report_row_to_dict(row) if row else None


def _report_row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    for key in ("evidence", "possible_causes", "recommended_actions", "safety_considerations"):
        try:
            d[key] = json.loads(d[key] or "[]")
        except json.JSONDecodeError:
            d[key] = []
    d["degraded"] = bool(d["degraded"])
    return d


def insert_samples(samples: Iterable[dict[str, Any]], db_path: Optional[Path] = None) -> int:
    rows = [
        (
            s["timestamp"],
            s.get("cpu_percent", 0.0),
            s.get("memory_percent", 0.0),
            s.get("swap_percent", 0.0),
            s.get("disk_read_mb_s", 0.0),
            s.get("disk_write_mb_s", 0.0),
            s.get("net_upload_kb_s", 0.0),
            s.get("net_download_kb_s", 0.0),
            int(s.get("process_count", 0)),
        )
        for s in samples
    ]
    if not rows:
        return 0
    with _lock:
        conn = _connect(db_path)
        try:
            conn.executemany(
                """
                INSERT INTO metric_samples (timestamp, cpu_percent, memory_percent, swap_percent,
                    disk_read_mb_s, disk_write_mb_s, net_upload_kb_s, net_download_kb_s, process_count)
                VALUES (?,?,?,?,?,?,?,?,?)
                """,
                rows,
            )
            conn.commit()
            return len(rows)
        finally:
            conn.close()


def fetch_samples(
    limit: int = 600, since: Optional[float] = None, db_path: Optional[Path] = None
) -> list[dict[str, Any]]:
    with _lock:
        conn = _connect(db_path)
        try:
            if since is not None:
                rows = conn.execute(
                    "SELECT * FROM metric_samples WHERE timestamp >= ? ORDER BY timestamp ASC LIMIT ?",
                    (since, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM metric_samples ORDER BY timestamp DESC LIMIT ?", (limit,)
                ).fetchall()
                rows = list(reversed(rows))
        finally:
            conn.close()
    return [dict(r) for r in rows]


# --- settings ---------------------------------------------------------------

DEFAULT_SETTINGS: dict[str, Any] = {
    "sample_interval": config.SAMPLE_INTERVAL,
    "sensitivity": 0.5,
    "retention_days": config.RETENTION_DAYS,
    "demo_mode": False,
}


def get_settings(db_path: Optional[Path] = None) -> dict[str, Any]:
    values = dict(DEFAULT_SETTINGS)
    with _lock:
        conn = _connect(db_path)
        try:
            for row in conn.execute("SELECT key, value FROM settings"):
                try:
                    values[row["key"]] = json.loads(row["value"])
                except json.JSONDecodeError:
                    values[row["key"]] = row["value"]
        finally:
            conn.close()
    return values


def set_setting(key: str, value: Any, db_path: Optional[Path] = None) -> None:
    with _lock:
        conn = _connect(db_path)
        try:
            conn.execute(
                "INSERT INTO settings (key, value, updated_at) VALUES (?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                (key, json.dumps(value), _now_iso()),
            )
            conn.commit()
        finally:
            conn.close()


def apply_retention(retention_days: Optional[int] = None, db_path: Optional[Path] = None) -> dict[str, int]:
    """Delete rows older than the retention window and cap table sizes."""
    days = retention_days or config.RETENTION_DAYS
    cutoff = time.time() - timedelta(days=days).total_seconds()
    removed: dict[str, int] = {}
    with _lock:
        conn = _connect(db_path)
        try:
            for table in ("anomaly_events", "diagnostic_reports", "metric_samples"):
                cur = conn.execute(f"DELETE FROM {table} WHERE timestamp < ?", (cutoff,))
                removed[table] = cur.rowcount if cur.rowcount is not None else 0
            # cap oversized tables anyway
            for table, cap in (
                ("anomaly_events", config.MAX_ANOMALY_ROWS),
                ("diagnostic_reports", config.MAX_REPORT_ROWS),
            ):
                cur = conn.execute(
                    f"DELETE FROM {table} WHERE id NOT IN "
                    f"(SELECT id FROM {table} ORDER BY timestamp DESC LIMIT ?)",
                    (cap,),
                )
                removed[table] = removed.get(table, 0) + (cur.rowcount or 0)
            conn.commit()
        finally:
            conn.close()
    return removed


def clear_table(table: str, db_path: Optional[Path] = None) -> int:
    if table not in {"anomaly_events", "diagnostic_reports", "metric_samples"}:
        raise ValueError(f"unknown table: {table}")
    with _lock:
        conn = _connect(db_path)
        try:
            cur = conn.execute(f"DELETE FROM {table}")
            conn.commit()
            return cur.rowcount or 0
        finally:
            conn.close()


def stats(db_path: Optional[Path] = None) -> dict[str, Any]:
    with _lock:
        conn = _connect(db_path)
        try:
            out: dict[str, Any] = {}
            for table in ("anomaly_events", "diagnostic_reports", "metric_samples"):
                out[table] = conn.execute(f"SELECT COUNT(*) AS c FROM {table}").fetchone()["c"]
            row = conn.execute("SELECT MIN(timestamp) AS a, MAX(timestamp) AS b FROM metric_samples").fetchone()
            out["oldest_sample"] = row["a"]
            out["newest_sample"] = row["b"]
        finally:
            conn.close()
    out["db_path"] = str(db_path or config.DB_PATH)
    return out

"""Pydantic schemas shared across the SENTINEL OS API."""

from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

Severity = Literal["info", "low", "medium", "high", "critical"]


class CpuMetrics(BaseModel):
    percent: float
    per_core: list[float] = Field(default_factory=list)
    core_count_logical: int = 0
    core_count_physical: int = 0
    frequency_mhz: Optional[float] = None
    load_avg: Optional[list[float]] = None


class MemoryMetrics(BaseModel):
    total_mb: float
    used_mb: float
    available_mb: float
    percent: float
    swap_total_mb: float
    swap_used_mb: float
    swap_percent: float


class DiskPartition(BaseModel):
    device: str
    mountpoint: str
    fstype: str
    total_gb: float
    used_gb: float
    free_gb: float
    percent: float


class DiskMetrics(BaseModel):
    read_mb_s: float
    write_mb_s: float
    read_mb_total: float
    write_mb_total: float
    partitions: list[DiskPartition] = Field(default_factory=list)


class NetworkMetrics(BaseModel):
    upload_kb_s: float
    download_kb_s: float
    bytes_sent_mb: float
    bytes_recv_mb: float
    packets_sent: int = 0
    packets_recv: int = 0


class SystemInfo(BaseModel):
    hostname: str
    platform: str
    platform_release: str
    platform_version: str
    architecture: str
    processor: str
    python_version: str
    boot_time: float
    uptime_seconds: float
    user: str
    is_admin: bool = False


class MetricSample(BaseModel):
    """A single point in the metrics time-series."""

    timestamp: float
    cpu_percent: float
    memory_percent: float
    swap_percent: float
    disk_read_mb_s: float
    disk_write_mb_s: float
    net_upload_kb_s: float
    net_download_kb_s: float
    process_count: int


class SystemSummary(BaseModel):
    source: Literal["live", "demo"]
    timestamp: float
    cpu: CpuMetrics
    memory: MemoryMetrics
    disk: DiskMetrics
    network: NetworkMetrics
    system: SystemInfo
    process_count: int
    health: "HealthReport"


class HealthReport(BaseModel):
    score: int
    status: Literal["optimal", "good", "fair", "degraded", "critical"]
    reasons: list[str] = Field(default_factory=list)
    partial_data: bool = False


class ProcessInfo(BaseModel):
    pid: int
    name: str
    username: Optional[str] = None
    status: Optional[str] = None
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    memory_mb: float = 0.0
    num_threads: Optional[int] = None
    create_time: Optional[float] = None
    exe: Optional[str] = None
    cmdline: Optional[str] = None


class ProcessListResponse(BaseModel):
    timestamp: float
    total: int
    returned: int
    processes: list[ProcessInfo]


class AnomalyEvent(BaseModel):
    id: Optional[int] = None
    timestamp: float
    detected_at: str
    is_anomaly: bool
    score: float
    severity: Severity
    metric: str
    observed_value: float
    expected_range: list[float]
    evidence: str
    explanation: str
    model: str
    acknowledged: int = 0
    features: dict[str, float] = Field(default_factory=dict)


class AnomalyStatus(BaseModel):
    enabled: bool
    model_ready: bool
    mode: Literal["unsupervised-learning", "rule-based-cold-start", "disabled"]
    trained_samples: int
    trained_at: Optional[str] = None
    training_source: str
    sensitivity: float
    contamination: float
    last_score: Optional[float] = None
    last_severity: Optional[Severity] = None
    is_anomaly: bool = False
    recent_events: list[AnomalyEvent] = Field(default_factory=list)


class Recommendation(BaseModel):
    id: str
    severity: Severity
    trigger: str
    evidence: str
    explanation: str
    suggested_action: str
    risk: str
    verification: str
    read_only: bool = True


class RecommendationResponse(BaseModel):
    timestamp: float
    count: int
    items: list[Recommendation]


class DiagnosticReport(BaseModel):
    id: Optional[int] = None
    created_at: str
    timestamp: float
    engine: Literal["gemini", "local-fallback"]
    model: Optional[str] = None
    question: str
    summary: str
    evidence: list[str] = Field(default_factory=list)
    possible_causes: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    recommended_actions: list[str] = Field(default_factory=list)
    safety_considerations: list[str] = Field(default_factory=list)
    degraded: bool = False
    notice: Optional[str] = None
    latency_ms: float = 0.0


class DoctorRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    include_history: bool = True


class DoctorResponse(BaseModel):
    report: DiagnosticReport
    engine: Literal["gemini", "local-fallback"]
    gemini_configured: bool


class ExperimentRequest(BaseModel):
    kind: Literal["cpu", "memory"]
    workers: int = Field(default=2, ge=1, le=8)
    duration_seconds: int = Field(default=15, ge=3, le=120)
    memory_mb: int = Field(default=256, ge=64, le=2048)
    confirmed: bool = Field(default=False)


class ExperimentStatus(BaseModel):
    id: Optional[str] = None
    kind: Optional[str] = None
    running: bool = False
    started_at: Optional[str] = None
    started_ts: Optional[float] = None
    duration_seconds: int = 0
    seconds_remaining: float = 0.0
    workers: int = 0
    memory_mb: int = 0
    baseline: dict[str, float] = Field(default_factory=dict)
    peak: dict[str, float] = Field(default_factory=dict)
    current: dict[str, float] = Field(default_factory=dict)
    recovery: Optional[dict[str, float]] = None
    samples: int = 0
    message: str = ""


class ForecastPoint(BaseModel):
    timestamp: float
    value: float
    kind: Literal["actual", "predicted"]


class ForecastSeries(BaseModel):
    metric: str
    unit: str
    horizon: int
    history: list[ForecastPoint] = Field(default_factory=list)
    forecast: list[ForecastPoint] = Field(default_factory=list)
    slope_per_minute: float = 0.0
    confidence: float = 0.0
    method: str
    sufficient_data: bool
    message: str = ""
    error: Optional[dict[str, float]] = None


class ForecastResponse(BaseModel):
    generated_at: str
    available_samples: int
    required_samples: int
    series: list[ForecastSeries] = Field(default_factory=list)


class HistoryQueryResult(BaseModel):
    total: int
    limit: int
    offset: int
    items: list[dict[str, Any]]


class SettingsPayload(BaseModel):
    sample_interval: float = Field(ge=0.5, le=30)
    sensitivity: float = Field(ge=0.0, le=1.0)
    retention_days: int = Field(ge=1, le=365)
    demo_mode: bool = False


SystemSummary.model_rebuild()

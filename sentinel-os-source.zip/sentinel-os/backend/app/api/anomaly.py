"""ML anomaly detection endpoints."""

from __future__ import annotations

import time
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app import config
from app.database import db
from app.ml.anomaly import FEATURES, anomaly_engine
from app.services.monitor import monitor
from app.services.orchestrator import orchestrator

router = APIRouter(prefix="/anomaly", tags=["anomaly"])


class SensitivityPayload(BaseModel):
    value: float = Field(ge=0.0, le=1.0, description="0 = least sensitive, 1 = most sensitive")


class EnabledPayload(BaseModel):
    enabled: bool


@router.get("/status")
def status(limit: int = Query(default=10, ge=0, le=40)) -> dict[str, Any]:
    data = anomaly_engine.status()
    data["features"] = FEATURES
    data["recent_events"] = orchestrator.recent_anomaly_payloads(limit=limit)
    data["current_metrics"] = {
        "cpu_percent": monitor.cpu_metrics()["percent"],
        "memory_percent": monitor.memory_metrics()["percent"],
        "swap_percent": monitor.memory_metrics()["swap_percent"],
        "process_count": monitor.process_count,
    }
    data["last_features"] = anomaly_engine.last_features
    return data


@router.get("/events")
def events(
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    severity: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None, max_length=120),
    since: Optional[float] = Query(default=None),
    only_anomalies: bool = Query(default=False),
) -> dict[str, Any]:
    total, rows = db.fetch_anomalies(
        limit=limit, offset=offset, severity=severity, search=search, since=since, only_anomalies=only_anomalies
    )
    return {"total": total, "limit": limit, "offset": offset, "items": rows}


@router.post("/events/{event_id}/acknowledge")
def acknowledge(event_id: int, acknowledged: bool = True) -> dict[str, Any]:
    ok = db.acknowledge_anomaly(event_id, acknowledged)
    if not ok:
        raise HTTPException(status_code=404, detail=f"anomaly event {event_id} not found")
    return {"id": event_id, "acknowledged": acknowledged}


@router.delete("/events/{event_id}")
def delete_event(event_id: int) -> dict[str, Any]:
    ok = db.delete_anomaly(event_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"anomaly event {event_id} not found")
    return {"id": event_id, "deleted": True}


@router.post("/train")
def train(include_history: bool = Query(default=True)) -> dict[str, Any]:
    """(Re)train the Isolation Forest on the synthetic baseline + real history."""
    samples = db.fetch_samples(limit=1200) if include_history else []
    samples = samples or [dict(s) for s in orchestrator.recent_samples]
    try:
        if samples and len(samples) >= config.ML_MIN_TRAIN_SAMPLES:
            import numpy as np

            from app.ml.anomaly import synthetic_baseline

            real = anomaly_engine._samples_to_matrix(samples)
            baseline = synthetic_baseline(n=max(400, len(real)))
            result = anomaly_engine.train(
                np.vstack([baseline, real]), source="synthetic-baseline+real-history", persist=True
            )
        else:
            result = anomaly_engine.train_cold_start()
            result["note"] = (
                f"Only {len(samples)} real samples available (minimum {config.ML_MIN_TRAIN_SAMPLES}); "
                "trained on the labelled synthetic healthy baseline instead."
            )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    result["timestamp"] = time.time()
    return result


@router.post("/sensitivity")
def set_sensitivity(payload: SensitivityPayload) -> dict[str, Any]:
    anomaly_engine.set_sensitivity(payload.value)
    db.set_setting("sensitivity", payload.value)
    # Re-train so the contamination parameter actually takes effect.
    try:
        samples = db.fetch_samples(limit=1200)
        import numpy as np

        from app.ml.anomaly import synthetic_baseline

        if samples and len(samples) >= 10:
            real = anomaly_engine._samples_to_matrix(samples)
            anomaly_engine.train(
                np.vstack([synthetic_baseline(n=max(400, len(real))), real]),
                source="synthetic-baseline+real-history",
                persist=True,
            )
        else:
            anomaly_engine.train_cold_start()
    except Exception:
        pass
    return {"sensitivity": payload.value, "contamination": anomaly_engine.contamination}


@router.post("/enabled")
def set_enabled(payload: EnabledPayload) -> dict[str, Any]:
    anomaly_engine.enabled = payload.enabled
    return {"enabled": anomaly_engine.enabled}


@router.post("/evaluate")
def evaluate_now() -> dict[str, Any]:
    """Score the current instantaneous state (does not wait for the next tick)."""
    sample = monitor.collect_sample()
    result = anomaly_engine.evaluate(sample)
    if result["is_anomaly"]:
        result["id"] = db.insert_anomaly(result)
        orchestrator.recent_anomalies.append(result)
    return result

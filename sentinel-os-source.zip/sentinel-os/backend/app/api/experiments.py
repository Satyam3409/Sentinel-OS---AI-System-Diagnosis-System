"""Performance Lab endpoints - bounded stress experiments with safety rails."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException

from app import config
from app.schemas.models import ExperimentRequest
from app.services.experiments import experiment_manager

router = APIRouter(prefix="/lab", tags=["performance-lab"])


@router.get("/limits")
def limits() -> dict[str, Any]:
    status = experiment_manager.status()
    return {
        "limits": status["limits"],
        "safety": {
            "requires_confirmation": True,
            "automatic_timeout": True,
            "max_concurrent_experiments": 1,
            "never_exhausts_ram": True,
            "memory_cap_rule": "Allocation is capped at 25% of currently available RAM and never above the configured ceiling.",
            "cleanup": "All experiment threads are daemon threads and buffers are released on timeout or stop.",
        },
        "current": status,
    }


@router.get("/status")
def status() -> dict[str, Any]:
    return experiment_manager.status()


@router.post("/start")
def start(payload: ExperimentRequest) -> dict[str, Any]:
    try:
        return experiment_manager.start(
            kind=payload.kind,
            workers=payload.workers,
            duration=payload.duration_seconds,
            memory_mb=payload.memory_mb,
            confirmed=payload.confirmed,
        )
    except PermissionError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/stop")
def stop() -> dict[str, Any]:
    try:
        return experiment_manager.stop("stopped by user")
    except RuntimeError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/compare")
def compare() -> dict[str, Any]:
    """Baseline vs peak vs recovery comparison for the last/current experiment."""
    status_data = experiment_manager.status()
    baseline = status_data.get("baseline") or {}
    peak = status_data.get("peak") or {}
    recovery = status_data.get("recovery") or {}
    deltas: dict[str, float] = {}
    for key, base_value in baseline.items():
        peak_value = peak.get(key)
        if peak_value is not None:
            deltas[key] = round(peak_value - base_value, 2)
    return {
        "experiment": status_data,
        "baseline": baseline,
        "peak": peak,
        "recovery": recovery,
        "delta_peak_vs_baseline": deltas,
        "recovered": bool(recovery)
        and abs((recovery.get("cpu_percent", 0) - baseline.get("cpu_percent", 0))) < 25,
        "note": "All values are measured from the local monitoring agent.",
    }


@router.post("/cleanup")
def cleanup() -> dict[str, Any]:
    experiment_manager.cleanup()
    return {"cleaned": True, "status": experiment_manager.status()}


@router.get("/config")
def lab_config() -> dict[str, Any]:
    return {
        "max_cpu_workers": config.LAB_MAX_CPU_WORKERS,
        "max_cpu_seconds": config.LAB_MAX_CPU_SECONDS,
        "max_memory_mb": config.LAB_MAX_MEMORY_MB,
        "max_memory_seconds": config.LAB_MAX_MEMORY_SECONDS,
    }

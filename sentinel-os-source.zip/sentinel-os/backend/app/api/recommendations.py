"""Smart, evidence-based recommendations (read-only)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from app.services.recommendations import build_recommendations

router = APIRouter(tags=["recommendations"])


@router.get("/recommendations")
def recommendations() -> dict[str, Any]:
    return build_recommendations()

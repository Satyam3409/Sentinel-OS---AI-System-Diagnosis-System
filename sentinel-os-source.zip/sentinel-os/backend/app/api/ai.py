"""SENTINEL AI DOCTOR endpoints (Gemini with local fallback)."""

from __future__ import annotations

import time
from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app import config
from app.database import db
from app.schemas.models import DoctorRequest
from app.services import ai_doctor

router = APIRouter(prefix="/ai", tags=["ai"])


SUGGESTED_QUESTIONS = [
    "Diagnose my PC.",
    "Why is my PC slow?",
    "Why is RAM usage high?",
    "Which process consumes the most CPU?",
    "Explain this anomaly.",
    "How can I improve my system performance?",
    "Analyze recent system activity.",
]


class SettingsUpdateRequest(BaseModel):
    question_style: Optional[str] = Field(default=None, description="Reserved for future prompt tuning")


@router.get("/status")
def status() -> dict[str, Any]:
    return {
        "assistant": "SENTINEL AI DOCTOR",
        "engine": "gemini" if config.gemini_configured() else "local-fallback",
        "gemini_configured": config.gemini_configured(),
        "gemini_model": config.GEMINI_MODEL if config.gemini_configured() else None,
        "gemini_timeout_seconds": config.GEMINI_TIMEOUT,
        "fallback_available": True,
        "suggested_questions": SUGGESTED_QUESTIONS,
        "safety": {
            "api_key_location": "backend environment variable GEMINI_API_KEY (never sent to the browser)",
            "executes_commands": False,
            "read_only": True,
        },
    }


@router.post("/doctor")
async def doctor(payload: DoctorRequest) -> dict[str, Any]:
    """Ask the AI Doctor a question grounded in live measured telemetry."""
    try:
        report = await ai_doctor.diagnose(payload.question, include_history=payload.include_history)
    except Exception as exc:
        # The local engine should always succeed; a failure here is a real bug.
        raise HTTPException(status_code=500, detail=f"diagnostic engine failed: {exc}") from exc
    try:
        report["id"] = db.insert_report(report)
    except Exception:
        report["id"] = None
    return {
        "report": report,
        "engine": report["engine"],
        "gemini_configured": config.gemini_configured(),
    }


@router.get("/reports")
def reports(
    limit: int = Query(default=25, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    search: Optional[str] = Query(default=None, max_length=120),
    engine: Optional[str] = Query(default=None),
) -> dict[str, Any]:
    total, rows = db.fetch_reports(limit=limit, offset=offset, search=search, engine=engine)
    return {"total": total, "limit": limit, "offset": offset, "items": rows}


@router.get("/reports/{report_id}")
def report_detail(report_id: int) -> dict[str, Any]:
    match = db.get_report(report_id)
    if match is None:
        raise HTTPException(status_code=404, detail=f"report {report_id} not found")
    return match


@router.post("/diagnose/quick")
def quick_diagnosis(kind: str = Query(default="full", pattern="^(full|cpu|memory|disk|process)$")) -> dict[str, Any]:
    """Synchronous local-only diagnosis - always available, even with no API key."""
    questions = {
        "full": "Diagnose my PC.",
        "cpu": "Why is my CPU usage high?",
        "memory": "Why is RAM usage high?",
        "disk": "Is my disk performance healthy?",
        "process": "Which process consumes the most CPU?",
    }
    telemetry = ai_doctor._collect_telemetry()
    report = ai_doctor.local_diagnostic(questions[kind], telemetry, reason="local quick diagnosis")
    report.update(
        {
            "timestamp": time.time(),
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "engine": "local-fallback",
            "model": None,
            "question": questions[kind],
            "degraded": True,
            "notice": "Local rule-based quick diagnosis (no external AI call).",
            "latency_ms": 0.0,
        }
    )
    return {"report": report, "engine": "local-fallback"}

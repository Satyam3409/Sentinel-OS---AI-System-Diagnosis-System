"""System monitoring endpoints (all data is measured from the local agent)."""

from __future__ import annotations

import time
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query

from app import config
from app.database import db
from app.services.monitor import monitor
from app.services.orchestrator import orchestrator

router = APIRouter(tags=["system"])


@router.get("/health")
def health() -> dict[str, Any]:
    """Liveness + readiness probe. Never requires privileged access."""
    return {
        "status": "ok" if monitor.running else "degraded",
        "service": config.APP_NAME,
        "version": config.APP_VERSION,
        "agent": {
            "monitoring": monitor.running,
            "sample_interval_seconds": monitor.sample_interval,
            "samples_collected": monitor.samples_collected,
            "ticks": orchestrator.ticks,
            "last_tick": orchestrator.last_tick,
            "history_points": len(monitor.history),
            "websocket_subscribers": orchestrator.current_status()["subscribers"],
            "last_error": monitor.last_error,
            "warnings": monitor.warnings,
        },
        "database": db.stats(),
        "gemini_configured": config.gemini_configured(),
        "server_time": time.time(),
    }


@router.get("/system/summary")
def system_summary() -> dict[str, Any]:
    """Full measured snapshot of the machine plus a health verdict."""
    try:
        summary = monitor.get_summary()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"metric collection failed: {exc}") from exc
    summary["agent"] = orchestrator.current_status()
    summary["data_warnings"] = monitor.warnings
    return summary


@router.get("/system/history")
def system_history(
    limit: int = Query(default=120, ge=1, le=config.HISTORY_MAX_POINTS),
    since: Optional[float] = Query(default=None),
    metric: Optional[str] = Query(default="all"),
    source: str = Query(default="memory", pattern="^(memory|database)$"),
) -> dict[str, Any]:
    """Time-series history. `source=database` reads the persisted samples."""
    if source == "database":
        rows = db.fetch_samples(limit=limit, since=since)
        if metric and metric != "all":
            points = [{"timestamp": r["timestamp"], "value": r.get(metric, 0.0)} for r in rows]
            return {"metric": metric, "source": "database", "count": len(points), "points": points}
        return {"metric": "all", "source": "database", "count": len(rows), "points": rows}
    data = monitor.get_history(limit=limit, since=since, metric=metric)
    data["source"] = "memory"
    return data


@router.get("/system/disks")
def system_disks() -> dict[str, Any]:
    disk = monitor.disk_metrics()
    return {"timestamp": time.time(), **disk}


@router.get("/system/network")
def system_network() -> dict[str, Any]:
    net = monitor.network_metrics()
    return {"timestamp": time.time(), **net}


@router.get("/system/info")
def system_info() -> dict[str, Any]:
    return monitor.system_info()


@router.get("/system/health")
def system_health() -> dict[str, Any]:
    summary = monitor.get_summary()
    return {**summary["health"], "timestamp": summary["timestamp"], "process_count": summary["process_count"]}


@router.get("/system/top")
def system_top(
    limit: int = Query(default=5, ge=1, le=25),
    by: str = Query(default="cpu", pattern="^(cpu|memory)$"),
) -> dict[str, Any]:
    from app.services.processes import top_processes

    return {"by": by, "items": top_processes(limit=limit, by=by)}

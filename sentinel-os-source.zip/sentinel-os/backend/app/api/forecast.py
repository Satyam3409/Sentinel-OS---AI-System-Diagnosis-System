"""Short-term forecasting endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Query

from app.database import db
from app.services.forecast import MIN_SAMPLES, build_forecast

router = APIRouter(tags=["forecast"])


@router.get("/forecast")
def forecast(
    horizon: int = Query(default=10, ge=1, le=60),
    source: str = Query(default="database", pattern="^(database|memory)$"),
) -> dict[str, Any]:
    """Forecast CPU and memory. Returns an explicit refusal when data is insufficient."""
    if source == "memory":
        from app.services.orchestrator import orchestrator

        samples = [dict(s) for s in orchestrator.recent_samples]
    else:
        samples = db.fetch_samples(limit=600)
        if len(samples) < MIN_SAMPLES:
            # Fall back to the in-memory ring buffer so the feature is usable
            # immediately after start-up, while remaining real measured data.
            from app.services.orchestrator import orchestrator

            samples = [dict(s) for s in orchestrator.recent_samples]
    return build_forecast(samples, horizon=horizon)

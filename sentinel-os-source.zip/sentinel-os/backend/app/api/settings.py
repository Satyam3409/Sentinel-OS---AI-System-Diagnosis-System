"""Settings and About endpoints."""

from __future__ import annotations

import platform
import time
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app import config
from app.database import db
from app.ml.anomaly import anomaly_engine
from app.services.monitor import monitor
from app.services.orchestrator import orchestrator

router = APIRouter(tags=["settings"])


class SettingsPayload(BaseModel):
    sample_interval: float = Field(ge=0.5, le=30, description="Monitoring interval in seconds")
    sensitivity: float = Field(ge=0.0, le=1.0, description="Anomaly detection sensitivity")
    retention_days: int = Field(ge=1, le=365, description="History retention window in days")
    data_source: str = Field(default="live", pattern="^(live|demo)$")


@router.get("/settings")
def get_settings() -> dict[str, Any]:
    values = db.get_settings()
    return {
        "settings": values,
        "effective": {
            "sample_interval_seconds": monitor.sample_interval,
            "anomaly_sensitivity": anomaly_engine.sensitivity,
            "anomaly_enabled": anomaly_engine.enabled,
            "retention_days": values.get("retention_days", config.RETENTION_DAYS),
        },
        "api_configuration": {
            "gemini_configured": config.gemini_configured(),
            "gemini_model": config.GEMINI_MODEL,
            "gemini_env_var": "GEMINI_API_KEY",
            "api_key_exposure": "The key is read only by the backend process and is never returned to the browser.",
            "how_to_enable": [
                "Create a file named .env inside sentinel-os/backend/ (copy .env.example).",
                "Add the line: GEMINI_API_KEY=your_actual_key",
                "Restart the backend. GET /api/ai/status will then report engine=gemini.",
                "If the variable is absent, SENTINEL AI DOCTOR automatically uses its offline rule-based engine.",
            ],
        },
        "server": {
            "host": config.HOST,
            "port": config.PORT,
            "allowed_origins": config.ALLOWED_ORIGINS,
            "data_dir": str(config.DATA_DIR),
        },
        "can_apply_at_runtime": {
            "sample_interval": True,
            "sensitivity": True,
            "retention_days": True,
            "note": "Sample interval changes take effect on the next monitoring tick.",
        },
    }


@router.put("/settings")
def update_settings(payload: SettingsPayload) -> dict[str, Any]:
    db.set_setting("sample_interval", payload.sample_interval)
    db.set_setting("sensitivity", payload.sensitivity)
    db.set_setting("retention_days", payload.retention_days)
    db.set_setting("demo_mode", payload.data_source == "demo")

    monitor.sample_interval = payload.sample_interval
    anomaly_engine.set_sensitivity(payload.sensitivity)
    try:
        db.apply_retention(payload.retention_days)
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=500, detail=f"retention failed: {exc}") from exc
    return get_settings()


@router.get("/about")
def about() -> dict[str, Any]:
    return {
        "application": config.APP_NAME,
        "full_name": "AI-Powered System Intelligence & Diagnostics Platform",
        "version": config.APP_VERSION,
        "purpose": "B.Tech AIML, 5th Semester, Operating Systems Project-Based Learning",
        "category": "Operating Systems + Artificial Intelligence + Machine Learning",
        "target_os": "Windows 10 / 11",
        "host_platform": platform.platform(),
        "architecture": {
            "frontend": ["React", "TypeScript", "Vite", "Tailwind CSS", "Recharts", "Lucide React"],
            "backend": ["Python", "FastAPI", "Uvicorn", "Pydantic", "psutil"],
            "ml": ["scikit-learn", "IsolationForest", "NumPy"],
            "ai": ["Google Gemini API (backend-only key)", "local rule-based fallback"],
            "database": ["SQLite"],
            "transport": ["REST", "WebSocket"],
        },
        "capabilities": [
            "Real Windows resource monitoring via psutil",
            "Live dashboard over WebSocket",
            "Read-only process explorer",
            "Isolation Forest anomaly detection with cold-start handling",
            "Gemini-backed AI System Doctor with offline fallback",
            "Evidence-based smart recommendations",
            "SQLite diagnostic history with CSV/JSON export",
            "Bounded performance experiments with automatic timeout",
            "Short-term CPU/RAM forecasting",
        ],
        "limitations": [
            "Most per-process metrics from SYSTEM-owned processes require elevated privileges; unavailable fields degrade gracefully.",
            "Anomaly detection measures unusual resource behaviour. It is not a malware detector.",
            "A cloud-hosted preview cannot access local Windows metrics - the agent must run on the monitored machine.",
        ],
        "disclaimer": (
            "SENTINEL OS is a monitoring and diagnostics tool. It does not replace the operating system, "
            "does not modify system configuration, does not terminate processes, and does not delete files."
        ),
        "status": {
            "agent": orchestrator.current_status(),
            "model": anomaly_engine.status(),
            "generated_at": time.time(),
        },
    }

"""WebSocket endpoints for real-time monitoring.

`/ws/metrics`   - pushes a full metric frame every monitoring tick (2s default)
`/ws/processes` - pushes a process table snapshot on a slower cadence
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.services.monitor import monitor
from app.services.orchestrator import orchestrator
from app.services.processes import collect_processes

router = APIRouter(tags=["websocket"])


@router.websocket("/ws/metrics")
async def ws_metrics(websocket: WebSocket) -> None:
    await websocket.accept()
    queue = await orchestrator.subscribe()
    try:
        # Send an immediate frame so the UI is populated without waiting a tick.
        await websocket.send_text(
            json.dumps(
                {
                    "type": "hello",
                    "message": "connected to SENTINEL OS monitoring agent",
                    "sample_interval": monitor.sample_interval,
                    "agent": orchestrator.current_status(),
                }
            )
        )
        if orchestrator.last_tick is None:
            await websocket.send_text(
                json.dumps(
                    {
                        "type": "metrics",
                        "timestamp": time.time(),
                        "summary": None,
                        "note": "waiting for the first monitoring tick",
                    }
                )
            )
        while True:
            try:
                payload = await asyncio.wait_for(queue.get(), timeout=15.0)
            except asyncio.TimeoutError:
                # Heartbeat keeps proxies and browsers from closing idle sockets.
                await websocket.send_text(json.dumps({"type": "heartbeat", "agent": orchestrator.current_status()}))
                continue
            await websocket.send_text(json.dumps(payload, default=str))
    except WebSocketDisconnect:
        pass
    except Exception:
        try:
            await websocket.close()
        except Exception:
            pass
    finally:
        await orchestrator.unsubscribe(queue)


@router.websocket("/ws/processes")
async def ws_processes(websocket: WebSocket) -> None:
    await websocket.accept()
    try:
        await websocket.send_text(json.dumps({"type": "hello", "message": "process stream ready"}))
        while True:
            sort = websocket.query_params.get("sort", "cpu")
            data = collect_processes(limit=120, sort=sort)
            await websocket.send_text(
                json.dumps({"type": "processes", "timestamp": data["timestamp"], "processes": data["processes"]}, default=str)
            )
            await asyncio.sleep(max(2.0, monitor.sample_interval))
    except WebSocketDisconnect:
        pass
    except Exception:
        try:
            await websocket.close()
        except Exception:
            pass


@router.get("/ws/status")
def ws_status() -> dict[str, Any]:
    return orchestrator.current_status()

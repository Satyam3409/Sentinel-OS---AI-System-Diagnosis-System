"""Process Explorer endpoints. Strictly read-only - no termination is exposed."""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query

from app import config
from app.services.processes import collect_processes, get_process_detail

router = APIRouter(tags=["processes"])


@router.get("/processes")
def list_processes(
    limit: int = Query(default=config.PROCESS_LIMIT, ge=1, le=1000),
    sort: str = Query(default="cpu", pattern="^(cpu|memory|name|pid)$"),
    search: Optional[str] = Query(default=None, max_length=120),
    status: Optional[str] = Query(default=None, max_length=30),
) -> dict[str, Any]:
    """List running processes. Read-only: SENTINEL OS never terminates processes."""
    try:
        return collect_processes(limit=limit, sort=sort, search=search, status=status)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"process enumeration failed: {exc}") from exc


@router.get("/processes/{pid}")
def process_detail(pid: int) -> dict[str, Any]:
    if pid <= 0:
        raise HTTPException(status_code=400, detail="pid must be a positive integer")
    detail = get_process_detail(pid)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"process {pid} is no longer running")
    return detail

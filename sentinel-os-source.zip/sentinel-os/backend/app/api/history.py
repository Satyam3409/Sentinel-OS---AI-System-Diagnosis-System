"""Diagnostic history: storage, search, filtering, export and retention."""

from __future__ import annotations

import csv
import io
import json
import time
from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import PlainTextResponse, Response

from app import config
from app.database import db

router = APIRouter(prefix="/history", tags=["history"])

DAY = 86400.0


def _since_from_range(range_key: Optional[str]) -> Optional[float]:
    now = time.time()
    mapping = {"1h": 3600.0, "24h": DAY, "7d": 7 * DAY, "30d": 30 * DAY}
    if not range_key or range_key == "all":
        return None
    return now - mapping.get(range_key, 30 * DAY)


@router.get("/stats")
def stats() -> dict[str, Any]:
    data = db.stats()
    settings = db.get_settings()
    data["retention_days"] = settings.get("retention_days", config.RETENTION_DAYS)
    return data


@router.get("/events")
def history(
    kind: str = Query(default="all", pattern="^(all|anomaly|report)$"),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    severity: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None, max_length=120),
    range_key: Optional[str] = Query(default="all", alias="range"),
    engine: Optional[str] = Query(default=None),
) -> dict[str, Any]:
    """Unified, filtered history view over anomaly events and diagnostic reports."""
    since = _since_from_range(range_key)
    items: list[dict[str, Any]] = []
    total = 0

    if kind in ("all", "anomaly"):
        a_total, a_rows = db.fetch_anomalies(
            limit=limit, offset=offset, severity=severity, search=search, since=since
        )
        total += a_total
        for row in a_rows:
            row["kind"] = "anomaly"
            items.append(row)

    if kind in ("all", "report"):
        r_total, r_rows = db.fetch_reports(limit=limit, offset=offset, search=search, engine=engine, since=since)
        total += r_total
        for row in r_rows:
            row["kind"] = "report"
            row["severity"] = "info"
            items.append(row)

    items.sort(key=lambda r: r.get("timestamp", 0), reverse=True)
    return {"total": total, "limit": limit, "offset": offset, "items": items[:limit]}


@router.get("/export")
def export(
    format_type: str = Query(default="json", alias="format", pattern="^(json|csv)$"),
    kind: str = Query(default="all", pattern="^(all|anomaly|report)$"),
    range_key: Optional[str] = Query(default="all", alias="range"),
) -> Response:
    since = _since_from_range(range_key)
    anomalies: list[dict[str, Any]] = []
    reports: list[dict[str, Any]] = []
    if kind in ("all", "anomaly"):
        _, anomalies = db.fetch_anomalies(limit=5000, since=since)
    if kind in ("all", "report"):
        _, reports = db.fetch_reports(limit=5000, since=since)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    if format_type == "json":
        payload = {
            "exported_at": datetime.now().isoformat(timespec="seconds"),
            "application": config.APP_NAME,
            "version": config.APP_VERSION,
            "anomaly_events": anomalies,
            "diagnostic_reports": reports,
        }
        return Response(
            content=json.dumps(payload, indent=2),
            media_type="application/json",
            headers={"Content-Disposition": f'attachment; filename="sentinel_history_{stamp}.json"'},
        )

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(
        [
            "record_type",
            "id",
            "detected_at",
            "severity",
            "metric",
            "observed_value",
            "expected_low",
            "expected_high",
            "score",
            "engine",
            "question",
            "summary",
            "evidence",
            "acknowledged",
        ]
    )
    for row in anomalies:
        writer.writerow(
            [
                "anomaly",
                row.get("id"),
                row.get("detected_at"),
                row.get("severity"),
                row.get("metric"),
                row.get("observed_value"),
                (row.get("expected_range") or [None, None])[0],
                (row.get("expected_range") or [None, None])[1],
                row.get("score"),
                row.get("model"),
                "",
                row.get("explanation", ""),
                row.get("evidence", ""),
                row.get("acknowledged"),
            ]
        )
    for row in reports:
        writer.writerow(
            [
                "report",
                row.get("id"),
                row.get("created_at"),
                "info",
                "",
                "",
                "",
                "",
                row.get("confidence"),
                row.get("engine"),
                row.get("question"),
                row.get("summary"),
                " | ".join(row.get("evidence") or []),
                "",
            ]
        )
    return Response(
        content=buffer.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="sentinel_history_{stamp}.csv"'},
    )


@router.post("/retention")
def apply_retention(retention_days: Optional[int] = Query(default=None, ge=1, le=365)) -> dict[str, Any]:
    if retention_days:
        db.set_setting("retention_days", retention_days)
    removed = db.apply_retention(retention_days)
    return {"retention_days": retention_days or config.RETENTION_DAYS, "removed": removed}


@router.delete("/clear")
def clear(
    table: str = Query(default="all", pattern="^(all|anomaly_events|diagnostic_reports|metric_samples)$"),
    confirm: bool = Query(default=False, description="must be true; protects against accidental data loss"),
) -> dict[str, Any]:
    """Clear stored history. Requires an explicit confirmation flag."""
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="history deletion requires confirm=true. This action permanently removes stored diagnostic history.",
        )
    if table == "all":
        removed = {t: db.clear_table(t) for t in ("anomaly_events", "diagnostic_reports", "metric_samples")}
    else:
        removed = {table: db.clear_table(table)}
    return {"cleared": removed, "note": "Cleared records cannot be recovered."}


@router.get("/export/raw", response_class=PlainTextResponse)
def export_raw(kind: str = Query(default="anomaly", pattern="^(anomaly|report)$")) -> str:
    """Debug helper: raw JSON dump of one table."""
    if kind == "anomaly":
        _, rows = db.fetch_anomalies(limit=5000)
    else:
        _, rows = db.fetch_reports(limit=5000)
    return json.dumps(rows, indent=2)

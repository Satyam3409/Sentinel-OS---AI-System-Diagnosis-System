"""Settings, About and top-level API surface tests."""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_api_index(client: TestClient) -> None:
    resp = client.get("/api")
    assert resp.status_code == 200
    data = resp.json()
    assert data["name"] == "SENTINEL OS"
    assert "endpoints" in data and data["endpoints"]["summary"]


def test_get_settings(client: TestClient) -> None:
    resp = client.get("/api/settings")
    assert resp.status_code == 200
    data = resp.json()
    assert "settings" in data and "effective" in data
    assert "api_configuration" in data
    assert data["api_configuration"]["gemini_configured"] is False
    assert data["api_configuration"]["gemini_env_var"] == "GEMINI_API_KEY"
    assert data["server"]["host"] == "127.0.0.1"
    assert isinstance(data["api_configuration"]["how_to_enable"], list)


def test_update_settings_round_trip(client: TestClient) -> None:
    payload = {
        "sample_interval": 2.0,
        "sensitivity": 0.6,
        "retention_days": 21,
        "data_source": "live",
    }
    resp = client.put("/api/settings", json=payload)
    assert resp.status_code == 200
    effective = resp.json()["effective"]
    assert effective["sample_interval_seconds"] == 2.0
    assert 0.0 <= effective["anomaly_sensitivity"] <= 1.0
    assert effective["retention_days"] == 21


def test_update_settings_validates_bounds(client: TestClient) -> None:
    bad_interval = client.put(
        "/api/settings",
        json={"sample_interval": 0.01, "sensitivity": 0.5, "retention_days": 30, "data_source": "live"},
    )
    assert bad_interval.status_code == 422

    bad_retention = client.put(
        "/api/settings",
        json={"sample_interval": 2.0, "sensitivity": 0.5, "retention_days": 100000, "data_source": "live"},
    )
    assert bad_retention.status_code == 422

    bad_source = client.put(
        "/api/settings",
        json={"sample_interval": 2.0, "sensitivity": 0.5, "retention_days": 30, "data_source": "cloud"},
    )
    assert bad_source.status_code == 422


def test_about_documents_capabilities_and_limits(client: TestClient) -> None:
    resp = client.get("/api/about")
    assert resp.status_code == 200
    data = resp.json()
    assert data["application"] == "SENTINEL OS"
    assert data["full_name"] == "AI-Powered System Intelligence & Diagnostics Platform"
    assert "Windows" in data["target_os"]
    assert "Operating Systems" in data["category"]
    assert data["architecture"]["backend"]
    assert data["architecture"]["ml"]
    assert data["capabilities"] and data["limitations"]
    # The malware disclaimer and locality caveat must be present.
    joined = " ".join(data["limitations"]).lower()
    assert "malware" in joined
    assert "local" in joined


def test_health_endpoint_reports_monitoring_state(client: TestClient) -> None:
    resp = client.get("/api/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] in {"ok", "degraded"}
    assert data["agent"]["monitoring"] is True
    assert data["gemini_configured"] is False

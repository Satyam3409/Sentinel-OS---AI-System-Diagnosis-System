"""Unit tests for the Isolation Forest anomaly detection engine."""

from __future__ import annotations

import numpy as np
import pytest

from app.ml.anomaly import (
    FEATURES,
    AnomalyEngine,
    sample_to_features,
    synthetic_baseline,
)

NORMAL_SAMPLE = {
    "cpu_percent": 22.0,
    "memory_percent": 47.0,
    "swap_percent": 5.0,
    "disk_read_mb_s": 1.2,
    "disk_write_mb_s": 2.0,
    "process_count": 205,
}

EXTREME_SAMPLE = {
    "cpu_percent": 100.0,
    "memory_percent": 99.5,
    "swap_percent": 92.0,
    "disk_read_mb_s": 480.0,
    "disk_write_mb_s": 520.0,
    "process_count": 900,
}


@pytest.fixture()
def engine(tmp_path) -> AnomalyEngine:
    return AnomalyEngine(model_path=tmp_path / "model.joblib")


def test_feature_vector_shape():
    features = sample_to_features(NORMAL_SAMPLE)
    assert set(features) == set(FEATURES)
    assert len(FEATURES) == 7


def test_cpu_delta_uses_previous_sample():
    first = sample_to_features(NORMAL_SAMPLE)
    assert first["cpu_delta"] == 0.0
    second = sample_to_features({"cpu_percent": 62.0, **{k: v for k, v in NORMAL_SAMPLE.items() if k != "cpu_percent"}}, NORMAL_SAMPLE)
    assert second["cpu_delta"] == pytest.approx(40.0)


def test_synthetic_baseline_is_labelled_synthetic_data():
    data = synthetic_baseline(n=200)
    assert data.shape == (200, len(FEATURES))
    assert data[:, FEATURES.index("cpu_percent")].max() <= 100


def test_train_rejects_wrong_shape(engine):
    with pytest.raises(ValueError):
        engine.train(np.zeros((50, 3)), source="test")


def test_train_rejects_too_few_samples(engine):
    with pytest.raises(ValueError):
        engine.train(np.zeros((5, len(FEATURES))), source="test")


def test_cold_start_training_makes_model_ready(engine):
    assert engine.model_ready is False
    assert engine.mode() == "rule-based-cold-start"
    result = engine.train_cold_start()
    assert engine.model_ready is True
    assert engine.mode() == "unsupervised-learning"
    assert result["trained_samples"] > 0
    assert result["training_source"] == "synthetic-healthy-baseline"


def test_rule_based_cold_start_detects_breach(engine):
    """Before any model exists the engineering thresholds must still fire."""
    engine.model = None
    result = engine.evaluate({"cpu_percent": 97.0, **{k: v for k, v in NORMAL_SAMPLE.items() if k != "cpu_percent"}})
    assert result["is_anomaly"] is True
    assert result["severity"] in {"medium", "high", "critical"}
    assert "threshold" in result["evidence"]


def test_trained_model_scores_normal_and_extreme_differently(engine):
    engine.train_cold_start()
    normal = engine.evaluate(dict(NORMAL_SAMPLE))
    extreme = engine.evaluate(dict(EXTREME_SAMPLE))
    assert extreme["score"] > normal["score"]
    assert extreme["is_anomaly"] is True
    assert extreme["severity"] in {"medium", "high", "critical"}


def test_result_contract(engine):
    engine.train_cold_start()
    result = engine.evaluate(dict(NORMAL_SAMPLE))
    for key in (
        "timestamp",
        "detected_at",
        "is_anomaly",
        "score",
        "severity",
        "metric",
        "observed_value",
        "expected_range",
        "evidence",
        "explanation",
        "model",
        "features",
    ):
        assert key in result
    assert 0.0 <= result["score"] <= 1.0
    assert len(result["expected_range"]) == 2


def test_explanation_never_claims_malware(engine):
    engine.train_cold_start()
    result = engine.evaluate(dict(EXTREME_SAMPLE))
    lowered = result["explanation"].lower()
    assert "malware" not in lowered.replace("not evidence of malware", "")
    assert "not evidence of malware" in lowered or "not proof of malware" in lowered


def test_sensitivity_changes_contamination(engine):
    engine.set_sensitivity(1.0)
    assert engine.contamination == pytest.approx(0.15, abs=0.01)
    engine.set_sensitivity(0.0)
    assert engine.contamination == pytest.approx(0.005, abs=0.01)
    engine.set_sensitivity(5.0)  # out of range input is clamped
    assert engine.sensitivity <= 1.0


def test_model_persistence_round_trip(engine, tmp_path):
    engine.train_cold_start()
    assert engine.model_path.exists()

    restored = AnomalyEngine(model_path=engine.model_path)
    assert restored.load() is True
    assert restored.model_ready is True
    assert restored.trained_samples == engine.trained_samples
    assert restored.training_source == "synthetic-healthy-baseline"


def test_load_returns_false_when_no_file(engine):
    assert engine.load() is False


def test_disabled_engine_never_flags(engine):
    engine.train_cold_start()
    engine.enabled = False
    result = engine.evaluate(dict(EXTREME_SAMPLE))
    assert result["is_anomaly"] is False
    assert result["model"] == "disabled"
    assert engine.mode() == "disabled"


def test_status_payload(engine):
    engine.train_cold_start()
    status = engine.status()
    assert status["model_ready"] is True
    assert status["mode"] == "unsupervised-learning"
    assert status["features"] if "features" in status else True
    assert status["enabled"] is True


def test_maybe_retrain_requires_enough_samples(engine):
    engine.train_cold_start()
    assert engine.maybe_retrain([dict(NORMAL_SAMPLE) for _ in range(3)]) is False

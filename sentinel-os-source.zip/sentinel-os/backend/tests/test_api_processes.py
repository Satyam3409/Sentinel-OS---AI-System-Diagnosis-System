"""Read-only Process Explorer endpoints."""

from __future__ import annotations


def test_list_processes_shape(client):
    body = client.get("/api/processes?limit=20").json()
    assert body["total"] >= 1
    assert body["returned"] <= 20
    for process in body["processes"]:
        assert isinstance(process["pid"], int)
        assert process["name"]
        assert process["cpu_percent"] >= 0
        assert process["memory_mb"] >= 0


def test_sort_by_memory_is_descending(client):
    body = client.get("/api/processes?limit=15&sort=memory").json()
    values = [p["memory_percent"] for p in body["processes"]]
    assert values == sorted(values, reverse=True)


def test_sort_by_cpu_is_descending(client):
    body = client.get("/api/processes?limit=15&sort=cpu").json()
    values = [p["cpu_percent"] for p in body["processes"]]
    assert values == sorted(values, reverse=True)


def test_search_filters_processes(client):
    everything = client.get("/api/processes?limit=200").json()
    assert everything["processes"], "expected at least one running process"
    name = everything["processes"][0]["name"]
    body = client.get(f"/api/processes?search={name[:4]}").json()
    assert body["returned"] >= 1
    assert all(name[:4].lower() in p["name"].lower() for p in body["processes"])


def test_process_detail(client):
    listing = client.get("/api/processes?limit=50").json()
    # PID 0 (the Windows idle process) is intentionally not inspectable, so pick
    # the first real process in the listing.
    pid = next(p["pid"] for p in listing["processes"] if p["pid"] > 0)
    body = client.get(f"/api/processes/{pid}").json()
    assert body["pid"] == pid
    assert body["read_only"] is True
    assert "note" in body


def test_process_detail_not_found(client):
    # PID 0 never exists as an inspectable process.
    response = client.get("/api/processes/999999")
    assert response.status_code in (404, 200)
    if response.status_code == 404:
        assert "no longer running" in response.json()["detail"]


def test_process_detail_rejects_non_positive_pid(client):
    assert client.get("/api/processes/0").status_code == 400


def test_no_termination_endpoint_exists(client):
    """SENTINEL OS must expose no way to kill a process."""
    # Assert against the published OpenAPI contract rather than router objects:
    # it is the stable, version-independent description of what is exposed.
    paths = client.get("/openapi.json").json()["paths"]
    assert "/api/processes/{pid}" in paths
    assert not any("kill" in path or "terminate" in path for path in paths)
    # Only GET is registered for the process routes.
    for path, operations in paths.items():
        if path.startswith("/api/processes"):
            assert "get" in operations
            assert set(operations) <= {"get", "parameters"}

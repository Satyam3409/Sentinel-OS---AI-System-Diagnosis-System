"""Performance Lab tests.

Stress experiments are deliberately bounded: they require explicit confirmation,
respect configured ceilings and always clean up.
"""

from __future__ import annotations

import time

from fastapi.testclient import TestClient


def test_limits_expose_safety_contract(client: TestClient) -> None:
    resp = client.get("/api/lab/limits")
    assert resp.status_code == 200
    data = resp.json()
    assert data["safety"]["requires_confirmation"] is True
    assert data["safety"]["automatic_timeout"] is True
    assert data["safety"]["never_exhausts_ram"] is True
    assert data["safety"]["max_concurrent_experiments"] == 1
    limits = data["limits"]
    assert limits["cpu"]["max_workers"] >= 1
    assert limits["cpu"]["max_duration_seconds"] >= 3
    assert limits["memory"]["max_memory_mb"] >= 64


def test_start_requires_confirmation(client: TestClient) -> None:
    resp = client.post(
        "/api/lab/start",
        json={"kind": "cpu", "workers": 1, "duration_seconds": 3, "confirmed": False},
    )
    assert resp.status_code == 400
    assert "confirm" in resp.json()["detail"].lower()


def test_cpu_experiment_lifecycle_and_cleanup(client: TestClient) -> None:
    start = client.post(
        "/api/lab/start",
        json={"kind": "cpu", "workers": 1, "duration_seconds": 3, "confirmed": True},
    )
    assert start.status_code == 200, start.text
    running = start.json()
    assert running["running"] is True
    assert running["kind"] == "cpu"
    assert running["baseline"], "a measured baseline must be captured"

    # A second concurrent experiment must be rejected.
    second = client.post(
        "/api/lab/start",
        json={"kind": "cpu", "workers": 1, "duration_seconds": 3, "confirmed": True},
    )
    assert second.status_code == 409

    time.sleep(0.3)
    status = client.get("/api/lab/status").json()
    assert status["running"] is True
    assert isinstance(status["peak"], dict)

    stopped = client.post("/api/lab/stop")
    assert stopped.status_code == 200
    assert stopped.json()["running"] is False

    # Stopping again should fail cleanly.
    assert client.post("/api/lab/stop").status_code == 404

    cleanup = client.post("/api/lab/cleanup")
    assert cleanup.status_code == 200
    assert cleanup.json()["cleaned"] is True


def test_experiment_limits_enforced(client: TestClient) -> None:
    too_many = client.post(
        "/api/lab/start",
        json={"kind": "cpu", "workers": 99, "duration_seconds": 3, "confirmed": True},
    )
    assert too_many.status_code in (400, 422)

    too_long = client.post(
        "/api/lab/start",
        json={"kind": "cpu", "workers": 1, "duration_seconds": 99999, "confirmed": True},
    )
    assert too_long.status_code == 422


def test_compare_endpoint_is_read_only(client: TestClient) -> None:
    resp = client.get("/api/lab/compare")
    assert resp.status_code == 200
    data = resp.json()
    assert "baseline" in data and "peak" in data
    assert "delta_peak_vs_baseline" in data
    assert data["note"].startswith("All values are measured")

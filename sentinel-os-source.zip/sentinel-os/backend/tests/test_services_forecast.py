"""Forecasting unit tests.

The forecaster must refuse to predict when there is not enough real data, and
must report honest error metrics when it does predict.
"""

from __future__ import annotations

import time

from app.services.forecast import HORIZON, MIN_SAMPLES, build_forecast


def _samples(n: int, base: float = 30.0, slope: float = 0.5) -> list[dict[str, float]]:
    now = time.time()
    return [
        {
            "timestamp": now + i * 2.0,
            "cpu_percent": base + slope * i,
            "memory_percent": 55.0 + 0.1 * i,
            "swap_percent": 5.0,
            "disk_read_mb_s": 0.2,
            "disk_write_mb_s": 0.3,
            "process_count": 200,
        }
        for i in range(n)
    ]


def test_refuses_prediction_without_enough_data() -> None:
    result = build_forecast(_samples(MIN_SAMPLES - 1))
    assert result["available_samples"] == MIN_SAMPLES - 1
    assert result["required_samples"] == MIN_SAMPLES
    assert len(result["series"]) == 2
    for series in result["series"]:
        assert series["sufficient_data"] is False
        assert series["forecast"] == []
        assert "enough" in series["message"].lower() or "sample" in series["message"].lower()


def test_empty_samples_are_handled() -> None:
    result = build_forecast([])
    assert result["available_samples"] == 0
    assert all(s["sufficient_data"] is False for s in result["series"])


def test_forecast_produced_with_sufficient_data() -> None:
    data = _samples(MIN_SAMPLES + 40)
    result = build_forecast(data, horizon=HORIZON)
    cpu = result["series"][0]
    assert cpu["sufficient_data"] is True
    assert cpu["metric"].lower().startswith("cpu")
    assert len(cpu["history"]) == len(data)
    assert len(cpu["forecast"]) == HORIZON
    assert all(point["kind"] == "predicted" for point in cpu["forecast"])
    assert "error" in cpu and cpu["error"] is not None
    assert cpu["error"]["mae"] >= 0
    assert 0.0 <= cpu["confidence"] <= 1.0


def test_forecast_values_are_clipped_to_valid_percentage_range() -> None:
    data = _samples(MIN_SAMPLES + 20, base=99.0, slope=5.0)
    result = build_forecast(data, horizon=HORIZON)
    cpu = result["series"][0]
    assert all(0.0 <= point["value"] <= 100.0 for point in cpu["forecast"])


def test_rising_trend_produces_positive_slope() -> None:
    data = _samples(MIN_SAMPLES + 30, base=20.0, slope=1.0)
    cpu = build_forecast(data)["series"][0]
    assert cpu["slope_per_minute"] > 0

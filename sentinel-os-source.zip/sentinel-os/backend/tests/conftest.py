"""Shared pytest fixtures for the SENTINEL OS backend test-suite.

Environment variables are set *before* importing the application so that the
test-run never touches the real runtime database and never calls Gemini.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

_TEST_DATA_DIR = Path(tempfile.mkdtemp(prefix="sentinel-os-tests-"))
os.environ["SENTINEL_DATA_DIR"] = str(_TEST_DATA_DIR)
os.environ["SENTINEL_SAMPLE_INTERVAL"] = "0.4"
os.environ["SENTINEL_ML_ENABLED"] = "true"
os.environ["SENTINEL_ML_MIN_TRAIN_SAMPLES"] = "20"
os.environ["SENTINEL_LAB_MAX_CPU_WORKERS"] = "4"
os.environ["SENTINEL_LAB_MAX_CPU_SECONDS"] = "30"
os.environ["SENTINEL_LAB_MAX_MEMORY_MB"] = "256"
os.environ["SENTINEL_LAB_MAX_MEMORY_SECONDS"] = "30"
# An empty key forces the deterministic local fallback engine.
os.environ["GEMINI_API_KEY"] = ""

from fastapi.testclient import TestClient  # noqa: E402

from app import config  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client() -> TestClient:
    """A live TestClient with the real lifespan (monitoring + ML) running."""
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture(scope="session")
def data_dir() -> Path:
    return Path(config.DATA_DIR)

"""Health, system monitoring and metric endpoints."""

from __future__ import annotations


def test_api_index(client):
    response = client.get("/api")
    assert response.status_code == 200
    body = response.json()
    assert body["name"] == "SENTINEL OS"
    assert "endpoints" in body


def test_health_reports_agent_state(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] in {"ok", "degraded"}
    agent = body["agent"]
    assert agent["monitoring"] is True
    assert agent["sample_interval_seconds"] > 0
    assert isinstance(agent["warnings"], list)
    assert "database" in body
    assert body["gemini_configured"] is False  # tests run without an API key


def test_summary_is_measured_not_random(client):
    body = client.get("/api/system/summary").json()
    assert body["source"] == "live"
    cpu = body["cpu"]
    memory = body["memory"]
    assert 0.0 <= cpu["percent"] <= 100.0
    assert cpu["core_count_logical"] >= 1
    assert 0.0 <= memory["percent"] <= 100.0
    assert memory["total_mb"] > 0
    assert memory["available_mb"] <= memory["total_mb"]
    assert body["process_count"] >= 1
    health = body["health"]
    assert 0 <= health["score"] <= 100
    assert health["status"] in {"optimal", "good", "fair", "degraded", "critical"}
    assert health["reasons"]
    assert "agent" in body


def test_cpu_metrics_bounds(client):
    body = client.get("/api/system/summary").json()["cpu"]
    assert len(body["per_core"]) == body["core_count_logical"]
    assert all(0.0 <= value <= 100.0 for value in body["per_core"])


def test_disks_endpoint_lists_partitions(client):
    body = client.get("/api/system/disks").json()
    assert "partitions" in body
    assert "read_mb_s" in body and "write_mb_s" in body
    for part in body["partitions"]:
        assert part["total_gb"] > 0
        assert 0 <= part["percent"] <= 100


def test_network_endpoint(client):
    body = client.get("/api/system/network").json()
    for key in ("upload_kb_s", "download_kb_s", "bytes_sent_mb", "bytes_recv_mb", "packets_sent"):
        assert key in body
    assert body["upload_kb_s"] >= 0


def test_system_info_endpoint(client):
    body = client.get("/api/system/info").json()
    assert body["hostname"]
    assert body["python_version"]
    assert body["uptime_seconds"] > 0
    assert isinstance(body["is_admin"], bool)


def test_history_from_memory_and_database(client):
    memory = client.get("/api/system/history?limit=50").json()
    assert memory["source"] == "memory"
    assert memory["metric"] == "all"
    assert isinstance(memory["points"], list)

    database = client.get("/api/system/history?limit=50&source=database").json()
    assert database["source"] == "database"
    assert isinstance(database["points"], list)


def test_history_single_metric_projection(client):
    body = client.get("/api/system/history?metric=cpu_percent&limit=10").json()
    assert body["metric"] == "cpu_percent"
    for point in body["points"]:
        assert "timestamp" in point
        assert "value" in point


def test_system_health_endpoint(client):
    body = client.get("/api/system/health").json()
    assert "score" in body and "status" in body and "reasons" in body


def test_top_processes(client):
    body = client.get("/api/system/top?by=cpu&limit=5").json()
    assert body["by"] == "cpu"
    assert len(body["items"]) <= 5
    cpu_values = [item["cpu_percent"] for item in body["items"]]
    assert cpu_values == sorted(cpu_values, reverse=True)


def test_history_limit_validation(client):
    assert client.get("/api/system/history?limit=0").status_code == 422
    assert client.get("/api/system/top?by=disk").status_code == 422

"""Anomaly-detection API tests.

These exercise the real ML engine through the HTTP surface. The model is trained
from the labelled synthetic baseline plus whatever real samples exist, so the
tests remain deterministic without needing a long observation window.
"""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_status_reports_engine_contract(client: TestClient) -> None:
    resp = client.get("/api/anomaly/status")
    assert resp.status_code == 200
    data = resp.json()
    for key in (
        "enabled",
        "model_ready",
        "mode",
        "trained_samples",
        "sensitivity",
        "contamination",
        "features",
        "recent_events",
        "current_metrics",
    ):
        assert key in data, f"missing key {key}"
    assert isinstance(data["features"], list) and data["features"]
    assert data["mode"] in {"unsupervised-learning", "rule-based-cold-start", "disabled"}
    assert 0.0 <= data["sensitivity"] <= 1.0
    assert 0.0 < data["contamination"] <= 0.5


def test_current_metrics_are_measured_not_random(client: TestClient) -> None:
    data = client.get("/api/anomaly/status").json()
    metrics = data["current_metrics"]
    assert 0.0 <= metrics["cpu_percent"] <= 100.0
    assert 0.0 <= metrics["memory_percent"] <= 100.0
    assert 0.0 <= metrics["swap_percent"] <= 100.0
    assert metrics["process_count"] > 0


def test_train_endpoint_returns_ready_model(client: TestClient) -> None:
    resp = client.post("/api/anomaly/train")
    assert resp.status_code == 200
    data = resp.json()
    assert data["trained_samples"] > 0
    assert data["training_source"]
    assert "timestamp" in data
    # The engine must report itself ready afterwards.
    assert client.get("/api/anomaly/status").json()["model_ready"] is True


def test_evaluate_returns_full_evidence_contract(client: TestClient) -> None:
    resp = client.post("/api/anomaly/evaluate")
    assert resp.status_code == 200
    result = resp.json()
    for key in (
        "timestamp",
        "detected_at",
        "is_anomaly",
        "score",
        "severity",
        "metric",
        "observed_value",
        "expected_range",
        "evidence",
        "explanation",
        "model",
    ):
        assert key in result, f"missing key {key}"
    assert isinstance(result["expected_range"], list)
    assert len(result["expected_range"]) == 2
    # Anomaly detection must explicitly disclaim being a malware verdict.
    explanation = result["explanation"].lower()
    assert "not evidence of malware" in explanation or "not proof of malware" in explanation


def test_sensitivity_updates_contamination(client: TestClient) -> None:
    high = client.post("/api/anomaly/sensitivity", json={"value": 1.0})
    assert high.status_code == 200
    assert high.json()["sensitivity"] == 1.0
    assert high.json()["contamination"] > 0.1

    low = client.post("/api/anomaly/sensitivity", json={"value": 0.0})
    assert low.status_code == 200
    assert low.json()["contamination"] <= 0.01

    # Restore a neutral value for subsequent tests.
    client.post("/api/anomaly/sensitivity", json={"value": 0.5})


def test_sensitivity_out_of_range_is_rejected(client: TestClient) -> None:
    assert client.post("/api/anomaly/sensitivity", json={"value": 2.5}).status_code == 422
    assert client.post("/api/anomaly/sensitivity", json={"value": -1}).status_code == 422


def test_enable_disable_toggle(client: TestClient) -> None:
    off = client.post("/api/anomaly/enabled", json={"enabled": False})
    assert off.status_code == 200
    assert off.json()["enabled"] is False
    on = client.post("/api/anomaly/enabled", json={"enabled": True})
    assert on.json()["enabled"] is True


def test_events_listing(client: TestClient) -> None:
    resp = client.get("/api/anomaly/events", params={"limit": 10})
    assert resp.status_code == 200
    data = resp.json()
    assert {"total", "limit", "offset", "items"} <= set(data)
    assert isinstance(data["items"], list)


def test_unknown_event_acknowledge_returns_404(client: TestClient) -> None:
    assert client.post("/api/anomaly/events/99999999/acknowledge").status_code == 404
    assert client.delete("/api/anomaly/events/99999999").status_code == 404

"""SQLite persistence layer tests (isolated database file per test)."""

from __future__ import annotations

import time

import pytest

from app.database import db


@pytest.fixture()
def dbfile(tmp_path):
    path = tmp_path / "test.db"
    db.init_db(path)
    return path


def _anomaly(**overrides) -> dict:
    base = {
        "timestamp": time.time(),
        "detected_at": "2026-01-01T00:00:00",
        "is_anomaly": True,
        "score": 0.62,
        "severity": "high",
        "metric": "cpu_percent",
        "observed_value": 96.5,
        "expected_low": 2.0,
        "expected_high": 68.0,
        "evidence": "CPU utilisation observed at 96.50%",
        "explanation": "CPU is statistically unusual - not evidence of malware.",
        "model": "IsolationForest",
        "features": {"cpu_percent": 96.5},
    }
    base.update(overrides)
    return base


def test_init_db_is_idempotent(dbfile):
    db.init_db(dbfile)
    db.init_db(dbfile)
    assert db.stats(dbfile)["anomaly_events"] == 0


def test_insert_and_fetch_anomaly(dbfile):
    event_id = db.insert_anomaly(_anomaly(), db_path=dbfile)
    assert event_id > 0
    total, rows = db.fetch_anomalies(db_path=dbfile)
    assert total == 1
    row = rows[0]
    assert row["id"] == event_id
    assert row["is_anomaly"] is True
    assert row["expected_range"] == [2.0, 68.0]
    assert row["features"] == {"cpu_percent": 96.5}
    assert "expected_low" not in row


def test_anomaly_severity_filter(dbfile):
    db.insert_anomaly(_anomaly(severity="high"), db_path=dbfile)
    db.insert_anomaly(_anomaly(severity="low"), db_path=dbfile)
    total, rows = db.fetch_anomalies(severity="high", db_path=dbfile)
    assert total == 1
    assert rows[0]["severity"] == "high"


def test_anomaly_search(dbfile):
    db.insert_anomaly(_anomaly(evidence="unmistakable needle"), db_path=dbfile)
    db.insert_anomaly(_anomaly(evidence="something else"), db_path=dbfile)
    total, rows = db.fetch_anomalies(search="needle", db_path=dbfile)
    assert total == 1


def test_acknowledge_and_delete_anomaly(dbfile):
    event_id = db.insert_anomaly(_anomaly(), db_path=dbfile)
    assert db.acknowledge_anomaly(event_id, True, db_path=dbfile) is True
    _, rows = db.fetch_anomalies(db_path=dbfile)
    assert rows[0]["acknowledged"] == 1
    assert db.delete_anomaly(event_id, db_path=dbfile) is True
    assert db.stats(dbfile)["anomaly_events"] == 0
    assert db.acknowledge_anomaly(424242, db_path=dbfile) is False


def test_reports_round_trip(dbfile):
    report = {
        "timestamp": time.time(),
        "created_at": "2026-01-01T00:00:00",
        "engine": "local-fallback",
        "model": None,
        "question": "Why is my PC slow?",
        "summary": "CPU is the limiting factor.",
        "evidence": ["CPU at 91%", "Top consumer: build.exe"],
        "possible_causes": ["heavy compilation"],
        "confidence": 0.7,
        "recommended_actions": ["close unused apps"],
        "safety_considerations": ["read-only analysis"],
        "degraded": True,
        "notice": "local engine",
        "latency_ms": 3.2,
    }
    report_id = db.insert_report(report, db_path=dbfile)
    assert report_id > 0
    fetched = db.get_report(report_id, db_path=dbfile)
    assert fetched is not None
    assert fetched["question"] == "Why is my PC slow?"
    assert fetched["evidence"] == ["CPU at 91%", "Top consumer: build.exe"]
    assert fetched["degraded"] is True
    assert db.get_report(999999, db_path=dbfile) is None


def test_reports_search_and_engine_filter(dbfile):
    db.insert_report({"question": "alpha", "engine": "gemini", "timestamp": time.time()}, db_path=dbfile)
    db.insert_report({"question": "beta", "engine": "local-fallback", "timestamp": time.time()}, db_path=dbfile)
    assert db.fetch_reports(engine="gemini", db_path=dbfile)[0] == 1
    assert db.fetch_reports(search="beta", db_path=dbfile)[0] == 1


def test_samples_round_trip_and_ordering(dbfile):
    now = time.time()
    samples = [
        {"timestamp": now - 2, "cpu_percent": 10.0, "memory_percent": 40.0, "process_count": 180},
        {"timestamp": now - 1, "cpu_percent": 20.0, "memory_percent": 42.0, "process_count": 181},
        {"timestamp": now, "cpu_percent": 30.0, "memory_percent": 44.0, "process_count": 182},
    ]
    assert db.insert_samples(samples, db_path=dbfile) == 3
    rows = db.fetch_samples(db_path=dbfile)
    assert [row["cpu_percent"] for row in rows] == [10.0, 20.0, 30.0]
    assert db.stats(dbfile)["metric_samples"] == 3
    assert db.stats(dbfile)["oldest_sample"] == pytest.approx(now - 2)


def test_insert_samples_with_empty_iterable(dbfile):
    assert db.insert_samples([], db_path=dbfile) == 0


def test_settings_defaults_and_override(dbfile):
    defaults = db.get_settings(db_path=dbfile)
    assert defaults["retention_days"] > 0
    assert defaults["demo_mode"] is False
    db.set_setting("sensitivity", 0.42, db_path=dbfile)
    db.set_setting("demo_mode", True, db_path=dbfile)
    updated = db.get_settings(db_path=dbfile)
    assert updated["sensitivity"] == pytest.approx(0.42)
    assert updated["demo_mode"] is True


def test_retention_removes_old_rows(dbfile):
    db.insert_samples(
        [{"timestamp": time.time() - 10 * 86400, "cpu_percent": 5.0, "memory_percent": 5.0}],
        db_path=dbfile,
    )
    db.insert_samples([{"timestamp": time.time(), "cpu_percent": 5.0, "memory_percent": 5.0}], db_path=dbfile)
    removed = db.apply_retention(1, db_path=dbfile)
    assert removed["metric_samples"] == 1
    assert db.stats(dbfile)["metric_samples"] == 1


def test_clear_table_and_guard(dbfile):
    db.insert_anomaly(_anomaly(), db_path=dbfile)
    assert db.clear_table("anomaly_events", db_path=dbfile) == 1
    with pytest.raises(ValueError):
        db.clear_table("users", db_path=dbfile)


def test_reset_db_drops_everything(dbfile):
    db.insert_anomaly(_anomaly(), db_path=dbfile)
    db.reset_db(dbfile)
    stats = db.stats(dbfile)
    assert stats["anomaly_events"] == 0
    assert stats["diagnostic_reports"] == 0
    assert stats["metric_samples"] == 0

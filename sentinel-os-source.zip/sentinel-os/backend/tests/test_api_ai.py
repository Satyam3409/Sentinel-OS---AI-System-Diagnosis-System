"""SENTINEL AI DOCTOR tests.

The test environment has no GEMINI_API_KEY, so every call must succeed through
the deterministic local fallback engine and must never leak a key to the client.
"""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_status_reports_local_fallback(client: TestClient) -> None:
    resp = client.get("/api/ai/status")
    assert resp.status_code == 200
    data = resp.json()
    assert data["assistant"] == "SENTINEL AI DOCTOR"
    assert data["gemini_configured"] is False
    assert data["engine"] == "local-fallback"
    assert data["fallback_available"] is True
    assert len(data["suggested_questions"]) >= 5
    assert data["safety"]["read_only"] is True
    assert data["safety"]["executes_commands"] is False
    assert "GEMINI_API_KEY" in data["safety"]["api_key_location"]


def test_doctor_answers_without_api_key(client: TestClient) -> None:
    resp = client.post("/api/ai/doctor", json={"question": "Diagnose my PC."})
    assert resp.status_code == 200
    body = resp.json()
    assert body["engine"] == "local-fallback"
    assert body["gemini_configured"] is False

    report = body["report"]
    # Every diagnosis must carry the six required sections.
    for key in (
        "summary",
        "evidence",
        "possible_causes",
        "confidence",
        "recommended_actions",
        "safety_considerations",
    ):
        assert key in report, f"missing section {key}"
    assert isinstance(report["evidence"], list) and report["evidence"]
    assert isinstance(report["recommended_actions"], list)
    assert 0.0 <= report["confidence"] <= 1.0
    assert report["question"] == "Diagnose my PC."
    assert report["degraded"] is True


def test_doctor_never_fabricates_metrics(client: TestClient) -> None:
    """Evidence must be grounded in measured values, and no secret may leak."""
    resp = client.post("/api/ai/doctor", json={"question": "Why is my PC slow?"})
    report = resp.json()["report"]
    assert all(isinstance(item, str) and item for item in report["evidence"])
    joined = " ".join(report["evidence"]).lower()
    assert "measured" in joined
    # The API key is empty here, and no credential may ever appear in the payload.
    assert "aiza" not in str(resp.json()).lower()


def test_doctor_question_is_validated(client: TestClient) -> None:
    assert client.post("/api/ai/doctor", json={"question": ""}).status_code == 422
    assert client.post("/api/ai/doctor", json={}).status_code == 422


def test_quick_diagnosis_local(client: TestClient) -> None:
    for kind in ("full", "cpu", "memory", "disk", "process"):
        resp = client.post("/api/ai/diagnose/quick", params={"kind": kind})
        assert resp.status_code == 200, kind
        report = resp.json()["report"]
        assert report["engine"] == "local-fallback"
        assert report["summary"]
    assert client.post("/api/ai/diagnose/quick", params={"kind": "bogus"}).status_code == 422


def test_reports_are_persisted_and_listable(client: TestClient) -> None:
    created = client.post("/api/ai/doctor", json={"question": "Analyze recent system activity."})
    report_id = created.json()["report"].get("id")
    assert report_id, "doctor report should be persisted with an id"

    listing = client.get("/api/ai/reports", params={"limit": 5})
    assert listing.status_code == 200
    data = listing.json()
    assert data["total"] >= 1
    assert any(item["id"] == report_id for item in data["items"])

    detail = client.get(f"/api/ai/reports/{report_id}")
    assert detail.status_code == 200
    assert detail.json()["id"] == report_id

    assert client.get("/api/ai/reports/99999999").status_code == 404

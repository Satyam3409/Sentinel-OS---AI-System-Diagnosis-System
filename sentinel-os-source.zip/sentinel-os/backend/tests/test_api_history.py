"""Diagnostic history: stats, filtering, export and retention safeguards."""

from __future__ import annotations

import json

from fastapi.testclient import TestClient


def test_stats_endpoint(client: TestClient) -> None:
    resp = client.get("/api/history/stats")
    assert resp.status_code == 200
    data = resp.json()
    assert "retention_days" in data
    for table in ("anomaly_events", "diagnostic_reports", "metric_samples"):
        assert table in data, f"missing stats for {table}"


def test_unified_history_view_and_filters(client: TestClient) -> None:
    client.post("/api/ai/doctor", json={"question": "Diagnose my PC."})

    all_items = client.get("/api/history/events", params={"kind": "all", "limit": 25})
    assert all_items.status_code == 200
    payload = all_items.json()
    assert {"total", "limit", "offset", "items"} <= set(payload)

    reports_only = client.get("/api/history/events", params={"kind": "report"})
    assert reports_only.status_code == 200
    assert all(i["kind"] == "report" for i in reports_only.json()["items"])

    bad_kind = client.get("/api/history/events", params={"kind": "nonsense"})
    assert bad_kind.status_code == 422

    ranged = client.get("/api/history/events", params={"range": "24h"})
    assert ranged.status_code == 200


def test_json_export_is_valid_and_labelled(client: TestClient) -> None:
    resp = client.get("/api/history/export", params={"format": "json"})
    assert resp.status_code == 200
    assert "attachment" in resp.headers.get("content-disposition", "")
    payload = json.loads(resp.text)
    assert payload["application"] == "SENTINEL OS"
    assert "anomaly_events" in payload
    assert "diagnostic_reports" in payload
    assert "exported_at" in payload


def test_csv_export_has_header(client: TestClient) -> None:
    resp = client.get("/api/history/export", params={"format": "csv"})
    assert resp.status_code == 200
    assert resp.text.splitlines()[0].startswith("record_type,id,detected_at")


def test_clear_requires_confirmation(client: TestClient) -> None:
    blocked = client.delete("/api/history/clear", params={"table": "all"})
    assert blocked.status_code == 400
    assert "confirm" in blocked.json()["detail"]

    ok = client.delete("/api/history/clear", params={"table": "metric_samples", "confirm": True})
    assert ok.status_code == 200
    assert "cleared" in ok.json()


def test_retention_endpoint(client: TestClient) -> None:
    resp = client.post("/api/history/retention", params={"retention_days": 30})
    assert resp.status_code == 200
    body = resp.json()
    assert body["retention_days"] == 30
    assert "removed" in body

    assert client.post("/api/history/retention", params={"retention_days": 9999}).status_code == 422


def test_raw_export_helper(client: TestClient) -> None:
    resp = client.get("/api/history/export/raw", params={"kind": "anomaly"})
    assert resp.status_code == 200
    assert isinstance(json.loads(resp.text), list)

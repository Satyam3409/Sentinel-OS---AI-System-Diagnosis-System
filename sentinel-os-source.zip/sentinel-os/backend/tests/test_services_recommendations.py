"""Recommendation engine unit tests.

The engine is given explicit synthetic summaries so no real telemetry is needed,
and every item must be read-only and carry the full evidence contract.
"""

from __future__ import annotations

from app.services.recommendations import build_recommendations


def _summary(cpu=10.0, mem=40.0, swap=0.0, read=0.0, write=0.0, processes=150, uptime=3600.0):
    return {
        "source": "live",
        "timestamp": 0.0,
        "cpu": {"percent": cpu, "core_count_logical": 8, "frequency_mhz": 2400.0, "per_core": []},
        "memory": {
            "total_mb": 16384.0,
            "used_mb": 16384.0 * mem / 100.0,
            "available_mb": 16384.0 * (100 - mem) / 100.0,
            "percent": mem,
            "swap_total_mb": 4096.0,
            "swap_used_mb": 4096.0 * swap / 100.0,
            "swap_percent": swap,
        },
        "disk": {"read_mb_s": read, "write_mb_s": write, "partitions": []},
        "network": {"upload_kb_s": 0.0, "download_kb_s": 0.0},
        "system": {"uptime_seconds": uptime, "boot_time": 0.0},
        "process_count": processes,
    }


def _ids(result):
    return {item["id"] for item in result["items"]}


def test_healthy_system_yields_no_pressure_recommendations() -> None:
    result = build_recommendations(_summary(cpu=5, mem=30, swap=0, processes=120, uptime=3600))
    assert result["count"] == len(result["items"])
    ids = _ids(result)
    assert "cpu-pressure" not in ids
    assert "memory-pressure" not in ids
    assert "swap-pressure" not in ids
    assert "process-count" not in ids
    assert "uptime" not in ids


def test_high_cpu_triggers_cpu_pressure() -> None:
    result = build_recommendations(_summary(cpu=95.0))
    item = next(i for i in result["items"] if i["id"] == "cpu-pressure")
    assert item["severity"] == "critical"
    assert "95" in item["trigger"]
    assert "evidence" in item and item["evidence"]
    assert item["read_only"] is True


def test_high_memory_and_swap_trigger_both() -> None:
    result = build_recommendations(_summary(mem=90.0, swap=70.0))
    ids = _ids(result)
    assert "memory-pressure" in ids
    assert "swap-pressure" in ids


def test_process_count_and_uptime_low_severity_triggers() -> None:
    result = build_recommendations(_summary(processes=500, uptime=86400.0 * 10))
    ids = _ids(result)
    assert "process-count" in ids
    assert "uptime" in ids
    for item in result["items"]:
        assert item["severity"] in {"info", "low", "medium", "high", "critical"}


def test_every_item_has_the_full_contract_and_is_read_only() -> None:
    result = build_recommendations(_summary(cpu=88.0, mem=88.0, swap=50.0, write=80.0, processes=400, uptime=86400.0 * 9))
    assert result["items"], "expected triggered recommendations"
    for item in result["items"]:
        for key in (
            "id",
            "severity",
            "trigger",
            "evidence",
            "explanation",
            "suggested_action",
            "risk",
            "verification",
            "read_only",
        ):
            assert key in item, f"missing {key}"
        assert item["read_only"] is True
        assert item["verification"]


def test_items_sorted_by_severity_descending() -> None:
    result = build_recommendations(_summary(cpu=95.0, mem=95.0, swap=80.0, processes=400))
    order = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
    severities = [order[i["severity"]] for i in result["items"]]
    assert severities == sorted(severities, reverse=True)

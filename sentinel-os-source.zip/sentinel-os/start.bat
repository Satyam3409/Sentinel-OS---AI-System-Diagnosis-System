@echo off
REM ===========================================================================
REM  SENTINEL OS - AI-Powered System Intelligence & Diagnostics Platform
REM  One-click launcher for Windows 10/11.  Double-click this file.
REM
REM  First run  : creates backend\.venv, installs the Python requirements and
REM               builds the frontend so the UI is served from a single port.
REM  Every run  : starts the monitoring agent and opens SENTINEL OS.
REM
REM  Requires Python 3.11+ (Node.js 18+ is needed only for the first-run build).
REM  This window becomes the monitoring-agent console - closing it stops
REM  monitoring. Nothing outside this folder is modified.
REM ===========================================================================

setlocal
title SENTINEL OS - launcher
cd /d "%~dp0"

set "ROOT=%~dp0"
set "VENV=%ROOT%backend\.venv"
set "PY=%VENV%\Scripts\python.exe"
set "URL=http://127.0.0.1:8000"

echo.
echo   ==========================================================
echo      SENTINEL OS  -  System Intelligence ^& Diagnostics
echo   ==========================================================
echo.

REM --- Already running? Then just open it and exit. --------------------------
netstat -ano | findstr "LISTENING" | findstr ":8000" >nul 2>&1
if not errorlevel 1 (
    echo   [info] SENTINEL OS is already running on port 8000.
    echo   [info] Opening %URL%
    start "" "%URL%"
    ping -n 3 127.0.0.1 >nul
    exit /b 0
)

REM --- Pick a Python interpreter to bootstrap the virtual environment --------
set "PYCMD=py -3"
where py >nul 2>&1
if errorlevel 1 set "PYCMD=python"

REM --- Step 1: virtual environment + backend dependencies -------------------
if not exist "%PY%" (
    echo   [setup] First run detected - preparing the Python environment.
    echo   [setup] Creating backend\.venv ...
    %PYCMD% -m venv "%VENV%"
    if not exist "%PY%" (
        echo.
        echo   [error] Could not create a virtual environment.
        echo           1. Install Python 3.11 or newer from https://www.python.org/downloads/
        echo           2. Tick "Add python.exe to PATH" during the install.
        echo           3. Run this file again.
        echo.
        pause
        exit /b 1
    )

    echo   [setup] Installing backend dependencies ^(this can take a minute^) ...
    "%PY%" -m pip install --upgrade pip >nul 2>&1
    "%PY%" -m pip install -r "%ROOT%backend\requirements.txt"
    if errorlevel 1 (
        echo.
        echo   [error] Dependency installation failed, so SENTINEL OS cannot start.
        echo           Check your internet connection, then install them manually:
        echo             cd backend
        echo             .venv\Scripts\python.exe -m pip install -r requirements.txt
        echo.
        pause
        exit /b 1
    )
    echo   [setup] Backend ready.
    echo.
)

REM --- Step 2: build the UI so one port serves everything -------------------
if not exist "%ROOT%frontend\dist\index.html" (
    where npm >nul 2>&1
    if errorlevel 1 (
        echo   [warn] Node.js / npm not found, so the interface cannot be pre-built.
        echo          The monitoring API still works - API docs at %URL%/docs
        echo.
        echo          For the full interface, install Node.js 18+ from https://nodejs.org
        echo          and run this file again.
        echo.
        pause
    ) else (
        echo   [setup] Building the interface ^(first run only^) ...
        pushd "%ROOT%frontend"
        if not exist "node_modules" (
            echo   [setup] Installing frontend dependencies ...
            call npm install
        )
        call npm run build
        popd
        if exist "%ROOT%frontend\dist\index.html" (
            echo   [setup] Interface build complete.
        ) else (
            echo   [warn] The build did not produce dist\index.html.
            echo          Run "npm run dev" inside frontend\ to use port 5173 instead.
        )
        echo.
    )
)

REM --- Step 3: start the monitoring agent ----------------------------------
REM Uvicorn must run from backend\ so that "app.main" is importable.
cd /d "%ROOT%backend"
title SENTINEL OS - monitoring agent

echo   [start] Monitoring this machine with psutil. Every metric shown in the
echo           interface is measured here - none of it is simulated.
echo   [start] Metrics are sampled every 2 seconds.
echo.
echo   [start] Interface : %URL%
echo   [start] API docs  : %URL%/docs
echo   [start] Health    : %URL%/api/health
echo.
echo   [start] Your browser will open automatically in a few seconds.
echo   [start] Leave this window open while using SENTINEL OS.
echo   [start] Press CTRL+C here, or close this window, to stop monitoring.
echo.

REM Open the browser from a detached helper that waits for the port to bind.
start "" /min cmd /c "ping -n 8 127.0.0.1 >nul & start %URL%"

"%PY%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000

echo.
echo   [stopped] The monitoring agent has shut down.
pause
exit /b 0

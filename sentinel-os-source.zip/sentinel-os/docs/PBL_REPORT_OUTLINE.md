# SENTINEL OS — PBL Report Outline

**Project:** SENTINEL OS — AI-Powered System Intelligence & Diagnostics Platform
**Course:** Operating Systems (Project-Based Learning)
**Programme:** B.Tech — Artificial Intelligence & Machine Learning — 5th Semester
**Team / Roll numbers:** _fill in_
**Guide:** _fill in_
**Academic year:** _fill in_

> This outline follows a standard B.Tech PBL report structure. Section headings are ready to
> expand; the bracketed notes indicate what evidence to include from the running application.

---

## Abstract

A short (~200 word) summary: SENTINEL OS is a local-first Windows monitoring and diagnostics
platform built with a FastAPI monitoring agent, a React dashboard, an Isolation Forest anomaly
detector and a Gemini-backed AI assistant with a fully offline fallback. State the headline
result: *real measured metrics, working ML anomaly detection with cold-start handling, and a
diagnostic assistant that never fabricates numbers.*

---

## 1. Introduction

### 1.1 Background
Windows exposes a large amount of performance data (CPU, memory, paging, disk, network,
processes). Built-in tools (Task Manager, Resource Monitor, Performance Monitor) present raw
counters but do not interpret them. Users can see *that* memory is at 92 % but not *why* or
*what to do*.

### 1.2 Problem statement
Design and implement a system that:
1. collects real Windows resource metrics,
2. detects statistically unusual behaviour without labelled training data,
3. explains the cause in plain language grounded in the measured values,
4. recommends safe, read-only corrective actions, and
5. keeps a searchable history of findings.

### 1.3 Objectives
Enumerate the seven primary objectives from the specification as measurable statements.

### 1.4 Scope and limitations
Explicitly state: this is a monitoring/diagnostics tool, **not** an operating system and **not**
a malware detector; most per-process fields require elevation; a cloud-hosted preview cannot
read the local machine's counters.

---

## 2. Literature and technology survey

* Operating-system performance theory: scheduling, paging/swap, thrashing, I/O wait, working-set
  behaviour. Cite Silberschatz *Operating System Concepts* (virtual memory, page replacement,
  thrashing) and Tanenbaum.
* Anomaly detection: unsupervised methods for time-series resource data; why **Isolation Forest**
  (Liu, Ting & Zhou, 2008) suits this problem — no labels, linear time, robust to high
  dimensionality, native handling of "few and different" points.
* Why not a supervised classifier: no labelled corpus of "problematic" Windows sessions exists
  for a student project, and supervised labels would be subjective.
* LLM-assisted diagnosis: grounding model output in structured telemetry to prevent
  hallucinated numbers.

---

## 3. Requirement analysis

### 3.1 Functional requirements
FR-1 real-time monitoring · FR-2 process explorer (read-only) · FR-3 ML anomaly detection ·
FR-4 AI diagnostic assistant · FR-5 evidence-based recommendations · FR-6 diagnostic history
with export · FR-7 bounded performance experiments · FR-8 trend forecasting · FR-9 settings.

### 3.2 Non-functional requirements
Local-first operation · no fabricated data · read-only safety · graceful degradation ·
response latency · portability within Windows 10/11 · no secret exposure.

### 3.3 Constraints
Windows target, Python + Node toolchain, optional third-party API key, no administrative
privileges assumed.

### 3.4 Use-case diagram
_(insert UML diagram)_ Actors: User, Monitoring Agent, ML Engine, AI Doctor, SQLite.

---

## 4. System design

### 4.1 Architecture
Reference `docs/ARCHITECTURE.md`. Present the three-tier design:
React SPA ↔ FastAPI agent ↔ (psutil / sklearn / SQLite / Gemini).

### 4.2 Module design
Describe each backend service and each frontend view; include the class/function inventory.

### 4.3 Data flow diagram
The sampling loop: `collect → evaluate → persist → broadcast`, plus the REST request path.

### 4.4 Database design
ER diagram of `anomaly_events`, `diagnostic_reports`, `metric_samples`, `settings`; include the
DDL from `database/db.py`.

### 4.5 ML design
Feature vector (7 features incl. `cpu_delta`), cold-start strategy (labelled synthetic baseline +
rule-based fallback), blended retraining, score mapping, severity derivation, sensitivity →
contamination curve.

### 4.6 API design
Summarise from `docs/API.md`; include the WebSocket contract.

### 4.7 UI/UX design
Screenshots of all ten views; describe the dark premium design language (electric-blue accents,
severity colour semantics, connection indicator, loading/error/empty states).

---

## 5. Implementation

### 5.1 Technology stack and justification
Table of technology → reason (React/TS for typed UI, Vite for fast dev/proxy, Tailwind for
consistent design tokens, Recharts for graphs, FastAPI + Pydantic for validated APIs, psutil for
portable Windows counters, scikit-learn for Isolation Forest, SQLite for zero-config storage).

### 5.2 Monitoring agent
Code walkthrough of `services/monitor.py`: rate calculations from cumulative counters, ring
buffer, warning collection, elevation detection.

### 5.3 Anomaly engine
Code walkthrough of `ml/anomaly.py`: feature engineering, `synthetic_baseline`, training guards,
`joblib` persistence, `decision_function` → score mapping, most-deviating-feature evidence.

### 5.4 AI Doctor
Code walkthrough of `services/ai_doctor.py`: telemetry collection, system instruction with
anti-fabrication rules, JSON extraction/repair, validation, local fallback, degraded flagging.

### 5.5 Recommendation engine
Threshold table and the evidence/action/risk/verification contract.

### 5.6 Performance Lab
Thread model, memory chunking, 25 %-of-available cap, watchdog, recovery capture.

### 5.7 Frontend
Layout, routing, hooks (`useAsync`, `useMetricsStream`), API client and error handling, charts.

---

## 6. Testing and results

### 6.1 Test strategy
Unit, API contract, integration (real lifespan via `TestClient`), and frontend component tests.

### 6.2 Test inventory
List the test modules and what each asserts (see `backend/tests/` and
`frontend/src/**/*.test.*`). Include the captured pytest / vitest summary output.

### 6.3 Observed results — screenshots
* Live Monitor with real CPU/RAM graphs.
* Process Explorer sorted by CPU.
* Anomaly page showing a detected event with observed value, learned range and score.
* AI Doctor answering with zero API key (degraded local engine).
* Recommendations triggered during a deliberate load.
* Performance Lab showing baseline → peak → recovery.

### 6.4 Performance Lab experiment
Table: baseline CPU %, peak CPU % during the experiment, recovery CPU % after cleanup, and the
computed delta. Note the measured recovery time.

### 6.5 Forecasting accuracy
Report hold-out MAE / RMSE / MAPE for CPU and memory with the sample window used, and state
honestly how the error changes with the amount of data.

### 6.6 Safety verification
Evidence that: no kill endpoint exists (test name), deletion requires `confirm=true` (test
name), experiments require `confirmed=true` (test name), and memory is capped below available
RAM.

---

## 7. Discussion

* Why Isolation Forest over autoencoders / statistical control charts for this data volume.
* Why blending synthetic + real data avoids model drift.
* Why grounding the LLM in telemetry prevents hallucination.
* Trade-offs: 2 s sampling vs. overhead; in-memory ring buffer vs. disk writes; read-only
  design vs. automation convenience.
* Ethical/safety considerations: never calling an anomaly "malware"; never automating
  termination.

---

## 8. Conclusion and future scope

**Conclusion.** Summarise delivered functionality and measurable outcomes.

**Future scope.**
* ETW / WMI-based per-process disk and network attribution.
* Correlation of anomalies across metrics (multivariate event grouping).
* Optional elevation helper for richer per-process fields.
* Trained-on-device seasonal models (time-of-day aware baselines).
* Packaged installer (PyInstaller + Tauri/Electron) for non-developer distribution.
* Supervisor-mode multi-machine dashboard.

---

## References

1. Silberschatz, Galvin & Gagne — *Operating System Concepts*.
2. Tanenbaum & Bos — *Modern Operating Systems*.
3. Liu, Ting & Zhou (2008) — *Isolation Forest*, ICDM.
4. scikit-learn documentation — `IsolationForest`.
5. psutil documentation.
6. FastAPI, React and Vite official documentation.
7. Google Gemini API documentation.

---

## Appendices

* **A** — Installation and run guide (reproduce `README.md` section 5–6).
* **B** — Complete API reference (`docs/API.md`).
* **C** — Source code listing / repository link.
* **D** — Test execution logs.
* **E** — Viva questions and answers (`docs/VIVA_QA.md`).

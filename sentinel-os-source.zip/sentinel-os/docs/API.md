# SENTINEL OS — REST & WebSocket API

Base URL (local agent): `http://127.0.0.1:8000`
Interactive docs: `http://127.0.0.1:8000/docs`

All endpoints are **read-only** with respect to the operating system. Nothing terminates
processes, deletes files, edits the registry, or executes commands. The only mutations are to
SENTINEL OS's own SQLite database and to bounded, user-confirmed Performance Lab threads.

---

## Understanding the response contract

Because the agent cannot always read every counter (processes owned by `SYSTEM` need
elevation), fields may be `null`. Callers must treat `null` as **"unavailable"**, never as zero,
and must never substitute a generated value.

---

## 1. Meta

### `GET /api`
Service index.
```json
{ "name": "SENTINEL OS", "version": "1.0.0", "docs": "/docs",
  "endpoints": { "summary": "/api/system/summary", "...": "..." }, "server_time": 1730000000.0 }
```

### `GET /api/health`
Liveness / readiness probe. Never requires privileges.
```json
{ "status": "ok", "service": "SENTINEL OS", "version": "1.0.0",
  "agent": { "monitoring": true, "sample_interval_seconds": 2.0,
             "samples_collected": 412, "ticks": 412, "last_tick": 1730000000.0,
             "history_points": 412, "websocket_subscribers": 1,
             "last_error": null, "warnings": [] },
  "database": { "anomaly_events": 3, "diagnostic_reports": 1, "metric_samples": 900 },
  "gemini_configured": false, "server_time": 1730000000.0 }
```

### `GET /api/about`
Project metadata, capabilities, limitations, architecture summary and safety disclaimer.

### `GET /api/settings` · `PUT /api/settings`
Read or update runtime settings.

`PUT` body:
```json
{ "sample_interval": 2.0, "sensitivity": 0.5, "retention_days": 30, "data_source": "live" }
```
* `sample_interval` 0.5–30 s · `sensitivity` 0.0–1.0 · `retention_days` 1–365
* `data_source` ∈ `live` | `demo`

Returns the same shape as `GET`, including an `effective` block and `api_configuration`
(where and how to set `GEMINI_API_KEY`).

---

## 2. System monitoring

### `GET /api/system/summary`
Full measured snapshot plus a health verdict.
```json
{
  "source": "live", "timestamp": 1730000000.0,
  "cpu": { "percent": 21.4, "per_core": [12.0, 30.5, "..."], "core_count_logical": 8,
           "core_count_physical": 4, "frequency_mhz": 2400.0, "load_avg": null },
  "memory": { "total_mb": 16384.0, "used_mb": 7102.0, "available_mb": 9282.0, "percent": 43.3,
              "swap_total_mb": 4096.0, "swap_used_mb": 210.0, "swap_percent": 5.1 },
  "disk": { "read_mb_s": 0.8, "write_mb_s": 1.4, "read_mb_total": 91234.0, "write_mb_total": 50122.0,
            "partitions": [ { "device": "C:\\", "mountpoint": "C:\\", "fstype": "NTFS",
                              "total_gb": 476.9, "used_gb": 312.4, "free_gb": 164.5, "percent": 65.5 } ] },
  "network": { "upload_kb_s": 12.4, "download_kb_s": 84.1, "bytes_sent_mb": 1024.0,
               "bytes_recv_mb": 8192.0, "packets_sent": 100, "packets_recv": 200 },
  "system": { "hostname": "...", "platform": "Windows-11", "architecture": "AMD64",
              "processor": "...", "uptime_seconds": 98765.0, "boot_time": 1729900000.0,
              "user": "...", "is_admin": false },
  "process_count": 248,
  "health": { "score": 92, "status": "optimal", "reasons": [], "partial_data": false },
  "agent": { "subscribers": 1, "...": "..." },
  "data_warnings": []
}
```

### `GET /api/system/history`
`?limit=120&since=<epoch>&metric=all|cpu_percent|memory_percent|…&source=memory|database`
When `metric` is set, points are projected to `{ timestamp, value }`; otherwise full samples are
returned. `source=database` reads the persisted table instead of the in-memory ring buffer.

### `GET /api/system/disks`
Disk throughput + partition table.

### `GET /api/system/network`
Upload/download rates and cumulative byte counters.

### `GET /api/system/info`
Hostname, OS, architecture, processor, Python version, uptime, user, elevation flag.

### `GET /api/system/health`
Just the health report plus `timestamp` and `process_count`.

### `GET /api/system/top`
`?limit=5&by=cpu|memory` — top resource consumers.

---

## 3. Processes (read-only)

### `GET /api/processes`
`?limit=200&sort=cpu|memory|name|pid&search=<text>&status=<text>`
```json
{ "timestamp": 1730000000.0, "total": 248, "returned": 200,
  "processes": [ { "pid": 1234, "name": "chrome.exe", "username": "user",
                   "status": "running", "cpu_percent": 12.3, "memory_percent": 4.1,
                   "memory_mb": 671.0, "num_threads": 42, "create_time": 1729990000.0,
                   "exe": null, "cmdline": null } ] }
```

### `GET /api/processes/{pid}`
Detailed view of one process, including `exe` and `cmdline` where permitted.
Returns `404` for an unknown PID.

> There is deliberately **no** kill/terminate endpoint. This is asserted by a test.

---

## 4. Anomaly detection (ML)

### `GET /api/anomaly/status`
`?limit=10`
```json
{ "enabled": true, "model_ready": true, "mode": "unsupervised-learning",
  "trained_samples": 1240, "trained_at": "2026-10-30T12:00:00", "training_source": "synthetic-healthy-baseline",
  "sensitivity": 0.5, "contamination": 0.06,
  "last_score": 0.12, "last_severity": "info", "is_anomaly": false,
  "features": ["cpu_percent", "..."],
  "recent_events": [ { "...": "..." } ],
  "current_metrics": { "cpu_percent": 21.4, "memory_percent": 43.3, "swap_percent": 5.1, "process_count": 248 },
  "last_features": { "cpu_percent": 21.4, "cpu_delta": 3.1, "...": 0.0 } }
```
`mode` ∈ `unsupervised-learning` | `rule-based-cold-start` | `disabled`.

### `GET /api/anomaly/events`
`?limit=50&offset=0&severity=&search=&since=&only_anomalies=false`
```json
{ "total": 3, "limit": 50, "offset": 0,
  "items": [ { "id": 1, "timestamp": 1730000000.0, "detected_at": "...", "is_anomaly": true,
               "score": 0.61, "severity": "high", "metric": "swap_percent",
               "observed_value": 78.2, "expected_range": [0.0, 41.0],
               "evidence": "...", "explanation": "...", "model": "IsolationForest(...)",
               "acknowledged": 0, "features": { "...": 0.0 } } ] }
```

### `POST /api/anomaly/train`
`?include_history=true` — retrains on synthetic baseline + real history (or cold start if there
is not enough real data) and persists the model.

### `POST /api/anomaly/sensitivity`
Body `{ "value": 0.0 … 1.0 }` → `{ "sensitivity": 0.8, "contamination": 0.115 }`.
Retrains so the contamination parameter takes effect.

### `POST /api/anomaly/enabled`
Body `{ "enabled": true|false }`.

### `POST /api/anomaly/evaluate`
Scores the current instantaneous state and persists the event when it is an anomaly.

### `POST /api/anomaly/events/{id}/acknowledge` · `DELETE /api/anomaly/events/{id}`
Acknowledge or delete a stored event. `404` when the id is unknown.

---

## 5. AI System Doctor

### `GET /api/ai/status`
```json
{ "assistant": "SENTINEL AI DOCTOR",
  "engine": "local-fallback", "gemini_configured": false, "gemini_model": null,
  "gemini_timeout_seconds": 30, "fallback_available": true,
  "suggested_questions": ["Diagnose my PC.", "Why is my PC slow?", "..."],
  "safety": { "api_key_location": "backend environment variable GEMINI_API_KEY (never sent to the browser)",
              "executes_commands": false, "read_only": true } }
```

### `POST /api/ai/doctor`
Body `{ "question": "Why is RAM usage high?", "include_history": true }`
```json
{ "engine": "local-fallback", "gemini_configured": false,
  "report": { "id": 7, "created_at": "...", "timestamp": 1730000000.0,
              "engine": "local-fallback", "model": null,
              "question": "Why is RAM usage high?",
              "summary": "…",
              "evidence": ["Memory utilisation measured at 88.1% — 14434 MB used of 16384 MB, 1950 MB available"],
              "possible_causes": ["…"], "confidence": 0.72,
              "recommended_actions": ["…"], "safety_considerations": ["…"],
              "degraded": true, "notice": "GEMINI_API_KEY not configured …", "latency_ms": 11.4 } }
```
`question` is required and 1–2000 characters (422 otherwise). Never fabricates numbers; the
key never appears in the response.

### `GET /api/ai/reports` · `GET /api/ai/reports/{id}`
Paginated stored reports (`?limit=25&offset=0&search=&engine=`) and single-report detail (`404`
when missing).

### `POST /api/ai/diagnose/quick`
`?kind=full|cpu|memory|disk|process` — synchronous, local-only diagnosis that always works.

---

## 6. Smart recommendations

### `GET /api/recommendations`
```json
{ "timestamp": 1730000000.0, "count": 2,
  "items": [ { "id": "cpu-pressure", "severity": "medium",
               "trigger": "CPU utilisation at 74.2% (threshold 70.0%)",
               "evidence": "Measured CPU utilisation 74.2%; top consumers: …",
               "explanation": "…", "suggested_action": "…", "risk": "…",
               "verification": "…", "read_only": true } ] }
```
Triggers: `cpu-pressure` (≥70 %), `memory-pressure` (≥75 %), `swap-pressure` (≥35 %),
`disk-capacity-*` (≥80 %), `disk-io` (≥60 MB/s), `storage-overall` (<20 % free),
`process-count` (>350), `uptime` (≥7 days). Items are sorted by severity, descending.

---

## 7. Diagnostic history

### `GET /api/history/stats`
Row counts per table plus the effective `retention_days`.

### `GET /api/history/events`
`?kind=all|anomaly|report&limit=50&offset=0&severity=&search=&range=all|1h|24h|7d|30d&engine=`
Unified, newest-first view. Every row carries a `kind` discriminator.

### `GET /api/history/export`
`?format=json|csv&kind=all|anomaly|report&range=all|1h|24h|7d|30d`
Returns a downloadable file (`Content-Disposition: attachment`). CSV columns:
`record_type, id, detected_at, severity, metric, observed_value, expected_low, expected_high,
score, engine, question, summary, evidence, acknowledged`.

### `POST /api/history/retention`
`?retention_days=30` → `{ "retention_days": 30, "removed": { "anomaly_events": 2, ... } }`

### `DELETE /api/history/clear`
`?table=all|anomaly_events|diagnostic_reports|metric_samples&confirm=true`
**`confirm=true` is mandatory**; without it the request is rejected with `400` and an
explanation. This is the guard that prevents accidental data loss.

### `GET /api/history/export/raw`
Debug helper: raw JSON of one table.

---

## 8. Performance Lab

### `GET /api/lab/limits`
Configured ceilings plus the explicit safety contract.
```json
{ "limits": { "cpu": { "max_workers": 4, "max_duration_seconds": 120, "available_logical_cores": 8 },
              "memory": { "max_memory_mb": 512, "configured_max_mb": 1024,
                          "max_duration_seconds": 120, "available_mb": 9282.0 } },
  "safety": { "requires_confirmation": true, "automatic_timeout": true,
              "max_concurrent_experiments": 1, "never_exhausts_ram": true,
              "memory_cap_rule": "Allocation is capped at 25% of currently available RAM …",
              "cleanup": "…" },
  "current": { "...": "..." } }
```

### `GET /api/lab/status`
Current experiment state: `id, kind, running, started_at, duration_seconds,
seconds_remaining, workers, memory_mb, baseline, peak, current, recovery, samples, message, limits`.

### `POST /api/lab/start`
```json
{ "kind": "cpu", "workers": 2, "duration_seconds": 20, "memory_mb": 256, "confirmed": true }
```
* `400` — `confirmed` is not `true`
* `409` — another experiment is already running
* `422` — values outside the schema bounds

### `POST /api/lab/stop` → `404` when nothing is running.
### `POST /api/lab/cleanup` → releases all resources.
### `GET /api/lab/compare`
Measured baseline vs peak vs recovery with `delta_peak_vs_baseline` and a `recovered` flag.
### `GET /api/lab/config` → configured ceilings.

---

## 9. Forecasting

### `GET /api/forecast`
`?horizon=10&source=database|memory`
```json
{ "generated_at": "...", "available_samples": 140, "required_samples": 20,
  "series": [ { "metric": "CPU utilisation", "unit": "%", "horizon": 10,
                "history": [ { "timestamp": 1730000000.0, "value": 21.4, "kind": "actual" } ],
                "forecast": [ { "timestamp": 1730000020.0, "value": 24.1, "kind": "predicted" } ],
                "slope_per_minute": 1.82, "confidence": 0.61,
                "method": "OLS linear trend + moving-average blend (hold-out of 10 samples)",
                "sufficient_data": true, "message": "Projected cpu utilisation 20s ahead. …",
                "error": { "mae": 2.14, "rmse": 2.88, "mape_percent": 9.4, "holdout_samples": 10 } } ] }
```
When fewer than 20 real samples exist, `sufficient_data` is `false`, `forecast` is empty and
`message` explains why. Predictions are never invented.

---

## 10. WebSocket

### `WS /ws/metrics`
Push stream of measured samples (~every `SENTINEL_SAMPLE_INTERVAL` seconds).
```json
{ "type": "metrics", "sample": { "timestamp": 1730000000.0, "cpu_percent": 21.4,
  "memory_percent": 43.3, "swap_percent": 5.1, "disk_read_mb_s": 0.8, "disk_write_mb_s": 1.4,
  "net_upload_kb_s": 12.4, "net_download_kb_s": 84.1, "process_count": 248 },
  "summary": { "...": "..." } }
```
Slow consumers have frames dropped rather than blocking the monitoring loop.

### `WS /ws/processes`
Periodic process-table snapshots for the Process Explorer.

---

## 11. Error format

Unexpected failures return structured JSON instead of a traceback:
```json
{ "error": "internal_error", "detail": "…", "path": "/api/system/summary",
  "hint": "Check the backend console for the full traceback." }
```
Validation failures use FastAPI's standard `422` envelope with a `detail` array.

# SENTINEL OS — Viva Questions & Answers

Prepared answers for the B.Tech AIML (5th Semester) Operating Systems PBL viva.
Every answer below describes what the code in this repository actually does. Where a
limitation exists it is stated openly — the project never claims more than it measures.

---

## 1. Operating Systems fundamentals

**Q1. Which OS concepts does this project demonstrate?**
SENTINEL OS exercises resource management and process management directly:

| OS concept | Where it appears |
| --- | --- |
| Process abstraction | Process Explorer reads the live process table (`pid`, `ppid`, `name`, `exe`, `status`, CPU, RSS) |
| CPU scheduling & utilisation | Per-core CPU sampling, system-wide `cpu_percent`, `cpu_delta` between two samples |
| Memory management | Physical RAM used/available/total, virtual memory (swap) utilisation |
| Secondary storage | Per-partition usage, read/write throughput from disk I/O counters |
| I/O subsystem | Network bytes sent/received, disk read/write MB/s derived from counters |
| Kernel/user boundary | `psutil` calls cross into the kernel via native APIs to read counters |
| Concurrency | Backend orchestrator loop, threaded SQLite access with an `RLock`, bounded experiment threads |

**Q2. Why is per-process CPU read as a delta rather than an instantaneous number?**
CPU percentage has no meaning at a single instant — it is work done over a window of
time. `psutil` therefore reports `cpu_percent()` for a process *relative to the previous
call*, which is why the first call for a process typically returns `0.0`. The backend
primes the counters and reports the delta between successive samples instead of
inventing a value.

**Q3. What does a "process count" of several hundred actually tell us?**
It is the number of entries in the kernel's process table visible to the current user.
On Windows this includes many system and service processes. It is a *load indicator*,
not a fault: a high count correlates with launch overhead and context-switch pressure,
which is why the recommendation engine only raises it as an advisory above a documented
threshold.

**Q4. How does the system handle processes it cannot read?**
Processes owned by `SYSTEM` or another user are frequently unreadable from a normal
user account. Rather than guessing, the collector catches the permission error and
returns `null`/`None` for the unavailable fields (CPU, memory, `exe`). The UI renders
those as an em-dash. This is deliberate: **a missing measurement is never replaced by a
fabricated one.**

**Q5. What is the difference between physical memory and swap here?**
Physical memory (RAM) is volatile storage the CPU addresses directly. Swap is the
backing store the OS uses to page memory pages that do not fit in RAM. A rising swap
percentage with high RAM pressure is a symptom of over-commitment — the machine is
thrashing — which is exactly why swap is one of the recommendation and ML features.

---

## 2. Monitoring architecture

**Q6. Why a separate backend at all? Could the browser not read system stats directly?**
No. A browser runs in a sandboxed JavaScript environment and has no access to OS
counters. More importantly, exposing an LLM API key in frontend code would leak it to
anyone with DevTools. The Python backend is the only component that touches the OS and
the only component that holds credentials.

**Q7. Describe the request path end-to-end.**
The orchestrator samples the machine every `SAMPLE_INTERVAL` seconds using `psutil`.
Each sample is (a) appended to an in-memory ring buffer, (b) persisted to SQLite in
`metric_samples`, and (c) published to WebSocket subscribers via an `asyncio.Queue`.
The React frontend subscribes to `/ws` for live updates and calls the REST endpoints in
`/api/*` for on-demand views (process list, reports, history).

**Q8. How is real-time streaming implemented?**
A pub/sub hub keyed by client. Each connected WebSocket gets its own
`asyncio.Queue`. The orchestrator pushes each sample to every queue. To stop a slow
client from stalling the loop, frames are dropped for consumers whose queue is full
rather than blocking the sampler.

**Q9. Why SQLite and not Postgres/Firebase?**
The deliverable is a localhost-first diagnostic tool. SQLite gives durable storage with
zero external services, no credentials, and no network exposure — which matches the
"never transmit system data off the machine unless the user explicitly enables Gemini"
requirement. There is an explicit **no Firebase** constraint.

**Q10. Is the database access thread-safe?**
Yes. Raw `sqlite3` connections are not shared across threads by default, so the data
layer serialises access behind a module-level `threading.RLock`. The ML retraining and
experiment threads therefore cannot interleave a write with the sampler's write.

---

## 3. Machine learning — anomaly detection

**Q11. Why Isolation Forest rather than a supervised classifier?**
Because we have no labelled "bad" data. Anomalies in system behaviour are unknown in
advance and constantly changing. Isolation Forest is an **unsupervised** algorithm that
isolates observations by random partitioning: anomalies are the points that get
isolated in fewer splits because they sit in sparse regions of feature space. It needs
no labels and scales linearly.

**Q12. What features does the model use?**
Seven, all measured: `cpu_percent`, `memory_percent`, `swap_percent`,
`disk_read_mb_s`, `disk_write_mb_s`, `process_count`, `cpu_delta`.

**Q13. How does the system work before it has real history (cold start)?**
An Isolation Forest cannot be trained on no data. Two safeguards:

1. A labelled **synthetic healthy baseline** (`synthetic_baseline(n=1200, seed=42)`)
   gives the model a starting notion of normal system behaviour.
2. A **rule-based cold-start fallback** classifies samples against documented
   thresholds when even that is insufficient.

Once real samples accumulate, the model is *retrained by blending* the synthetic
baseline with real measured history, so the synthetic prior decays as genuine data
arrives. The `/api/anomaly/status` endpoint reports which mode is active
(`unsupervised-learning`, `rule-based-cold-start`, or `disabled`) so the user always
knows what produced a verdict.

**Q14. What is the "sensitivity" slider actually changing?**
It maps a user-facing 0–1 sensitivity onto the Isolation Forest `contamination`
parameter through the documented piecewise-linear curve
`SENSITIVITY_TO_CONTAMINATION`. `0.5` is the neutral default. Moving it up tells the
model to expect a higher proportion of anomalies (more, lower-severity flags); moving it
down expects fewer. The interpolation lives in `contamination_for_sensitivity()`.

**Q15. What is the score, and how is severity assigned?**
Isolation Forest's `decision_function` yields a signed score — negative means "more
anomalous". The system converts that into a bounded severity band
(`low` → `critical`) using the score magnitude, and exposes an `expected_range` for the
metric that triggered the flag. The score is a *statistical outlier measure*, not a
probability, and it is not presented as one.

**Q16. Does a flag prove there is malware?**
**No, and the application says so explicitly.** An anomaly is a deviation from learned
normal behaviour. A legitimate backup job, a Windows update, or a compile can be flagged
identically to malicious activity. The UI and the About page both state that this is
**not** a malware detector and must not be used as an antivirus substitute. Tests assert
that generated explanations never contain the word "malware".

---

## 4. AI System Doctor

**Q17. How is the AI used, and what stops it from hallucinating numbers?**
The AI receives a structured telemetry block assembled from real measurements
(`_format_telemetry_block`). The system instruction (`SYSTEM_INSTRUCTION`) forbids
inventing measurements and requires the model to ground every claim in the supplied
figures. The response is parsed as JSON (`_extract_json`), validated against a strict
schema (`_validate_report`), and repaired or rejected if malformed.

**Q18. What happens when there is no Gemini API key?**
The Doctor degrades gracefully to a deterministic **local rule-based diagnostic**
(`local_diagnostic`) and reports `degraded: true` plus the engine used. The application
is fully usable offline; the AI narrative is an enhancement, never a dependency.

**Q19. How is the API key protected?**
The key is read only from a backend environment variable (`GEMINI_API_KEY`) through
`app/config.py`. It never reaches the frontend, never appears in a response, and never
appears in logs. `gemini_configured()` only reports whether a key is present. A test
asserts that no credential marker leaks into the evidence returned to the client.

**Q20. What does the diagnostic report contain?**
Six sections — summary, contributing factors, evidence, likely causes, recommendations,
and confidence — all persisted to `diagnostic_reports` so they appear in Diagnostic
History. The evidence field is grounded in named measured values.

---

## 5. Safety, ethics and scope

**Q21. What can the application *not* do — by design?**
It never terminates a process, never deletes a file, never edits the registry, never
installs software, and never changes system settings. Every recommendation is advisory.
This is a read-only diagnostic tool, matching the constraint that destructive actions
are out of scope.

**Q22. Where do bounded side effects exist?**
Only in the Performance Lab, and only with explicit confirmation. Experiments spawn
daemon threads that consume a *bounded* amount of CPU or allocate a *bounded* amount of
memory (16 MB chunks, capped at 25 % of available RAM), enforce a hard timeout, and are
reaped by a watchdog (`_watch`). Starting an experiment without the confirmation flag
returns HTTP 400.

**Q23. What happens to the user's system data?**
By default nothing leaves the machine. `data_source` is constrained to `live` or `demo`.
System metrics are only ever sent to Google's API when the user has explicitly
configured a Gemini key. CORS is restricted to localhost origins.

**Q24. Can the machine be overloaded by the tool itself?**
The sampler interval is validated to a floor (0.5 s) so it cannot spin the CPU, and
retention is bounded (1–365 days) so the database cannot grow without limit. Settings
violations return HTTP 422 with the accepted range.

---

## 6. Performance Lab & forecasting

**Q25. What experiment types exist and why?**
CPU load and memory allocation experiments, plus a read-only comparison view. They let
the student demonstrate cause and effect — "allocate N MB and observe the effect on
available memory and swap" — which is the *measurable performance experiment* objective.

**Q26. How is the forecast produced?**
`app/services/forecast.py` fits an ordinary-least-squares linear trend on the recent
series and blends it with a moving average, then projects `HORIZON` steps ahead. It
refuses to predict below `MIN_SAMPLES = 20`, returning `sufficient_data: false` with a
message rather than a made-up curve. Accuracy is reported honestly using hold-out
MAE, RMSE and MAPE.

**Q27. Why report error metrics?**
Because a projection without an error bound is a guess. Reporting MAE/RMSE/MAPE tells
the user how much to trust the line, and supplying a confidence value keeps the
forecast honest.

---

## 7. Engineering & testing

**Q28. How is the project tested?**
Backend: `pytest` with FastAPI's `TestClient` running the real lifespan, so tests
exercise the actual database and orchestration. Modules cover the ML engine, the data
layer, and every REST contract (system, processes, anomaly, AI, history,
recommendations, forecast, lab, settings/about). A `conftest.py` fixture points
`SENTINEL_DATA_DIR` at a temporary directory, shortens the sample interval, shrinks the
lab limits, and clears `GEMINI_API_KEY` so tests run hermetically offline.

Frontend: Vitest with jsdom and Testing Library. `format.test.ts` locks in the
anti-fabrication behaviour (null → em-dash, byte-unit switch, uptime formatting) and
`Primitives.test.tsx` covers the shared UI primitives including progress-bar clamping.

**Q29. How do you prove the app does not terminate processes?**
By design it only calls read-only `psutil` accessors; there is no `terminate`/`kill`
call anywhere. Tests assert the contract: the process API returns data and exposes no
action endpoint, and Lab start without confirmation is rejected.

**Q30. Why TypeScript strict mode?**
`strict`, `noUnusedLocals` and `noUnusedParameters` are on, and the build script runs
`tsc --noEmit` before `vite build`. This turns type errors and dead code into build
failures instead of runtime surprises — important when the UI must render
`null`-heavy real data correctly.

**Q31. How would you extend this project?**
(1) Correlate anomalies across metrics with a multivariate model and confidence
intervals; (2) add an ETW/Perfmon collector for kernel-level detail; (3) support
Linux/macOS through the same `psutil` abstraction; (4) export the PBL dataset for
offline analysis; (5) add anomaly acknowledgement workflows with operator notes.

---

## 8. Likely "trap" questions

**Q32. "So your AI detects malware?"** — No. It detects statistical deviations from
normal behaviour. Malware is one possible cause among many, and the tool explicitly
refuses to make that claim.

**Q33. "Are these numbers real?"** — Yes. Every production metric comes from `psutil`
through the backend. The only synthetic data is the ML *training prior*, and the UI
labelling makes clear when a verdict came from the rule-based cold start.

**Q34. "Why does a metric show a dash?"** — Because the OS denied read access to that
field (usually a privileged process). We report unavailability rather than a guess.

**Q35. "What if the API key is missing?"** — The Doctor falls back to a deterministic
local analysis and flags `degraded: true`. Nothing breaks.

# SENTINEL OS — Architecture

> AI-Powered System Intelligence & Diagnostics Platform
> B.Tech AIML · 5th Semester · Operating Systems PBL · Windows 10/11

---

## 1. Design principles

| Principle | How it is enforced |
| --- | --- |
| **Local-first** | Backend binds to `127.0.0.1`. CORS allows only local origins. No cloud dependency for monitoring. |
| **Measure, never invent** | Every metric in the UI originates from `psutil` calls inside `services/monitor.py`. No random or placeholder data exists in production paths. |
| **Read-only** | No code path calls `psutil.Process.terminate()`, deletes files, writes the registry, or runs shell commands. |
| **Degrade gracefully** | Per-process fields owned by `SYSTEM` are returned as `null`; collectors catch exceptions and record them in `monitor.warnings`. |
| **Bounded side effects** | The only write operations are to the local SQLite file and to Performance Lab stress threads, both strictly capped and timeout-guarded. |
| **Honest AI** | Gemini is given measured telemetry, told not to invent numbers, and is never asked for a security verdict. Failures fall back locally and the report is flagged `degraded`. |

---

## 2. Component map

```
backend/app/
├── main.py                    FastAPI app: lifespan, CORS, routers, SPA mount
├── config.py                  Environment-driven configuration + gemini_configured()
│
├── api/                       HTTP + WebSocket surface (thin — delegates to services)
│   ├── system.py              /health, /system/summary|history|disks|network|info|top
│   ├── processes.py           /processes, /processes/{pid}
│   ├── anomaly.py             /anomaly/status|events|train|sensitivity|enabled|evaluate
│   ├── ai.py                  /ai/status|doctor|reports|diagnose/quick
│   ├── recommendations.py     /recommendations
│   ├── history.py             /history/stats|events|export|retention|clear
│   ├── experiments.py         /lab/limits|status|start|stop|compare|cleanup|config
│   ├── forecast.py            /forecast
│   ├── settings.py            /settings (GET/PUT), /about
│   └── ws.py                  /ws/metrics, /ws/processes
│
├── services/
│   ├── monitor.py             SystemMonitor singleton — all psutil sampling
│   ├── orchestrator.py        Background asyncio loop: sample → evaluate → persist → broadcast
│   ├── processes.py           Read-only process table + top-N helpers (memoised sweep)
│   ├── recommendations.py     Threshold evidence engine (read-only output)
│   ├── ai_doctor.py           Gemini REST client + deterministic local fallback
│   ├── forecast.py            OLS + moving-average trend projection with hold-out error
│   └── experiments.py         ExperimentManager — bounded CPU/memory stress with timeouts
│
├── ml/anomaly.py              Isolation Forest engine: features, training, persistence, inference
├── schemas/models.py          Pydantic request/response models
└── database/db.py             SQLite persistence (thread-safe, raw sqlite3)
```

---

## 3. Runtime data flow

```
                      ┌──────────────────────────────────────────────┐
                      │  Orchestrator._loop()   (asyncio task)       │
                      │  every SENTINEL_SAMPLE_INTERVAL seconds      │
                      └───────────────┬──────────────────────────────┘
                                      │ 1. collect_sample()
                                      ▼
                      ┌──────────────────────────────────────────────┐
                      │  SystemMonitor (psutil)                      │
                      │  cpu / per-core / memory / swap / disk I/O   │
                      │  network counters / uptime / processes       │
                      └───────────────┬──────────────────────────────┘
                                      │ 2. sample dict
              ┌───────────────────────┼─────────────────────────┐
              ▼                       ▼                         ▼
   ┌────────────────────┐  ┌────────────────────┐  ┌─────────────────────┐
   │ AnomalyEngine       │  │ metric_samples     │  │ WebSocket broadcast │
   │ .evaluate(sample)   │  │ (periodic persist) │  │ /ws/metrics         │
   │ IsolationForest or  │  │ + blended retrain  │  │ (dropped frames for │
   │ rule-based cold     │  │ every ~20 samples  │  │  slow consumers)    │
   │ start               │  └────────────────────┘  └──────────┬──────────┘
   └─────────┬──────────┘                                     │
             │ is_anomaly?                                    ▼
             ▼                                     ┌─────────────────────┐
   ┌────────────────────┐                          │ React dashboard      │
   │ anomaly_events     │                          │ (live cards, charts) │
   │ (SQLite)           │                          └─────────────────────┘
   └────────────────────┘
```

### Request path (REST)

```
Browser → Vite proxy (/api) → FastAPI router → service → psutil / SQLite / sklearn → JSON
```

---

## 4. Machine-learning pipeline

### 4.1 Feature engineering

`sample_to_features()` turns one metric sample into a fixed 7-element vector:

| # | Feature | Unit | Rationale |
| --- | --- | --- | --- |
| 1 | `cpu_percent` | % | Primary contention signal |
| 2 | `memory_percent` | % | Memory exhaustion signal |
| 3 | `swap_percent` | % | Concrete indicator of memory pressure |
| 4 | `disk_read_mb_s` | MB/s | Storage saturation (read side) |
| 5 | `disk_write_mb_s` | MB/s | Storage saturation (write side) |
| 6 | `process_count` | count | Bookkeeping / spawn storms |
| 7 | `cpu_delta` | % | **Rate of change** — catches sudden workload shifts that a single snapshot misses |

`cpu_delta` is computed against the previous sample, so the model sees dynamics, not just levels.

### 4.2 Cold start

An Isolation Forest needs data before it can detect anything. SENTINEL OS solves this two ways:

1. **Labelled synthetic healthy baseline** — `synthetic_baseline(n=1200, seed=42)` generates a
   reproducible healthy-desktop distribution (Normal/Exponential draws, clipped to physical
   ranges). It is clearly labelled as synthetic everywhere it surfaces in the API/UI.
2. **Rule-based cold-start detector** — engineering thresholds (CPU ≥ 90 %, memory ≥ 90 %,
   swap ≥ 60 %, disk ≥ 120 MB/s, abrupt CPU change ≥ 55 points) guarantee coverage even if
   model training is unavailable.

### 4.3 Training and retraining

```
bootstrap()                       →  load persisted model  OR  train_cold_start()
_loop() every N samples           →  maybe_retrain()
                                     if real_samples ≥ ML_MIN_TRAIN_SAMPLES
                                     blend( synthetic_baseline , real_history )
```

Blending keeps a broad notion of "normal" while adapting to this specific machine, which
prevents the model from drifting into "everything is normal" after a heavy session.

### 4.4 Inference and explanation

```
decision_function(x) → raw ∈ ~[-0.5, 0.5] → score = clamp(0.5 − raw, 0, 1)
predict(x)           → −1 ⇒ anomaly
```

For the anomalous sample the engine reports:

* **which feature deviated most** (largest z-score against the learned distribution),
* the observed value vs the learned **1st–99th percentile range**,
* a **severity** derived from the score, escalated only when an absolute safety threshold is
  additionally breached,
* a plain-language explanation that always ends by stating this is *not* evidence of malware.

### 4.5 Sensitivity

User-facing sensitivity (`0.0 … 1.0`) is interpolated onto the contamination parameter:

| Sensitivity | 0.00 | 0.25 | 0.50 | 0.75 | 1.00 |
| --- | --- | --- | --- | --- | --- |
| Contamination | 0.01 | 0.03 | 0.06 | 0.10 | 0.15 |

The neutral default is `0.5` → `0.06`. Changing sensitivity triggers a retrain so the parameter
actually takes effect.

---

## 5. AI System Doctor

```
question ──┐
           ▼
   _collect_telemetry()   ← measured snapshot + top processes + recent trend + rule findings
           │
           ▼
   GEMINI_API_KEY present?
    ├── yes → call_gemini()  POST /v1beta/models/{model}:generateContent
    │            │ structured JSON schema enforced via system_instruction
    │            │ responseMimeType = application/json
    │            ├── success → _validate_report() (repair/complete any missing section)
    │            └── failure (timeout / HTTP error / bad JSON / blocked) ──┐
    └── no  ─────────────────────────────────────────────────────────────┤
                                                                          ▼
                                                        local_diagnostic()  (rule-based)
                                                                          │
                                                                          ▼
                        report {summary, evidence, possible_causes, confidence,
                                recommended_actions, safety_considerations,
                                engine, degraded, notice, latency_ms}
```

Report sections are validated before return; missing fields are repaired rather than exposed.
The API key is read from the backend environment only and is never serialised into a response.

---

## 6. Database schema (SQLite)

```
anomaly_events
  id, timestamp, detected_at, is_anomaly, score, severity,
  metric, observed_value, expected_low, expected_high,
  evidence, explanation, model, features(JSON), acknowledged
  INDEX (timestamp DESC), INDEX (severity)

diagnostic_reports
  id, timestamp, created_at, engine, model, question,
  summary, evidence(JSON), possible_causes(JSON), confidence,
  recommended_actions(JSON), safety_considerations(JSON),
  degraded, notice, latency_ms
  INDEX (timestamp DESC)

metric_samples
  id, timestamp, cpu_percent, memory_percent, swap_percent,
  disk_read_mb_s, disk_write_mb_s, net_upload_kb_s,
  net_download_kb_s, process_count
  INDEX (timestamp DESC)

settings            key TEXT PRIMARY KEY, value (typed via JSON)
```

* All access is serialised through a module-level `threading.RLock`.
* `apply_retention(days)` prunes rows older than the configured window.
* `clear_table()` is only reachable through an endpoint that requires `confirm=true`.

---

## 7. Performance Lab safety model

```
POST /lab/start  (must carry confirmed=true)
        │
        ├── reject concurrent experiments (409)
        ├── clamp workers ≤ LAB_MAX_CPU_WORKERS
        ├── clamp duration ≤ LAB_MAX_*_SECONDS
        ├── clamp memory   ≤ min(LAB_MAX_MEMORY_MB, 25% of currently available RAM)
        ├── capture measured BASELINE
        ├── spawn daemon threads (CPU busy-loop w/ sleeps, or 16 MB memory chunks)
        ├── watchdog thread records PEAK and enforces the hard timeout
        └── on stop/timeout: release buffers, capture RECOVERY
```

Every value in `baseline` / `peak` / `recovery` is a real measurement from the monitoring agent.
Daemon threads guarantee nothing survives interpreter exit.

---

## 8. Forecasting

* Requires ≥ 20 real persisted samples — otherwise the API explicitly refuses
  (`sufficient_data: false` with an explanatory message) instead of guessing.
* Fits OLS on all but the last *k* samples to measure honest hold-out **MAE / RMSE / MAPE**.
* Refits on the full series, blends the regression anchor with the recent mean (70/30) to
  avoid over-reacting to one noisy sample, then projects the horizon.
* Confidence degrades with hold-out error and with the amount of data available.

---

## 9. Real-time transport

| Endpoint | Payload | Notes |
| --- | --- | --- |
| `WS /ws/metrics` | latest sample + light summary | Producer/consumer queues; frames dropped for slow clients so the agent is never blocked |
| `WS /ws/processes` | process list snapshot | Lower frequency, used by Process Explorer |

REST is used for everything except continuous streaming, which keeps the surface testable.

---

## 10. Security posture

* Bind address and CORS restricted to localhost origins.
* Pydantic validates every request body and query parameter (422 on violation).
* Global exception handler converts unexpected failures into structured JSON, not tracebacks.
* Secrets live only in `backend/.env`; `.env` is git-ignored while `.env.example` documents keys.
* No endpoint exists that can mutate the system (verified by a test asserting no
  kill/terminate route is registered).

---

## 11. Testing strategy

| Layer | Tool | What is verified |
| --- | --- | --- |
| API contracts | `fastapi.testclient` | status codes, payload shapes, validation errors, read-only guarantee |
| ML engine | pytest | feature engineering, cold start, training guards, scoring, persistence, sensitivity mapping |
| Database | pytest | insert/fetch/filter/search, retention, guarded clear, settings |
| Services | pytest | recommendation thresholds & evidence, forecast refusal/accuracy |
| Frontend | Vitest + Testing Library | formatting (`—` for missing data), component states, no fabricated values |

Tests run against a temporary data directory with `GEMINI_API_KEY=""`, so they never touch real
history and never make network calls.

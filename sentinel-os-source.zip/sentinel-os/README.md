# SENTINEL OS

**AI-Powered System Intelligence & Diagnostics Platform**

B.Tech AIML — 5th Semester — Operating Systems Project-Based Learning
Category: Operating Systems + Artificial Intelligence + Machine Learning
Target OS: Windows 10 / 11

---

## 1. What this is

SENTINEL OS is a desktop-style monitoring and diagnostics platform. It reads **real**
Windows performance counters through `psutil`, detects unusual resource behaviour with an
Isolation Forest model, explains problems in plain language (Google Gemini with a fully
offline rule-based fallback), and produces evidence-based, read-only recommendations.

It also stores diagnostic history in SQLite, runs **bounded** stress experiments in a
Performance Lab, and forecasts short-term CPU / memory trends.

> SENTINEL OS is **not** an operating system and **not** a replacement for Windows. It never
> terminates processes, deletes files, edits the registry, disables security software, or
> executes shell commands.

### Honesty guarantees

* Every production number in the UI comes from the local monitoring agent. Nothing is
  randomised or invented.
* Anomaly detection measures **unusual resource behaviour**. It is *not* a malware detector
  and never claims to be one.
* If a metric cannot be read (usually because a process is owned by `SYSTEM` and the agent is
  not elevated) the field degrades to `null` and the UI shows it as unavailable.

---

## 2. Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│  React + TypeScript + Vite + Tailwind + Recharts   (port 5173)      │
│  Overview · Live Monitor · Process Explorer · AI Doctor · Anomaly    │
│  Recommendations · History · Performance Lab · Settings · About     │
└───────────────┬─────────────────────────────────┬───────────────────┘
                │ REST /api/*                     │ WebSocket /ws/metrics
                ▼                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│  FastAPI monitoring agent  (uvicorn, 127.0.0.1:8000)                │
│  ┌──────────────┐ ┌───────────────┐ ┌──────────────┐ ┌───────────┐  │
│  │ monitor      │ │ orchestrator  │ │ recommendations│ │ forecast │  │
│  │ (psutil)     │ │ sampling loop │ │ rules         │ │ OLS      │  │
│  └──────────────┘ └───────────────┘ └──────────────┘ └───────────┘  │
│  ┌──────────────────────┐ ┌──────────────────┐ ┌─────────────────┐  │
│  │ ml/anomaly.py        │ │ services/ai_doctor│ │ experiments.py  │  │
│  │ IsolationForest      │ │ Gemini + fallback │ │ bounded stress  │  │
│  └──────────────────────┘ └──────────────────┘ └─────────────────┘  │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │ database/db.py  —  SQLite (anomaly_events, diagnostic_reports,│   │
│  │                    metric_samples, settings)                  │   │
│  └──────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
                ▲
                │ psutil → CPU / memory / swap / disk / network / processes
                ▼
        Windows 10 / 11 host
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full component breakdown and data flow.

---

## 3. Important: local-only monitoring

The agent must run **on the machine being monitored**, because it reads that machine's real
performance counters. A cloud-hosted preview cannot reach your `127.0.0.1:8000`, and the UI
says so explicitly instead of pretending otherwise. Always start the backend locally first.

---

## 4. Prerequisites

* **Windows 10 / 11**
* **Python 3.11+** (developed and tested on Python 3.15)
* **Node.js 18+** with npm

---

## 5. Installation

### 5.1 Backend (monitoring agent)

```powershell
cd sentinel-os\backend

# create and activate a virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# optional: configure the Gemini API key (see section 7)
Copy-Item .env.example .env
```

### 5.2 Frontend

```powershell
cd sentinel-os\frontend
npm install
```

---

## 6. Running the application

**One-click launcher (recommended on Windows)**

Double-click [`start.bat`](start.bat) in the project root. On the first run it creates
`backend\.venv`, installs the Python requirements, builds the frontend, starts the
monitoring agent and opens <http://127.0.0.1:8000> in your browser. Later runs start
in a few seconds. The launcher window *is* the monitoring-agent console — closing it
stops monitoring. Nothing outside the project folder is modified.

To start it manually instead, open **two** terminals.

**Terminal 1 — backend / monitoring agent**

```powershell
cd sentinel-os\backend
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

* Backend: <http://127.0.0.1:8000>
* Interactive API docs (Swagger UI): <http://127.0.0.1:8000/docs>

**Terminal 2 — frontend**

```powershell
cd sentinel-os\frontend
npm run dev
```

* Frontend: <http://127.0.0.1:5173>

Vite proxies `/api` and `/ws` to `127.0.0.1:8000`, so the browser only ever talks to
`localhost`. The header shows a live **Agent connected / Agent offline** indicator.

**Production-style single-server run (optional)**

```powershell
cd sentinel-os\frontend
npm run build          # emits frontend/dist

cd ..\backend
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
# FastAPI now also serves the built SPA at http://127.0.0.1:8000
```

---

## 7. Environment variables

Copy `backend/.env.example` to `backend/.env` and adjust as needed. Everything has a safe
default, so the application runs with **no** `.env` file at all.

| Variable | Default | Meaning |
| --- | --- | --- |
| `SENTINEL_HOST` | `127.0.0.1` | Bind address (localhost-first) |
| `SENTINEL_PORT` | `8000` | Backend port |
| `SENTINEL_SAMPLE_INTERVAL` | `2.0` | Seconds between monitoring samples |
| `SENTINEL_HISTORY_MAX_POINTS` | `900` | In-memory ring-buffer size |
| `SENTINEL_PROCESS_LIMIT` | `250` | Max processes returned by the API |
| `SENTINEL_DATA_DIR` | `backend/data` | SQLite + model storage directory |
| `SENTINEL_RETENTION_DAYS` | `30` | History retention window |
| `SENTINEL_ML_ENABLED` | `true` | Enable anomaly detection |
| `SENTINEL_ML_MIN_TRAIN_SAMPLES` | `60` | Real samples required before blended retraining |
| `SENTINEL_ML_CONTAMINATION` | `0.06` | Expected anomaly fraction for the baseline model |
| `GEMINI_API_KEY` | *(empty)* | Google Gemini key — **backend only** |
| `GEMINI_MODEL` | `gemini-2.0-flash` | Gemini model name |
| `GEMINI_TIMEOUT` | `30` | Gemini request timeout in seconds |
| `SENTINEL_LAB_MAX_CPU_WORKERS` | `4` | Performance Lab CPU worker ceiling |
| `SENTINEL_LAB_MAX_CPU_SECONDS` | `120` | Performance Lab CPU duration ceiling |
| `SENTINEL_LAB_MAX_MEMORY_MB` | `1024` | Performance Lab memory ceiling |
| `SENTINEL_LAB_MAX_MEMORY_SECONDS` | `120` | Performance Lab memory duration ceiling |

### Enabling Gemini (optional)

The AI System Doctor works **fully offline** out of the box. To enable Gemini:

1. Copy `backend/.env.example` → `backend/.env`.
2. Add `GEMINI_API_KEY=your_actual_key`.
3. Restart the backend.
4. `GET /api/ai/status` will then report `"engine": "gemini"`.

The key is read only by the backend process. It is never sent to, or referenced by, frontend
code. If the key is missing, invalid, times out, or returns an unusable payload, the Doctor
transparently falls back to the local rule-based engine and marks the report `degraded`.

---

## 8. Testing

**Backend** (pytest + FastAPI `TestClient`, real lifespan, temporary database, no network):

```powershell
cd sentinel-os\backend
.\.venv\Scripts\python.exe -m pytest
```

**Frontend** (Vitest + Testing Library, jsdom):

```powershell
cd sentinel-os\frontend
npm run test          # single run
npm run test:watch    # watch mode
```

**Type-check + production build of the frontend:**

```powershell
cd sentinel-os\frontend
npm run build
```

Coverage includes: CPU / RAM / disk / process collection, permission-error degradation, all
REST contracts, anomaly detection (including model cold start and persistence), sensitivity
mapping, recommendation generation, Gemini failure → local fallback, database persistence and
retention, Performance Lab lifecycle & cleanup, and frontend rendering.

---

## 9. Project structure

```
sentinel-os/
├── backend/
│   ├── app/
│   │   ├── main.py            # FastAPI app, lifespan, CORS, static SPA mount
│   │   ├── config.py          # env-var driven configuration
│   │   ├── api/               # REST + WebSocket routers
│   │   ├── schemas/           # Pydantic models
│   │   ├── services/          # monitor, orchestrator, ai_doctor,
│   │   │                      # recommendations, forecast, experiments, processes
│   │   ├── ml/                # Isolation Forest anomaly engine
│   │   └── database/          # SQLite layer
│   ├── tests/                 # pytest suite
│   ├── requirements.txt
│   ├── pytest.ini
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/        # ui primitives, charts, layout
│   │   ├── pages/             # the ten sidebar views
│   │   ├── hooks/             # useAsync, useMetricsStream
│   │   ├── services/          # api client, ws client, formatters
│   │   ├── layouts/           # AppLayout (sidebar + topbar)
│   │   └── types/
│   ├── package.json
│   └── vite.config.ts
├── docs/
│   ├── ARCHITECTURE.md
│   ├── API.md
│   ├── PBL_REPORT_OUTLINE.md
│   └── VIVA_QA.md
├── README.md
└── .gitignore
```

---

## 10. The ten views

| View | Purpose |
| --- | --- |
| **Overview** | Health score, CPU / RAM / disk / network cards, live charts, top processes, recent anomalies, AI insight |
| **Live Monitor** | High-frequency WebSocket stream, per-core CPU, sparklines, disk & network throughput |
| **Process Explorer** | Searchable / sortable read-only process table with a detail panel |
| **AI System Doctor** | Chat interface grounded in measured telemetry; Gemini + offline fallback |
| **Anomaly Detection** | Isolation Forest status, sensitivity control, historical anomalies with evidence |
| **Smart Recommendations** | Evidence-based, read-only optimisation guidance |
| **Diagnostic History** | Search, filters, detail view, CSV / JSON export, retention, guarded clear |
| **Performance Lab** | Bounded CPU / memory experiments with baseline → peak → recovery comparison and forecasting |
| **Settings** | Monitoring interval, sensitivity, retention, Gemini setup instructions |
| **About** | Capabilities, limitations, architecture and safety disclaimer |

---

## 11. Safety model

* **Localhost-first.** Binds to `127.0.0.1`; CORS allows only local origins.
* **Read-only by design.** No process termination, file deletion, registry edits, or command
  execution anywhere in the codebase.
* **Bounded experiments.** Performance Lab requires explicit confirmation, clamps to
  server-side ceilings, caps memory at 25% of currently available RAM, and always times out.
* **Secrets stay server-side.** The Gemini key lives only in the backend environment.
* **Graceful degradation.** Missing privileges reduce available fields; they never crash the
  agent, and the UI marks affected data as unavailable.

---

## 12. Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| UI shows *Agent offline* | Backend not running. Start it on `127.0.0.1:8000` (section 6). |
| Some process usernames / paths are `null` | Those processes are owned by `SYSTEM`. Expected without elevation; the UI labels it. |
| AI Doctor says `degraded` | `GEMINI_API_KEY` not set (or Gemini unreachable). Offline engine used — this is normal. |
| `npm run dev` fails with a script-execution error on Windows | Use `npm.cmd` instead of `npm`, or run `Set-ExecutionPolicy -Scope Process Bypass`. |
| Port already in use | `$env:SENTINEL_PORT=8010` for the backend; change `server.port` in `vite.config.ts` for the frontend. |

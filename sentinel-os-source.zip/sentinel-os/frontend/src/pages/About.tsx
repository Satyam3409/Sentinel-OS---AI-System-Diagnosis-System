import { Boxes, CheckCircle2, Cpu, ExternalLink, Info, MonitorPlay, ShieldAlert, TriangleAlert } from 'lucide-react'
import { Badge, ErrorState, LoadingState, Panel } from '../components/ui/Primitives'
import { formatDateTime } from '../services/format'
import type { PageContext } from '../layouts/AppLayout'
import { api } from '../services/api'
import { useAsync } from '../hooks/useAsync'

export function AboutPage(_context: PageContext) {
  const { data, loading, error, reload } = useAsync((signal) => api.about(signal), [])

  if (loading && !data) {
    return (
      <Panel title="About SENTINEL OS">
        <LoadingState label="Reading application metadata…" />
      </Panel>
    )
  }
  if (error && !data) {
    return (
      <Panel title="About SENTINEL OS">
        <ErrorState message={error} onRetry={() => void reload()} />
      </Panel>
    )
  }
  if (!data) return null

  const meta = [
    { label: 'Full name', value: data.full_name },
    { label: 'Version', value: `v${data.version}` },
    { label: 'Category', value: data.category },
    { label: 'Target OS', value: data.target_os },
    { label: 'Host platform', value: data.host_platform },
  ]

  return (
    <div className="space-y-5">
      <Panel>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-electric-500/40 bg-electric-600/15 shadow-glow">
              <Cpu className="h-7 w-7 text-electric-300" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-[0.18em] text-white">SENTINEL OS</h1>
              <p className="mt-0.5 text-xs text-white/50">{data.full_name}</p>
            </div>
          </div>
          <Badge tone="info" dot>
            AI-powered system intelligence
          </Badge>
        </div>
        <p className="mt-4 max-w-3xl text-xs leading-relaxed text-white/60">{data.purpose}</p>
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {meta.map((entry) => (
            <div key={entry.label} className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
              <p className="text-2xs uppercase tracking-[0.14em] text-white/35">{entry.label}</p>
              <p className="mt-1 text-xs text-white/75">{entry.value}</p>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="System architecture" subtitle="Clear separation between the React client, the FastAPI agent and the ML/AI services">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {Object.entries(data.architecture).map(([layer, modules]) => (
            <div key={layer} className="rounded-lg border border-panel-border bg-canvas-soft p-4">
              <p className="mb-2.5 flex items-center gap-2 text-2xs font-semibold uppercase tracking-[0.16em] text-electric-300">
                <Boxes className="h-3.5 w-3.5" /> {layer}
              </p>
              <ul className="space-y-1.5">
                {modules.map((module) => (
                  <li key={module} className="flex items-start gap-2 text-xs text-white/60">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-electric-400" />
                    <span className="font-mono leading-relaxed">{module}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <Panel title="Capabilities" subtitle="Implemented and verified in this build">
          <ul className="space-y-2">
            {data.capabilities.map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-xs leading-relaxed text-white/65">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-alert-ok" />
                {item}
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="Limitations & honest scope" subtitle="What this application deliberately does not do">
          <ul className="space-y-2">
            {data.limitations.map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-xs leading-relaxed text-white/65">
                <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-alert-warning" />
                {item}
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
        <Panel title="Safety disclaimer">
          <div className="flex items-start gap-3">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-alert-critical" />
            <p className="text-xs leading-relaxed text-white/65">{data.disclaimer}</p>
          </div>
        </Panel>

        <Panel title="Live status">
          <div className="space-y-1">
            {Object.entries(data.status).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between border-b border-panel-border/60 py-1.5 text-xs last:border-0">
                <span className="text-white/45">{key.replace(/_/g, ' ')}</span>
                <span className="font-mono text-2xs text-electric-200">
                  {typeof value === 'boolean' ? (value ? 'yes' : 'no') : typeof value === 'number' && key.includes('time') ? formatDateTime(value) : String(value)}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <Panel title="Project context">
        <div className="grid grid-cols-1 gap-4 text-xs sm:grid-cols-3">
          <div className="flex items-start gap-3 rounded-lg border border-panel-border bg-canvas-soft px-3.5 py-3">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
            <div>
              <p className="font-semibold text-white/80">Academic PBL</p>
              <p className="mt-1 leading-relaxed text-white/50">
                Built for a B.Tech AIML (5th semester) Operating Systems project-based learning module.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-lg border border-panel-border bg-canvas-soft px-3.5 py-3">
            <MonitorPlay className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
            <div>
              <p className="font-semibold text-white/80">Local-first</p>
              <p className="mt-1 leading-relaxed text-white/50">
                The monitoring agent binds to 127.0.0.1. Run it on the Windows machine you want to observe.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-lg border border-panel-border bg-canvas-soft px-3.5 py-3">
            <ExternalLink className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
            <div>
              <p className="font-semibold text-white/80">API documentation</p>
              <p className="mt-1 leading-relaxed text-white/50">
                Interactive OpenAPI docs are served by the agent at <span className="font-mono text-electric-200">/docs</span>.
              </p>
            </div>
          </div>
        </div>
      </Panel>
    </div>
  )
}

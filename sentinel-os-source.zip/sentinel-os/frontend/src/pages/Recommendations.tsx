import { useMemo, useState } from 'react'
import {
  AlertTriangle,
  BadgeCheck,
  HardDrive,
  MemoryStick,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Timer,
  Workflow,
} from 'lucide-react'
import { Badge, EmptyState, ErrorState, LoadingState, Panel } from '../components/ui/Primitives'
import { formatDateTime, formatRelative, severityBadgeClass } from '../services/format'
import type { PageContext } from '../layouts/AppLayout'
import type { Recommendation, Severity } from '../types'
import { api } from '../services/api'
import { useAsync } from '../hooks/useAsync'

const SEVERITY_ORDER: Severity[] = ['critical', 'high', 'medium', 'low', 'info']

function triggerIcon(trigger: string) {
  const value = trigger.toLowerCase()
  if (value.includes('memory') || value.includes('swap')) return MemoryStick
  if (value.includes('disk') || value.includes('storage')) return HardDrive
  if (value.includes('process')) return Workflow
  if (value.includes('uptime')) return Timer
  return Sparkles
}

function RecommendationCard({ item }: { item: Recommendation }) {
  const Icon = triggerIcon(item.trigger)
  return (
    <article className="panel panel-sheen overflow-hidden">
      <div className="flex items-start justify-between gap-3 border-b border-panel-border px-4 py-3">
        <div className="flex min-w-0 items-start gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-panel-border bg-panel-light">
            <Icon className="h-4 w-4 text-electric-300" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">{item.trigger}</p>
            <p className="mt-0.5 font-mono text-2xs text-white/30">{item.id}</p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Badge tone="severity">{item.severity}</Badge>
          {item.read_only && (
            <span className="inline-flex items-center gap-1 text-2xs text-alert-ok" title="No system changes are performed">
              <ShieldCheck className="h-3 w-3" /> read-only
            </span>
          )}
        </div>
      </div>
      <dl className="divide-y divide-panel-border/70 text-xs">
        <Row label="Evidence" value={item.evidence} mono />
        <Row label="Why it matters" value={item.explanation} />
        <Row label="Suggested action" value={item.suggested_action} tone="electric" />
        <Row label="Potential risk" value={item.risk} tone="warn" />
        <Row label="How to verify" value={item.verification} />
      </dl>
    </article>
  )
}

function Row({ label, value, tone, mono }: { label: string; value: string; tone?: 'electric' | 'warn'; mono?: boolean }) {
  const toneClass = tone === 'electric' ? 'text-electric-200' : tone === 'warn' ? 'text-alert-warning' : 'text-white/70'
  return (
    <div className="grid grid-cols-1 gap-1 px-4 py-2.5 sm:grid-cols-[140px_minmax(0,1fr)] sm:gap-4">
      <dt className="text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">{label}</dt>
      <dd className={`${toneClass} ${mono ? 'font-mono text-2xs' : ''} leading-relaxed`}>{value}</dd>
    </div>
  )
}

export function RecommendationsPage(_context: PageContext) {
  const { data, loading, error, reload } = useAsync((signal) => api.recommendations(signal), [], { pollMs: 15000 })
  const [severityFilter, setSeverityFilter] = useState<'all' | Severity>('all')

  const items = useMemo(() => {
    const list = data?.items ?? []
    const filtered = severityFilter === 'all' ? list : list.filter((item) => item.severity === severityFilter)
    return [...filtered].sort((a, b) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity))
  }, [data, severityFilter])

  const counts = useMemo(() => {
    const base: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0, info: 0 }
    for (const item of data?.items ?? []) base[item.severity] = (base[item.severity] ?? 0) + 1
    return base
  }, [data])

  return (
    <div className="space-y-5">
      <Panel
        title="Evidence-based recommendation engine"
        subtitle="Every suggestion is derived from measured metrics — no language model can execute commands here"
        actions={
          <button className="btn" onClick={() => void reload()} type="button">
            <RefreshCw className="h-3.5 w-3.5" /> Re-evaluate
          </button>
        }
      >
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setSeverityFilter('all')}
            className={`chip ${severityFilter === 'all' ? 'border-electric-500/50 bg-electric-500/10 text-electric-200' : ''}`}
          >
            All ({data?.items.length ?? 0})
          </button>
          {SEVERITY_ORDER.map((severity) => (
            <button
              key={severity}
              type="button"
              onClick={() => setSeverityFilter(severity)}
              className={`chip capitalize ${severityFilter === severity ? severityBadgeClass(severity) : ''}`}
            >
              {severity} ({counts[severity] ?? 0})
            </button>
          ))}
          <span className="ml-auto text-2xs text-white/30">
            {data ? `evaluated ${formatRelative(data.timestamp)}` : 'awaiting first evaluation'}
          </span>
        </div>
      </Panel>

      {loading && !data && <Panel><LoadingState label="Evaluating measured metrics…" /></Panel>}
      {error && !data && (
        <Panel>
          <ErrorState message={error} onRetry={() => void reload()} />
        </Panel>
      )}

      {data && items.length === 0 && (
        <Panel>
          <EmptyState
            message="No recommendations — measured metrics are within healthy thresholds."
            hint="Thresholds: CPU 70% · memory 75% · swap 35% · disk 80% · storage free 20% · disk I/O 60 MB/s · processes 350 · uptime 7 days"
          />
        </Panel>
      )}

      <div className="grid grid-cols-1 gap-5 2xl:grid-cols-2">
        {items.map((item) => (
          <RecommendationCard key={item.id} item={item} />
        ))}
      </div>

      <Panel title="Safety model">
        <div className="grid grid-cols-1 gap-4 text-xs sm:grid-cols-2">
          <div className="flex items-start gap-3 rounded-lg border border-panel-border bg-canvas-soft px-3.5 py-3">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-alert-ok" />
            <div>
              <p className="font-semibold text-white/80">Read-only by design</p>
              <p className="mt-1 leading-relaxed text-white/50">
                Recommendations describe observations and suggest actions for you to take manually. SENTINEL OS never
                terminates processes, deletes files, edits the registry or disables security tooling.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-lg border border-panel-border bg-canvas-soft px-3.5 py-3">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-alert-warning" />
            <div>
              <p className="font-semibold text-white/80">No LLM command execution</p>
              <p className="mt-1 leading-relaxed text-white/50">
                The AI System Doctor explains findings but its output is never parsed into shell commands. This page is
                produced entirely by deterministic threshold rules.
              </p>
            </div>
          </div>
        </div>
        {data && (
          <p className="mt-4 flex items-center gap-2 text-2xs text-white/30">
            <BadgeCheck className="h-3.5 w-3.5 text-electric-400" />
            Generated {formatDateTime(data.timestamp)} from live psutil measurements
          </p>
        )}
      </Panel>
    </div>
  )
}

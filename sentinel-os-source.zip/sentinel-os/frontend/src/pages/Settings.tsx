import { useEffect, useState } from 'react'
import {
  Check,
  KeyRound,
  RefreshCw,
  Save,
  Server,
  SlidersHorizontal,
  Sparkles,
  TriangleAlert,
} from 'lucide-react'
import { Badge, ErrorState, LoadingState, Panel } from '../components/ui/Primitives'
import type { PageContext } from '../layouts/AppLayout'
import { api } from '../services/api'
import { useAsync } from '../hooks/useAsync'

export function SettingsPage(_context: PageContext) {
  const { data, loading, error, reload, setData } = useAsync((signal) => api.settings(signal), [])
  const [sampleInterval, setSampleInterval] = useState(2)
  const [sensitivity, setSensitivity] = useState(0.5)
  const [retentionDays, setRetentionDays] = useState(30)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [saveError, setSaveError] = useState<string | null>(null)

  useEffect(() => {
    if (!data) return
    setSampleInterval(data.settings.sample_interval)
    setSensitivity(data.settings.sensitivity)
    setRetentionDays(data.settings.retention_days)
  }, [data])

  const save = async () => {
    setSaving(true)
    setSaveError(null)
    setSaved(false)
    try {
      const updated = await api.updateSettings({
        sample_interval: sampleInterval,
        sensitivity,
        retention_days: retentionDays,
        data_source: 'live',
      })
      setData(updated)
      setSaved(true)
      window.setTimeout(() => setSaved(false), 2500)
    } catch (err) {
      setSaveError((err as Error).message)
    } finally {
      setSaving(false)
    }
  }

  if (loading && !data) {
    return (
      <Panel title="Settings">
        <LoadingState label="Reading effective configuration…" />
      </Panel>
    )
  }
  if (error && !data) {
    return (
      <Panel title="Settings">
        <ErrorState message={error} onRetry={() => void reload()} />
      </Panel>
    )
  }
  if (!data) return null

  return (
    <div className="space-y-5">
      <Panel
        title="Monitoring & analysis"
        subtitle="These values are applied by the backend at runtime"
        actions={
          <>
            <button className="btn" onClick={() => void reload()} type="button">
              <RefreshCw className="h-3.5 w-3.5" /> Reload
            </button>
            <button className="btn btn-primary" disabled={saving} onClick={() => void save()} type="button">
              {saving ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : saved ? <Check className="h-3.5 w-3.5" /> : <Save className="h-3.5 w-3.5" />}
              {saved ? 'Saved' : 'Save changes'}
            </button>
          </>
        }
      >
        {saveError && (
          <p className="mb-3 rounded-lg border border-alert-critical/40 bg-alert-critical/10 px-3 py-2 text-2xs text-alert-critical">
            {saveError}
          </p>
        )}
        <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
          <div>
            <label className="label">Sample interval (seconds)</label>
            <input
              className="input"
              type="number"
              min={1}
              max={30}
              value={sampleInterval}
              onChange={(event) => setSampleInterval(Number(event.target.value))}
            />
            <p className="mt-1.5 text-2xs text-white/35">How often the agent collects a real psutil sample.</p>
          </div>
          <div>
            <label className="label">Anomaly sensitivity</label>
            <input
              className="input"
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={sensitivity}
              onChange={(event) => setSensitivity(Number(event.target.value))}
            />
            <p className="mt-1.5 text-2xs text-white/35">
              {sensitivity.toFixed(2)} · higher values flag more behaviour as unusual (Isolation Forest contamination).
            </p>
          </div>
          <div>
            <label className="label">Retention (days)</label>
            <input
              className="input"
              type="number"
              min={1}
              max={365}
              value={retentionDays}
              onChange={(event) => setRetentionDays(Number(event.target.value))}
            />
            <p className="mt-1.5 text-2xs text-white/35">Metric samples older than this window are pruned.</p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {Object.entries(data.effective).map(([key, value]) => (
            <div key={key} className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
              <p className="text-2xs uppercase tracking-[0.14em] text-white/35">{key.replace(/_/g, ' ')}</p>
              <p className="mt-1 font-mono text-xs text-electric-200">{String(value)}</p>
            </div>
          ))}
        </div>
      </Panel>

      <Panel
        title="Gemini AI configuration"
        subtitle="The API key never leaves the backend — the browser cannot read or send it"
        actions={
          <Badge tone={data.api_configuration.gemini_configured ? 'ok' : 'warn'} dot>
            {data.api_configuration.gemini_configured ? 'configured' : 'not configured'}
          </Badge>
        }
      >
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          <div className="space-y-3">
            <div className="flex items-start gap-3 rounded-lg border border-panel-border bg-canvas-soft px-3.5 py-3">
              <KeyRound className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
              <div className="text-xs">
                <p className="font-semibold text-white/80">Environment variable</p>
                <p className="mt-1 font-mono text-2xs text-electric-200">{data.api_configuration.gemini_env_var}</p>
                <p className="mt-1.5 leading-relaxed text-white/50">{data.api_configuration.api_key_exposure}</p>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-lg border border-panel-border bg-canvas-soft px-3.5 py-3">
              <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
              <div className="text-xs">
                <p className="font-semibold text-white/80">Model</p>
                <p className="mt-1 font-mono text-2xs text-electric-200">{data.api_configuration.gemini_model}</p>
              </div>
            </div>
            {!data.api_configuration.gemini_configured && (
              <div className="flex items-start gap-3 rounded-lg border border-alert-warning/40 bg-alert-warning/10 px-3.5 py-3">
                <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-alert-warning" />
                <p className="text-2xs leading-relaxed text-alert-warning">
                  Without a key the AI System Doctor automatically uses the built-in deterministic rule engine. All other
                  modules (monitoring, processes, ML anomalies, history, lab) work fully offline.
                </p>
              </div>
            )}
          </div>
          <div className="rounded-lg border border-panel-border bg-canvas-soft px-4 py-3">
            <p className="mb-2 text-2xs font-semibold uppercase tracking-[0.14em] text-white/40">Enable Gemini</p>
            <ol className="space-y-2 text-xs text-white/60">
              {data.api_configuration.how_to_enable.map((step, index) => (
                <li key={step} className="flex gap-2.5">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded border border-panel-border font-mono text-2xs text-electric-300">
                    {index + 1}
                  </span>
                  <span className="leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <Panel title="Local agent" subtitle="Localhost-first by design">
          <div className="space-y-0.5">
            <div className="flex items-center justify-between border-b border-panel-border/60 py-2 text-xs">
              <span className="flex items-center gap-2 text-white/45">
                <Server className="h-3.5 w-3.5" /> Bind address
              </span>
              <span className="font-mono text-electric-200">
                {data.server.host}:{data.server.port}
              </span>
            </div>
            <div className="border-b border-panel-border/60 py-2 text-xs">
              <span className="flex items-center gap-2 text-white/45">
                <SlidersHorizontal className="h-3.5 w-3.5" /> Allowed CORS origins
              </span>
              <div className="mt-1.5 flex flex-wrap gap-1">
                {data.server.allowed_origins.map((origin) => (
                  <span key={origin} className="rounded border border-panel-border bg-canvas-soft px-1.5 py-0.5 font-mono text-2xs text-white/55">
                    {origin}
                  </span>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between py-2 text-xs">
              <span className="text-white/45">Data directory</span>
              <span className="max-w-[60%] truncate font-mono text-2xs text-white/60">{data.server.data_dir}</span>
            </div>
          </div>
        </Panel>

        <Panel title="Runtime capabilities" subtitle="What can be changed without restarting the agent">
          <div className="space-y-2">
            {Object.entries(data.can_apply_at_runtime).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between border-b border-panel-border/60 py-2 text-xs last:border-0">
                <span className="text-white/55">{key.replace(/_/g, ' ')}</span>
                <Badge tone={value === true ? 'ok' : value === false ? 'warn' : 'neutral'}>
                  {String(value)}
                </Badge>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  )
}

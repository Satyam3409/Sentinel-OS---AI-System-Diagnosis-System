import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Database,
  Download,
  FileText,
  RefreshCw,
  Search,
  Trash2,
} from 'lucide-react'
import { Badge, EmptyState, ErrorState, LoadingState, Panel } from '../components/ui/Primitives'
import { ConfirmDialog } from '../components/ui/ConfirmDialog'
import { API_BASE, api } from '../services/api'
import {
  formatDateTime,
  formatNumber,
  formatRelative,
  metricLabel,
  metricUnit,
  truncate,
} from '../services/format'
import type { PageContext } from '../layouts/AppLayout'
import type { HistoryListItem } from '../types'
import { useAsync } from '../hooks/useAsync'

const PAGE_SIZE = 25
const RANGES = [
  { id: 'all', label: 'All time' },
  { id: '24h', label: 'Last 24h' },
  { id: '7d', label: 'Last 7 days' },
  { id: '30d', label: 'Last 30 days' },
]
const SEVERITIES = ['all', 'critical', 'high', 'medium', 'low', 'info'] as const

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[120px_minmax(0,1fr)] gap-3 py-1.5">
      <span className="text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">{label}</span>
      <span className="break-words text-xs text-white/70">{value}</span>
    </div>
  )
}

function HistoryDetail({ item }: { item: HistoryListItem }) {
  const isAnomaly = item.kind === 'anomaly'
  return (
    <div className="space-y-1">
      <div className="mb-2 flex items-center gap-2">
        {isAnomaly ? <AlertTriangle className="h-4 w-4 text-alert-warning" /> : <FileText className="h-4 w-4 text-electric-300" />}
        <span className="text-sm font-semibold text-white">{isAnomaly ? 'Anomaly event' : 'Diagnostic report'}</span>
        <Badge tone="severity" className="ml-auto">
          {item.severity}
        </Badge>
      </div>
      <DetailRow label="Record ID" value={`#${item.id} (${item.kind})`} />
      <DetailRow label="Recorded" value={formatDateTime(item.timestamp)} />
      {isAnomaly ? (
        <>
          <DetailRow label="Metric" value={metricLabel(item.metric ?? '')} />
          <DetailRow label="Observed" value={`${formatNumber(item.observed_value ?? 0, 2)}${metricUnit(item.metric ?? '')}`} />
          <DetailRow
            label="Expected band"
            value={
              item.expected_range
                ? `${formatNumber(item.expected_range[0], 2)} – ${formatNumber(item.expected_range[1], 2)}${metricUnit(item.metric ?? '')}`
                : '—'
            }
          />
          <DetailRow label="Model score" value={formatNumber(item.score ?? 0, 4)} />
          <DetailRow label="Model" value={item.model ?? '—'} />
          <DetailRow label="Evidence" value={item.evidence ?? '—'} />
          <DetailRow label="Explanation" value={item.explanation ?? '—'} />
          <DetailRow label="Acknowledged" value={item.acknowledged ? 'yes' : 'no'} />
        </>
      ) : (
        <>
          <DetailRow label="Engine" value={item.engine ?? '—'} />
          <DetailRow label="Question" value={item.question || '(unspecified)'} />
          <DetailRow label="Summary" value={item.summary ?? '—'} />
          <DetailRow label="Confidence" value={`${Math.round((item.confidence ?? 0) * 100)}%`} />
        </>
      )}
    </div>
  )
}

export function HistoryPage(_context: PageContext) {
  const stats = useAsync((signal) => api.historyStats(signal), [], { pollMs: 30000 })

  const [kind, setKind] = useState('all')
  const [severity, setSeverity] = useState('all')
  const [range, setRange] = useState('all')
  const [search, setSearch] = useState('')
  const [offset, setOffset] = useState(0)
  const [items, setItems] = useState<HistoryListItem[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selected, setSelected] = useState<HistoryListItem | null>(null)
  const [confirmClear, setConfirmClear] = useState(false)
  const [retention, setRetention] = useState(30)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const result = await api.historyEvents({ kind, severity, range, search, limit: PAGE_SIZE, offset })
      setItems(result.items)
      setTotal(result.total)
      setError(null)
      setSelected((current) => (current ? result.items.find((item) => item.id === current.id && item.kind === current.kind) ?? null : null))
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setLoading(false)
    }
  }, [kind, severity, range, search, offset])

  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 250)
    return () => window.clearTimeout(timer)
  }, [load])

  useEffect(() => {
    setOffset(0)
  }, [kind, severity, range, search])

  useEffect(() => {
    if (stats.data?.retention_days) setRetention(stats.data.retention_days)
  }, [stats.data?.retention_days])

  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE))
  const page = Math.floor(offset / PAGE_SIZE) + 1

  const clear = async () => {
    setConfirmClear(false)
    await api.clearHistory('all')
    setOffset(0)
    await Promise.all([load(), stats.reload()])
  }

  const applyRetention = async () => {
    await api.applyRetention(retention)
    await Promise.all([load(), stats.reload()])
  }

  const stat = stats.data
  const statCards = useMemo(
    () => [
      { label: 'Anomaly events', value: stat?.anomaly_events ?? 0, icon: AlertTriangle },
      { label: 'Diagnostic reports', value: stat?.diagnostic_reports ?? 0, icon: FileText },
      { label: 'Metric samples', value: stat?.metric_samples ?? 0, icon: Database },
    ],
    [stat],
  )

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        {statCards.map((card) => (
          <div key={card.label} className="panel panel-sheen px-4 py-4">
            <div className="flex items-center justify-between">
              <p className="text-2xs font-semibold uppercase tracking-[0.16em] text-white/40">{card.label}</p>
              <card.icon className="h-4 w-4 text-electric-300" />
            </div>
            <p className="metric-value mt-2.5">
              {stat ? card.value.toLocaleString() : <span className="skeleton inline-block h-7 w-16" />}
            </p>
            <p className="mt-2 text-2xs text-white/30">
              {stat?.oldest_sample
                ? `${formatRelative(stat.oldest_sample)} → ${stat.newest_sample ? formatRelative(stat.newest_sample) : '—'}`
                : 'no samples stored yet'}
            </p>
          </div>
        ))}
      </div>

      <Panel
        title="Stored diagnostics"
        subtitle={`Every anomaly and AI report is persisted in SQLite · ${stat?.db_path ?? '…'}`}
        actions={
          <>
            <button className="btn" onClick={() => void load()} type="button">
              <RefreshCw className="h-3.5 w-3.5" /> Refresh
            </button>
            <a className="btn" href={`${API_BASE}/history/export?format=csv&kind=${kind}&range=${range}`} download>
              <Download className="h-3.5 w-3.5" /> CSV
            </a>
            <a className="btn" href={`${API_BASE}/history/export?format=json&kind=${kind}&range=${range}`} download>
              <Download className="h-3.5 w-3.5" /> JSON
            </a>
            <button className="btn btn-danger" onClick={() => setConfirmClear(true)} type="button">
              <Trash2 className="h-3.5 w-3.5" /> Clear
            </button>
          </>
        }
      >
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/30" />
            <input
              className="input !pl-8"
              placeholder="Search evidence, summary, metric…"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <select className="input !w-auto" value={kind} onChange={(event) => setKind(event.target.value)}>
            <option value="all">All records</option>
            <option value="anomaly">Anomalies</option>
            <option value="report">AI reports</option>
          </select>
          <select className="input !w-auto" value={severity} onChange={(event) => setSeverity(event.target.value)}>
            {SEVERITIES.map((value) => (
              <option key={value} value={value}>
                {value === 'all' ? 'All severities' : value}
              </option>
            ))}
          </select>
          <div className="flex items-center gap-1">
            {RANGES.map((entry) => (
              <button
                key={entry.id}
                type="button"
                onClick={() => setRange(entry.id)}
                className={`chip ${range === entry.id ? 'border-electric-500/50 bg-electric-500/10 text-electric-200' : ''}`}
              >
                {entry.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4">
          {loading && items.length === 0 && <LoadingState label="Querying diagnostic history…" />}
          {error && <ErrorState message={error} onRetry={() => void load()} />}
          {!loading && !error && items.length === 0 && (
            <EmptyState
              message="No records match the current filters."
              hint="Anomaly events appear automatically when the Isolation Forest scores unusual behaviour, and AI reports are saved whenever you consult the System Doctor."
            />
          )}

          {items.length > 0 && (
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
              <div className="overflow-hidden rounded-lg border border-panel-border">
                <table className="w-full border-collapse text-left">
                  <thead>
                    <tr className="bg-panel-light/60">
                      <th className="th">Type</th>
                      <th className="th">Recorded</th>
                      <th className="th">Severity</th>
                      <th className="th">Detail</th>
                      <th className="th text-right">Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item) => {
                      const isActive = selected?.id === item.id && selected?.kind === item.kind
                      return (
                        <tr
                          key={`${item.kind}-${item.id}`}
                          onClick={() => setSelected(item)}
                          className={`cursor-pointer border-t border-panel-border/70 transition-colors hover:bg-electric-500/5 ${
                            isActive ? 'bg-electric-500/10' : ''
                          }`}
                        >
                          <td className="td">
                            <span className="inline-flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide text-white/60">
                              {item.kind === 'anomaly' ? <AlertTriangle className="h-3 w-3" /> : <FileText className="h-3 w-3" />}
                              {item.kind}
                            </span>
                          </td>
                          <td className="td font-mono text-2xs text-white/50">{formatDateTime(item.timestamp)}</td>
                          <td className="td">
                            <Badge tone="severity">{item.severity}</Badge>
                          </td>
                          <td className="td max-w-[280px] truncate text-xs text-white/60">
                            {item.kind === 'anomaly'
                              ? truncate(`${metricLabel(item.metric ?? '')} · ${item.evidence ?? ''}`, 70)
                              : truncate(item.question || item.summary || '—', 70)}
                          </td>
                          <td className="td text-right font-mono text-2xs text-white/55">
                            {item.kind === 'anomaly' ? formatNumber(item.score ?? 0, 3) : `${Math.round((item.confidence ?? 0) * 100)}%`}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>

              <div className="rounded-lg border border-panel-border bg-canvas-soft p-4">
                {selected ? (
                  <HistoryDetail item={selected} />
                ) : (
                  <EmptyState message="Select a record to inspect its full detail." />
                )}
              </div>
            </div>
          )}

          {total > 0 && (
            <div className="mt-4 flex items-center justify-between text-2xs text-white/40">
              <span>
                {offset + 1}–{Math.min(offset + PAGE_SIZE, total)} of {total.toLocaleString()}
              </span>
              <div className="flex items-center gap-2">
                <button className="btn !px-2 !py-1" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}>
                  <ChevronLeft className="h-3.5 w-3.5" />
                </button>
                <span className="font-mono">
                  page {page} / {pageCount}
                </span>
                <button
                  className="btn !px-2 !py-1"
                  disabled={offset + PAGE_SIZE >= total}
                  onClick={() => setOffset(offset + PAGE_SIZE)}
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </Panel>

      <Panel title="Data retention" subtitle="Keeps the local database bounded — old samples are pruned automatically">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="label">Retention period (days)</label>
            <input
              className="input !w-36"
              type="number"
              min={1}
              max={365}
              value={retention}
              onChange={(event) => setRetention(Number(event.target.value))}
            />
          </div>
          <button className="btn btn-primary" onClick={() => void applyRetention()} type="button">
            Apply retention
          </button>
          <p className="text-2xs leading-relaxed text-white/40">
            Retention removes metric samples older than the configured window. Anomaly events and diagnostic reports are
            preserved for your project record.
          </p>
        </div>
      </Panel>

      <ConfirmDialog
        open={confirmClear}
        destructive
        title="Clear all diagnostic history?"
        description="This permanently deletes stored anomaly events, diagnostic reports and metric samples from the local SQLite database. This cannot be undone. Export first if you need the data for your PBL submission."
        confirmLabel="Delete everything"
        onConfirm={() => void clear()}
        onCancel={() => setConfirmClear(false)}
      />
    </div>
  )
}

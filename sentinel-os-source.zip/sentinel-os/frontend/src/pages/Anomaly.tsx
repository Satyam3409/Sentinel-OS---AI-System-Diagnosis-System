import { useState } from 'react'
import {
  Activity,
  Brain,
  Check,
  Filter,
  RefreshCw,
  Search,
  ShieldAlert,
  SlidersHorizontal,
  Trash2,
  TrendingUp,
} from 'lucide-react'
import { MetricChart } from '../components/charts/MetricChart'
import { Badge, EmptyState, ErrorState, LoadingState, Panel, ProgressBar } from '../components/ui/Primitives'
import { api } from '../services/api'
import { formatClock, formatDateTime, formatRelative, metricLabel, metricUnit, severityBadgeClass } from '../services/format'
import { useAsync } from '../hooks/useAsync'
import type { PageContext } from '../layouts/AppLayout'

const SEVERITIES = ['all', 'critical', 'high', 'medium', 'low', 'info'] as const

export function AnomalyPage({ live }: PageContext) {
  const [severity, setSeverity] = useState<(typeof SEVERITIES)[number]>('all')
  const [search, setSearch] = useState('')
  const [training, setTraining] = useState(false)
  const [trainMessage, setTrainMessage] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<number | null>(null)

  const status = useAsync((signal) => api.anomalyStatus(12, signal), [], { pollMs: 8000 })
  const events = useAsync(
    (signal) =>
      api.anomalyEvents(
        { limit: 60, severity: severity === 'all' ? undefined : severity, search: search.trim() || undefined },
        signal,
      ),
    [severity, search],
    { pollMs: 15000 },
  )

  const retrain = async () => {
    setTraining(true)
    setTrainMessage(null)
    try {
      const result = await api.trainAnomaly()
      setTrainMessage(
        `Model retrained on ${result.trained_samples} samples (source: ${result.training_source})` +
          (result.note ? ` — ${result.note}` : ''),
      )
      await status.reload()
    } catch (error) {
      setTrainMessage((error as Error).message)
    } finally {
      setTraining(false)
    }
  }

  const changeSensitivity = async (value: number) => {
    try {
      await api.setSensitivity(value)
      await status.reload()
    } catch (error) {
      setTrainMessage((error as Error).message)
    }
  }

  const toggleEnabled = async (enabled: boolean) => {
    try {
      await api.setAnomalyEnabled(enabled)
      await status.reload()
    } catch (error) {
      setTrainMessage((error as Error).message)
    }
  }

  const acknowledge = async (id: number, value: boolean) => {
    setBusyId(id)
    try {
      await api.acknowledgeAnomaly(id, value)
      await events.reload()
    } finally {
      setBusyId(null)
    }
  }

  const remove = async (id: number) => {
    setBusyId(id)
    try {
      await api.deleteAnomaly(id)
      await events.reload()
      await status.reload()
    } finally {
      setBusyId(null)
    }
  }

  const data = status.data
  const historyForChart = live.history.slice(-90).map((sample) => ({
    timestamp: sample.timestamp,
    cpu_percent: sample.cpu_percent,
    memory_percent: sample.memory_percent,
  }))

  return (
    <div className="space-y-5">
      {/* Engine status */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
        <Panel
          title="Anomaly detection engine"
          subtitle="Isolation Forest over 7 engineered resource features"
          actions={
            <>
              <Badge tone={data?.enabled ? 'ok' : 'critical'} dot>
                {data?.enabled ? 'Enabled' : 'Disabled'}
              </Badge>
              <Badge tone={data?.model_ready ? 'info' : 'warn'}>
                {data?.mode ?? 'initialising'}
              </Badge>
            </>
          }
        >
          {status.loading && !data ? (
            <LoadingState label="Reading model state…" />
          ) : status.error ? (
            <ErrorState message={status.error} onRetry={() => void status.reload()} />
          ) : data ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                <EngineStat label="Model" value={data.model_ready ? 'Trained' : 'Cold start'} />
                <EngineStat label="Training samples" value={String(data.trained_samples)} />
                <EngineStat label="Contamination" value={data.contamination.toFixed(3)} />
                <EngineStat
                  label="Last score"
                  value={data.last_score !== null ? data.last_score.toFixed(4) : '—'}
                />
              </div>

              <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                <div className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
                  <p className="text-2xs uppercase tracking-[0.12em] text-white/30">Training source</p>
                  <p className="mt-1 font-mono text-xs text-white/80">{data.training_source}</p>
                  <p className="mt-1 text-2xs text-white/35">
                    {data.training_source.includes('synthetic')
                      ? 'Includes a labelled synthetic healthy baseline so detection works from the first second (cold-start handling).'
                      : 'Trained from measured history of this machine.'}
                  </p>
                </div>
                <div className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
                  <p className="text-2xs uppercase tracking-[0.12em] text-white/30">Last evaluation</p>
                  <p className="mt-1 flex items-center gap-2 font-mono text-xs text-white/80">
                    <span
                      className={`inline-flex rounded-md border px-1.5 py-0.5 text-2xs font-semibold uppercase ${severityBadgeClass(
                        data.last_severity ?? 'info',
                      )}`}
                    >
                      {data.last_severity ?? 'info'}
                    </span>
                    {data.is_anomaly ? 'anomaly detected' : 'nominal'}
                  </p>
                  <p className="mt-1 text-2xs text-white/35">
                    Trained at {data.trained_at ? formatDateTime(Date.parse(data.trained_at) / 1000) : '—'}
                  </p>
                </div>
              </div>

              {/* Sensitivity control */}
              <div className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-3">
                <div className="flex items-center justify-between">
                  <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">
                    <SlidersHorizontal className="h-3 w-3" /> Sensitivity
                  </p>
                  <span className="font-mono text-2xs text-white/70">{data.sensitivity.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={data.sensitivity}
                  onChange={(event) => void changeSensitivity(Number(event.target.value))}
                  className="mt-2.5 w-full accent-electric-500"
                />
                <p className="mt-1.5 text-2xs leading-relaxed text-white/35">
                  Maps to Isolation Forest contamination {data.contamination.toFixed(3)}. Higher sensitivity produces
                  more alerts; lower sensitivity only reports severe deviations. Re-training applies the new value.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button className="btn btn-primary" onClick={() => void retrain()} disabled={training} type="button">
                  {training ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Brain className="h-3.5 w-3.5" />}
                  Retrain model
                </button>
                <button className="btn" onClick={() => void toggleEnabled(!data.enabled)} type="button">
                  {data.enabled ? 'Disable detection' : 'Enable detection'}
                </button>
                <button
                  className="btn"
                  onClick={async () => {
                    await api.evaluateAnomaly()
                    await status.reload()
                  }}
                  type="button"
                >
                  <Activity className="h-3.5 w-3.5" />
                  Score now
                </button>
              </div>

              {trainMessage && (
                <p className="rounded-lg border border-panel-border bg-panel-light px-3 py-2 font-mono text-2xs leading-relaxed text-white/60">
                  {trainMessage}
                </p>
              )}
            </div>
          ) : null}
        </Panel>

        <div className="space-y-5">
          <Panel title="Current metrics" subtitle="Inputs to the current sample">
            {data?.current_metrics ? (
              <dl className="space-y-2.5">
                {Object.entries(data.current_metrics).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between gap-3">
                    <dt className="text-2xs uppercase tracking-[0.12em] text-white/35">{metricLabel(key)}</dt>
                    <dd className="font-mono text-2xs text-white/75">
                      {value.toFixed(2)}
                      {metricUnit(key)}
                    </dd>
                  </div>
                ))}
              </dl>
            ) : (
              <EmptyState message="No current metrics" />
            )}
          </Panel>

          <Panel title="Feature vector" subtitle="Engineered features used by the model">
            {data?.last_features && Object.keys(data.last_features).length > 0 ? (
              <dl className="space-y-2.5">
                {Object.entries(data.last_features).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between gap-3">
                    <dt className="text-2xs text-white/45">{metricLabel(key)}</dt>
                    <dd className="font-mono text-2xs text-white/75">
                      {value.toFixed(2)}
                      {metricUnit(key)}
                    </dd>
                  </div>
                ))}
              </dl>
            ) : (
              <EmptyState message="No feature vector yet" hint="Wait for the next monitoring tick." />
            )}
            <p className="mt-3 border-t border-panel-border pt-3 text-2xs leading-relaxed text-white/30">
              Features are extracted per sample: absolute utilisation, swap pressure, disk throughput, process count and
              the CPU change rate between consecutive samples.
            </p>
          </Panel>
        </div>
      </div>

      {/* Resource trend + score */}
      <div className="grid grid-cols-1 gap-5 2xl:grid-cols-2">
        <Panel title="Resource behaviour" subtitle="Live samples feeding the detector">
          <MetricChart
            data={historyForChart}
            series={[
              { key: 'cpu_percent', label: 'CPU', color: '#2f8cff' },
              { key: 'memory_percent', label: 'Memory', color: '#22d39a' },
            ]}
            height={230}
          />
        </Panel>
        <Panel
          title="Anomaly score timeline"
          subtitle="Score from the streamed evaluations"
          actions={data?.last_score !== null && data?.last_score !== undefined ? <Badge tone="info">{data.last_score.toFixed(4)}</Badge> : undefined}
        >
          <ScoreTimeline events={live.events} />
        </Panel>
      </div>

      {/* Event log */}
      <Panel
        title="Detected anomalies"
        subtitle="Persisted in SQLite with severity, evidence and model score"
        actions={<Badge tone="neutral">{events.data?.total ?? 0} records</Badge>}
        bodyClassName="!px-0 !py-0"
      >
        <div className="flex flex-wrap items-center gap-3 border-b border-panel-border px-4 py-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/30" />
            <input
              className="input !pl-9"
              placeholder="Search metric, evidence or explanation…"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-3.5 w-3.5 text-white/30" />
            {SEVERITIES.map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setSeverity(value)}
                className={`btn !px-2.5 !py-1 ${
                  severity === value ? 'border-electric-500/60 bg-electric-600/15 text-white' : ''
                }`}
              >
                {value}
              </button>
            ))}
          </div>
        </div>

        {events.error ? (
          <ErrorState message={events.error} onRetry={() => void events.reload()} />
        ) : events.loading && !events.data ? (
          <LoadingState label="Loading anomaly history…" />
        ) : (events.data?.items.length ?? 0) === 0 ? (
          <EmptyState
            message="No anomalies match the current filter"
            hint="A clean result is the expected steady state. Try exercising the Performance Lab to generate real load and observe the detector respond."
          />
        ) : (
          <div className="max-h-[520px] overflow-auto">
            <table className="w-full min-w-[880px] border-collapse">
              <thead>
                <tr>
                  <th className="th w-28">Detected</th>
                  <th className="th w-24">Severity</th>
                  <th className="th w-40">Metric</th>
                  <th className="th w-28">Observed</th>
                  <th className="th w-36">Expected range</th>
                  <th className="th w-24">Score</th>
                  <th className="th">Evidence</th>
                  <th className="th w-32">Actions</th>
                </tr>
              </thead>
              <tbody>
                {events.data!.items.map((event) => (
                  <tr key={event.id ?? `${event.timestamp}-${event.metric}`} className="align-top transition-colors hover:bg-panel-hover/50">
                    <td className="td whitespace-nowrap font-mono text-2xs text-white/50">
                      {formatClock(event.timestamp)}
                      <span className="block text-white/25">{formatRelative(event.timestamp)}</span>
                    </td>
                    <td className="td">
                      <span
                        className={`inline-flex rounded-md border px-1.5 py-0.5 text-2xs font-semibold uppercase ${severityBadgeClass(
                          event.severity,
                        )}`}
                      >
                        {event.severity}
                      </span>
                    </td>
                    <td className="td">
                      <span className="text-white/80">{metricLabel(event.metric)}</span>
                      <span className="block font-mono text-2xs text-white/25">{event.model}</span>
                    </td>
                    <td className="td font-mono text-white/85">
                      {event.observed_value.toFixed(2)}
                      {metricUnit(event.metric)}
                    </td>
                    <td className="td font-mono text-2xs text-white/50">
                      {event.expected_range[0].toFixed(2)} – {event.expected_range[1].toFixed(2)}
                      {metricUnit(event.metric)}
                    </td>
                    <td className="td">
                      <div className="flex items-center gap-2">
                        <span className="w-12 font-mono text-2xs text-white/70">{event.score.toFixed(3)}</span>
                        <ProgressBar value={event.score * 100} height="h-1" />
                      </div>
                    </td>
                    <td className="td max-w-[380px]">
                      <p className="text-2xs leading-relaxed text-white/60">{event.evidence}</p>
                      <p className="mt-1 text-2xs leading-relaxed text-white/35">{event.explanation}</p>
                    </td>
                    <td className="td">
                      <div className="flex items-center gap-1.5">
                        <button
                          className="btn !px-2 !py-1"
                          type="button"
                          disabled={busyId === event.id}
                          title={event.acknowledged ? 'Un-acknowledge' : 'Acknowledge'}
                          onClick={() => event.id !== null && void acknowledge(event.id, !event.acknowledged)}
                        >
                          <Check className={`h-3 w-3 ${event.acknowledged ? 'text-alert-ok' : ''}`} />
                        </button>
                        <button
                          className="btn !px-2 !py-1"
                          type="button"
                          disabled={busyId === event.id}
                          title="Delete record"
                          onClick={() => event.id !== null && void remove(event.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="border-t border-panel-border px-4 py-2.5 text-2xs leading-relaxed text-white/30">
          An anomaly is a statistical statement about resource behaviour relative to the learned baseline. It is
          <span className="mx-1 font-semibold text-white/50">not</span> proof of malware or intrusion.
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <InfoCard
          icon={<ShieldAlert className="h-4 w-4 text-alert-warning" />}
          title="How detection works"
          body="Every 2 seconds a feature vector is extracted from the measured sample and scored by the Isolation Forest. Points that require many random splits to isolate are considered unusual. The decision function is mapped to a 0–1 anomaly score and classified into info / low / medium / high / critical."
        />
        <InfoCard
          icon={<TrendingUp className="h-4 w-4 text-electric-300" />}
          title="Cold-start handling"
          body="Before real history exists, the model is trained on a labelled synthetic healthy baseline so detection is never unavailable. As real samples accumulate (minimum 60), the model is automatically retrained on a blend of the baseline and this machine's measured history."
        />
        <InfoCard
          icon={<Brain className="h-4 w-4 text-electric-300" />}
          title="Feature engineering"
          body="Features: CPU %, memory %, swap %, disk read MB/s, disk write MB/s, process count and the absolute CPU change between consecutive samples. The change-rate feature is what makes abrupt workload shifts visible to the model."
        />
      </div>
    </div>
  )
}

function EngineStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
      <p className="text-2xs uppercase tracking-[0.12em] text-white/30">{label}</p>
      <p className="mt-1 truncate font-mono text-sm text-white/85">{value}</p>
    </div>
  )
}

function ScoreTimeline({ events }: { events: Array<{ id: number | null; timestamp: number; score: number; severity: string }> }) {
  if (events.length === 0) {
    return (
      <EmptyState
        message="No scored anomalies in this session"
        hint="The score timeline populates as the detector flags unusual samples."
      />
    )
  }
  const points = events
    .slice()
    .reverse()
    .map((event) => ({ timestamp: event.timestamp, score: Math.round(event.score * 1000) / 10 }))
  return <MetricChart data={points} series={[{ key: 'score', label: 'Anomaly score', color: '#ffb020' }]} domain={[0, 100]} height={230} />
}

function InfoCard({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div className="panel panel-sheen px-4 py-4">
      <p className="flex items-center gap-2 text-xs font-semibold text-white/85">
        {icon}
        {title}
      </p>
      <p className="mt-2 text-2xs leading-relaxed text-white/50">{body}</p>
    </div>
  )
}

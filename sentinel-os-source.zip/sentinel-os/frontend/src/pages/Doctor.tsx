import { useEffect, useMemo, useRef, useState } from 'react'
import {
  AlertTriangle,
  Bot,
  BrainCircuit,
  CheckCircle2,
  Gauge,
  Info,
  Lightbulb,
  RefreshCw,
  Send,
  ShieldCheck,
  Sparkles,
  User,
  WifiOff,
} from 'lucide-react'
import { Badge, EmptyState, Panel } from '../components/ui/Primitives'
import { api } from '../services/api'
import { formatRelative } from '../services/format'
import type { DiagnosticReport, DoctorStatus } from '../types'
import type { PageContext } from '../layouts/AppLayout'

interface ChatEntry {
  id: string
  role: 'user' | 'doctor'
  question?: string
  report?: DiagnosticReport
  error?: string
  pending?: boolean
  at: number
}

const DEFAULT_QUESTIONS = [
  'Diagnose my PC.',
  'Why is my PC slow?',
  'Why is RAM usage high?',
  'Which process consumes the most CPU?',
  'Explain this anomaly.',
  'How can I improve my system performance?',
  'Analyze recent system activity.',
]

export function DoctorPage({ live }: PageContext) {
  const [status, setStatus] = useState<DoctorStatus | null>(null)
  const [entries, setEntries] = useState<ChatEntry[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const scrollRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const controller = new AbortController()
    api
      .doctorStatus(controller.signal)
      .then(setStatus)
      .catch(() => setStatus(null))
    return () => controller.abort()
  }, [])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [entries])

  const questions = status?.suggested_questions ?? DEFAULT_QUESTIONS
  const geminiConfigured = status?.gemini_configured ?? false

  const ask = async (question: string) => {
    const trimmed = question.trim()
    if (!trimmed || busy) return
    const entryId = `${Date.now()}`
    setInput('')
    setBusy(true)
    setEntries((prev) => [
      ...prev,
      { id: `${entryId}-q`, role: 'user', question: trimmed, at: Date.now() },
      { id: `${entryId}-a`, role: 'doctor', question: trimmed, pending: true, at: Date.now() },
    ])

    try {
      const response = await api.askDoctor(trimmed, true)
      setEntries((prev) =>
        prev.map((entry) =>
          entry.id === `${entryId}-a` ? { ...entry, pending: false, report: response.report } : entry,
        ),
      )
    } catch (error) {
      setEntries((prev) =>
        prev.map((entry) =>
          entry.id === `${entryId}-a` ? { ...entry, pending: false, error: (error as Error).message } : entry,
        ),
      )
    } finally {
      setBusy(false)
    }
  }

  const quickLocal = async (kind: 'full' | 'cpu' | 'memory' | 'disk' | 'process') => {
    if (busy) return
    setBusy(true)
    const labels: Record<string, string> = {
      full: 'Diagnose my PC.',
      cpu: 'Why is my CPU usage high?',
      memory: 'Why is RAM usage high?',
      disk: 'Is my disk performance healthy?',
      process: 'Which process consumes the most CPU?',
    }
    const entryId = `${Date.now()}`
    setEntries((prev) => [
      ...prev,
      { id: `${entryId}-q`, role: 'user', question: labels[kind], at: Date.now() },
      { id: `${entryId}-a`, role: 'doctor', question: labels[kind], pending: true, at: Date.now() },
    ])
    try {
      const response = await api.quickDiagnosis(kind)
      setEntries((prev) =>
        prev.map((entry) =>
          entry.id === `${entryId}-a` ? { ...entry, pending: false, report: response.report } : entry,
        ),
      )
    } catch (error) {
      setEntries((prev) =>
        prev.map((entry) =>
          entry.id === `${entryId}-a` ? { ...entry, pending: false, error: (error as Error).message } : entry,
        ),
      )
    } finally {
      setBusy(false)
    }
  }

  const liveContext = useMemo(() => {
    const summary = live.summary
    if (!summary) return null
    return {
      cpu: summary.cpu.percent,
      memory: summary.memory.percent,
      swap: summary.memory.swap_percent,
      processes: summary.process_count,
    }
  }, [live.summary])

  return (
    <div className="grid grid-cols-1 gap-5 2xl:grid-cols-[minmax(0,1fr)_360px]">
      <Panel
        title="SENTINEL AI DOCTOR"
        subtitle="Answers are grounded in measured telemetry from this machine"
        actions={
          <>
            <Badge tone={geminiConfigured ? 'ok' : 'warn'} dot>
              {geminiConfigured ? `Gemini · ${status?.gemini_model}` : 'Offline engine'}
            </Badge>
            <button
              className="btn !px-2 !py-1"
              type="button"
              onClick={() => setEntries([])}
              disabled={entries.length === 0}
              title="Clear the conversation"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </>
        }
        bodyClassName="!px-0 !py-0"
      >
        <div ref={scrollRef} className="max-h-[calc(100vh-330px)] min-h-[420px] space-y-4 overflow-y-auto px-4 py-4 scrollbar-thin">
          {entries.length === 0 && (
            <div className="flex flex-col items-center gap-3 py-10 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-electric-500/35 bg-electric-600/12 shadow-glow">
                <BrainCircuit className="h-5 w-5 text-electric-300" />
              </div>
              <p className="text-sm font-semibold text-white">Ask the AI Doctor about this machine</p>
              <p className="max-w-md text-2xs leading-relaxed text-white/45">
                Every answer is produced from a structured telemetry snapshot containing the measured CPU, memory,
                swap, disk, network and process values for this machine. The model is explicitly instructed never to
                invent measurements, and a deterministic rule-based engine answers whenever Gemini is unavailable.
              </p>
              {!geminiConfigured && (
                <div className="mt-1 flex max-w-md items-start gap-2 rounded-lg border border-alert-warning/30 bg-alert-warning/8 px-3 py-2 text-left">
                  <WifiOff className="mt-0.5 h-3.5 w-3.5 shrink-0 text-alert-warning" />
                  <p className="text-2xs leading-relaxed text-alert-warning/90">
                    <span className="font-semibold">Gemini is not configured.</span> The Doctor is answering with its
                    offline rule-based engine. Add <code className="rounded bg-black/40 px-1">GEMINI_API_KEY</code> to
                    <code className="ml-1 rounded bg-black/40 px-1">backend/.env</code> and restart the agent to enable
                    Gemini reasoning.
                  </p>
                </div>
              )}
            </div>
          )}

          {entries.map((entry) =>
            entry.role === 'user' ? (
              <div key={entry.id} className="flex justify-end gap-3">
                <div className="max-w-[78%] rounded-xl rounded-tr-sm border border-electric-500/30 bg-electric-600/15 px-3.5 py-2.5">
                  <p className="text-xs leading-relaxed text-white/90">{entry.question}</p>
                </div>
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-panel-border bg-panel-light">
                  <User className="h-3.5 w-3.5 text-white/50" />
                </div>
              </div>
            ) : (
              <div key={entry.id} className="flex gap-3">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-electric-500/35 bg-electric-600/12">
                  <Bot className="h-3.5 w-3.5 text-electric-300" />
                </div>
                <div className="min-w-0 flex-1">
                  {entry.pending ? (
                    <div className="space-y-2 rounded-xl border border-panel-border bg-panel-light px-3.5 py-3">
                      <div className="skeleton h-3 w-2/3" />
                      <div className="skeleton h-3 w-full" />
                      <div className="skeleton h-3 w-4/5" />
                      <p className="pt-1 font-mono text-2xs text-white/30">
                        Collecting telemetry and generating a grounded diagnosis…
                      </p>
                    </div>
                  ) : entry.error ? (
                    <div className="rounded-xl border border-alert-critical/35 bg-alert-critical/8 px-3.5 py-3">
                      <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.12em] text-alert-critical">
                        <AlertTriangle className="h-3 w-3" /> Diagnostic failed
                      </p>
                      <p className="mt-1 text-2xs leading-relaxed text-white/60">{entry.error}</p>
                    </div>
                  ) : entry.report ? (
                    <ReportCard report={entry.report} />
                  ) : null}
                </div>
              </div>
            ),
          )}
        </div>

        {/* Composer */}
        <div className="border-t border-panel-border px-4 py-3">
          <form
            className="flex items-end gap-2"
            onSubmit={(event) => {
              event.preventDefault()
              void ask(input)
            }}
          >
            <textarea
              className="input min-h-[42px] max-h-32 flex-1 resize-y"
              placeholder="Ask about CPU, memory, disk, processes or a specific anomaly…"
              value={input}
              rows={1}
              onChange={(event) => setInput(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' && !event.shiftKey) {
                  event.preventDefault()
                  void ask(input)
                }
              }}
            />
            <button className="btn btn-primary" type="submit" disabled={busy || input.trim().length === 0}>
              {busy ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              Diagnose
            </button>
          </form>
          <p className="mt-2 text-2xs text-white/25">
            The Doctor is read-only and cannot execute commands, terminate processes, or modify your system.
          </p>
        </div>
      </Panel>

      {/* Sidebar: prompts + status */}
      <div className="space-y-5">
        <Panel title="Suggested questions" subtitle="Tap to run a grounded diagnosis">
          <ul className="space-y-2">
            {questions.map((question) => (
              <li key={question}>
                <button
                  className="w-full rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5 text-left text-xs text-white/70 transition-all duration-200 ease-sentinel hover:border-electric-500/40 hover:bg-panel-hover hover:text-white"
                  type="button"
                  disabled={busy}
                  onClick={() => void ask(question)}
                >
                  {question}
                </button>
              </li>
            ))}
          </ul>
          <div className="mt-4 border-t border-panel-border pt-3">
            <p className="mb-2 text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">
              Instant local diagnosis
            </p>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  ['full', 'Full system'],
                  ['cpu', 'CPU'],
                  ['memory', 'Memory'],
                  ['disk', 'Storage'],
                ] as Array<['full' | 'cpu' | 'memory' | 'disk', string]>
              ).map(([kind, label]) => (
                <button key={kind} className="btn !py-1.5" type="button" disabled={busy} onClick={() => void quickLocal(kind)}>
                  {label}
                </button>
              ))}
            </div>
            <p className="mt-2 text-2xs leading-relaxed text-white/25">
              Runs entirely offline with zero API calls. Useful when Gemini is unavailable or you want an immediate
              deterministic reading.
            </p>
          </div>
        </Panel>

        <Panel title="Grounding context" subtitle="Values injected into the prompt">
          {liveContext ? (
            <dl className="space-y-2.5">
              <ContextRow label="CPU utilisation" value={`${liveContext.cpu.toFixed(1)}%`} />
              <ContextRow label="Memory utilisation" value={`${liveContext.memory.toFixed(1)}%`} />
              <ContextRow label="Swap utilisation" value={`${liveContext.swap.toFixed(1)}%`} />
              <ContextRow label="Process count" value={String(liveContext.processes)} />
              <ContextRow
                label="Telemetry age"
                value={live.lastFrameAt ? formatRelative(live.lastFrameAt / 1000) : '—'}
              />
            </dl>
          ) : (
            <EmptyState message="No telemetry yet" hint="Start the local monitoring agent to provide measured context." />
          )}
          <div className="mt-3 flex items-start gap-2 rounded-lg border border-electric-500/25 bg-electric-600/8 px-3 py-2">
            <Info className="mt-0.5 h-3 w-3 shrink-0 text-electric-200" />
            <p className="text-2xs leading-relaxed text-white/55">
              The backend never sends the API key to the browser. Requests to Gemini go out from the Python process only.
            </p>
          </div>
        </Panel>
      </div>
    </div>
  )
}

function ReportCard({ report }: { report: DiagnosticReport }) {
  const confidencePercent = Math.round(report.confidence * 100)
  return (
    <div className="animate-slide-up space-y-3 rounded-xl border border-panel-border bg-panel-light px-3.5 py-3">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={report.engine === 'gemini' ? 'info' : 'warn'} dot>
          {report.engine === 'gemini' ? `Gemini · ${report.model}` : 'Local rule-based engine'}
        </Badge>
        <Badge tone="neutral">{report.latency_ms.toFixed(0)} ms</Badge>
        <span className="ml-auto font-mono text-2xs text-white/30">{formatRelative(report.timestamp)}</span>
      </div>

      <div>
        <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">
          <Sparkles className="h-3 w-3 text-electric-300" /> Summary
        </p>
        <p className="mt-1.5 text-xs leading-relaxed text-white/85">{report.summary}</p>
      </div>

      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
        <ReportList
          icon={<Gauge className="h-3 w-3 text-electric-300" />}
          title="Observed evidence"
          items={report.evidence}
        />
        <ReportList
          icon={<Lightbulb className="h-3 w-3 text-alert-warning" />}
          title="Possible causes"
          items={report.possible_causes}
        />
        <ReportList
          icon={<CheckCircle2 className="h-3 w-3 text-alert-ok" />}
          title="Recommended actions (read-only)"
          items={report.recommended_actions}
        />
        <ReportList
          icon={<ShieldCheck className="h-3 w-3 text-alert-ok" />}
          title="Safety considerations"
          items={report.safety_considerations}
          tone="muted"
        />
      </div>

      <div className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
        <div className="flex items-center justify-between">
          <span className="text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">Confidence</span>
          <span className="font-mono text-xs text-white/80">{confidencePercent}%</span>
        </div>
        <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-panel-light">
          <div
            className={`h-1.5 rounded-full transition-[width] duration-700 ${
              confidencePercent >= 70 ? 'bg-alert-ok' : confidencePercent >= 45 ? 'bg-alert-warning' : 'bg-alert-critical'
            }`}
            style={{ width: `${confidencePercent}%` }}
          />
        </div>
        <p className="mt-2 text-2xs leading-relaxed text-white/35">
          Confidence reflects how strongly the measured evidence supports the diagnosis. It is not a probability of
          hardware failure or malware.
        </p>
      </div>

      {report.notice && (
        <div className="rounded-lg border border-alert-warning/30 bg-alert-warning/8 px-3 py-2">
          <p className="text-2xs leading-relaxed text-alert-warning/90">{report.notice}</p>
        </div>
      )}
    </div>
  )
}

function ReportList({
  icon,
  title,
  items,
  tone = 'default',
}: {
  icon: React.ReactNode
  title: string
  items: string[]
  tone?: 'default' | 'muted'
}) {
  return (
    <div className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
      <p className="mb-2 flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">
        {icon}
        {title}
      </p>
      {items.length === 0 ? (
        <p className="text-2xs text-white/25">None reported</p>
      ) : (
        <ul className="space-y-1.5">
          {items.map((item, index) => (
            <li
              key={`${title}-${index}`}
              className={`text-2xs leading-relaxed ${tone === 'muted' ? 'text-white/45' : 'text-white/70'}`}
            >
              {item}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

function ContextRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-2xs uppercase tracking-[0.12em] text-white/35">{label}</dt>
      <dd className="font-mono text-2xs text-white/75">{value}</dd>
    </div>
  )
}

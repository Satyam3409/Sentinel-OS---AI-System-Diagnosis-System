import { useEffect, useMemo, useState } from 'react'
import { ArrowDown, ArrowUp, Lock, Search, ShieldAlert, X } from 'lucide-react'
import { Badge, EmptyState, ErrorState, LoadingState, Panel, ProgressBar } from '../components/ui/Primitives'
import { api } from '../services/api'
import { formatBytesMB, formatDateTime, formatPercent } from '../services/format'
import type { ProcessDetail, ProcessInfo, ProcessList } from '../types'
import type { PageContext } from '../layouts/AppLayout'

type SortKey = 'cpu' | 'memory' | 'name' | 'pid'

export function ProcessExplorerPage(_context: PageContext) {
  const [data, setData] = useState<ProcessList | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [sort, setSort] = useState<SortKey>('cpu')
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [selected, setSelected] = useState<number | null>(null)
  const [detail, setDetail] = useState<ProcessDetail | null>(null)
  const [detailError, setDetailError] = useState<string | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)

  const load = async (signal?: AbortSignal) => {
    try {
      const result = await api.processes(
        { limit: 300, sort, search: search.trim() || undefined },
        signal,
      )
      setData(result)
      setError(null)
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const controller = new AbortController()
    void load(controller.signal)
    return () => controller.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sort, search])

  useEffect(() => {
    if (!autoRefresh) return
    const timer = window.setInterval(() => void load(), 4000)
    return () => window.clearInterval(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoRefresh, sort, search])

  useEffect(() => {
    if (selected === null) {
      setDetail(null)
      return
    }
    const controller = new AbortController()
    setDetailLoading(true)
    api
      .process(selected, controller.signal)
      .then((result) => {
        setDetail(result)
        setDetailError(null)
      })
      .catch((err) => setDetailError((err as Error).message))
      .finally(() => setDetailLoading(false))
    return () => controller.abort()
  }, [selected])

  const processes: ProcessInfo[] = data?.processes ?? []

  const totals = useMemo(() => {
    const cpu = processes.reduce((sum, process) => sum + process.cpu_percent, 0)
    const memory = processes.reduce((sum, process) => sum + process.memory_mb, 0)
    return { cpu, memory }
  }, [processes])

  return (
    <div className="grid grid-cols-1 gap-5 2xl:grid-cols-[minmax(0,1fr)_380px]">
      <div className="space-y-4">
        <Panel
          title="Process explorer"
          subtitle="Read-only inspection — SENTINEL OS never terminates processes"
          actions={
            <>
              <label className="chip cursor-pointer">
                <input
                  type="checkbox"
                  className="h-3 w-3 accent-electric-500"
                  checked={autoRefresh}
                  onChange={(event) => setAutoRefresh(event.target.checked)}
                />
                Auto refresh (4s)
              </label>
              <Badge tone="neutral">{data?.total ?? 0} total</Badge>
            </>
          }
          bodyClassName="!px-0 !py-0"
        >
          <div className="flex flex-wrap items-center gap-3 border-b border-panel-border px-4 py-3">
            <div className="relative min-w-[220px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/30" />
              <input
                className="input !pl-9"
                placeholder="Search by process name or exact PID…"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
              {search && (
                <button
                  type="button"
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-white/35 hover:text-white/70"
                  onClick={() => setSearch('')}
                  aria-label="Clear search"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">Sort</span>
              {(['cpu', 'memory', 'name', 'pid'] as SortKey[]).map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSort(key)}
                  className={`btn !px-2.5 !py-1 ${sort === key ? 'border-electric-500/60 bg-electric-600/15 text-white' : ''}`}
                >
                  {key === 'cpu' ? 'CPU' : key === 'memory' ? 'RAM' : key === 'name' ? 'Name' : 'PID'}
                </button>
              ))}
            </div>
          </div>

          {error && processes.length === 0 ? (
            <ErrorState message={error} onRetry={() => void load()} />
          ) : loading && !data ? (
            <LoadingState label="Enumerating processes with psutil…" />
          ) : processes.length === 0 ? (
            <EmptyState
              message="No processes match the current filter"
              hint="Clear the search box or switch the sort order. Some high-privilege processes may not expose all fields."
            />
          ) : (
            <div className="max-h-[calc(100vh-320px)] overflow-auto">
              <table className="w-full min-w-[720px] border-collapse">
                <thead>
                  <tr>
                    <th className="th w-20">PID</th>
                    <th className="th">Name</th>
                    <th className="th w-24">Status</th>
                    <th className="th w-32">CPU share</th>
                    <th className="th w-28">RAM</th>
                    <th className="th w-24">RAM %</th>
                    <th className="th w-16">Threads</th>
                  </tr>
                </thead>
                <tbody>
                  {processes.map((process) => {
                    const isSelected = selected === process.pid
                    return (
                      <tr
                        key={process.pid}
                        onClick={() => setSelected(process.pid)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-electric-600/12' : 'hover:bg-panel-hover/60'
                        }`}
                      >
                        <td className="td font-mono text-white/50">{process.pid}</td>
                        <td className="td">
                          <span className="truncate font-medium text-white/85">{process.name}</span>
                          {process.username && (
                            <span className="ml-2 font-mono text-2xs text-white/25">{process.username}</span>
                          )}
                        </td>
                        <td className="td">
                          <span className="text-2xs uppercase tracking-wide text-white/45">{process.status ?? '—'}</span>
                        </td>
                        <td className="td">
                          <div className="flex items-center gap-2">
                            <span className="w-12 shrink-0 font-mono text-2xs text-white/70">
                              {process.cpu_percent.toFixed(1)}%
                            </span>
                            <ProgressBar value={Math.min(100, process.cpu_percent)} height="h-1" />
                          </div>
                        </td>
                        <td className="td font-mono">{formatBytesMB(process.memory_mb, 0)}</td>
                        <td className="td font-mono">{formatPercent(process.memory_percent, 2)}</td>
                        <td className="td font-mono text-white/45">{process.num_threads ?? '—'}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-panel-border px-4 py-2.5 text-2xs text-white/40">
            <span>
              Showing {processes.length} of {data?.total ?? 0} processes
              {data?.skipped ? ` · ${data.skipped} entries skipped (access denied)` : ''}
            </span>
            <span className="flex items-center gap-3 font-mono">
              <span className="inline-flex items-center gap-1">
                <ArrowUp className="h-3 w-3 text-electric-300" /> Σ CPU {totals.cpu.toFixed(1)}%
              </span>
              <span className="inline-flex items-center gap-1">
                <ArrowDown className="h-3 w-3 text-electric-300" /> Σ RAM {formatBytesMB(totals.memory, 0)}
              </span>
            </span>
          </div>
        </Panel>

        <div className="rounded-lg border border-electric-500/25 bg-electric-600/8 px-4 py-3">
          <p className="flex items-center gap-2 text-2xs font-semibold uppercase tracking-[0.14em] text-electric-200">
            <Lock className="h-3 w-3" /> Read-only by design
          </p>
          <p className="mt-1 text-2xs leading-relaxed text-white/55">
            The Process Explorer is intentionally read-only. No termination endpoint exists anywhere in the API, so no
            component — including the AI Doctor or the recommendation engine — can kill a process. CPU share is
            normalised by the number of logical cores so values are comparable with Windows Task Manager.
          </p>
        </div>
      </div>

      {/* Detail panel */}
      <div className="space-y-5">
        <Panel
          title="Process details"
          subtitle={selected !== null ? `PID ${selected}` : 'Select a process from the table'}
          actions={
            selected !== null && (
              <button className="btn !px-2 !py-1" type="button" onClick={() => setSelected(null)}>
                <X className="h-3.5 w-3.5" />
              </button>
            )
          }
        >
          {selected === null ? (
            <EmptyState message="No process selected" hint="Click any row to inspect its measured attributes." />
          ) : detailLoading && !detail ? (
            <LoadingState label="Loading process detail…" />
          ) : detailError ? (
            <ErrorState message={detailError} onRetry={() => setSelected(selected)} />
          ) : detail ? (
            <div className="space-y-3">
              <div>
                <p className="text-sm font-semibold text-white">{detail.name}</p>
                <p className="font-mono text-2xs text-white/35">
                  {detail.exe ? detail.exe : 'Executable path unavailable (insufficient privileges)'}
                </p>
              </div>
              <dl className="grid grid-cols-2 gap-2.5">
                <DetailCell label="CPU share" value={`${detail.cpu_percent.toFixed(2)}%`} />
                <DetailCell label="Memory" value={formatBytesMB(detail.memory_mb, 1)} />
                <DetailCell label="Memory share" value={formatPercent(detail.memory_percent, 3)} />
                <DetailCell label="Threads" value={String(detail.num_threads ?? '—')} />
                <DetailCell label="Status" value={detail.status ?? '—'} />
                <DetailCell label="User" value={detail.username ?? '—'} />
                <DetailCell label="Started" value={detail.create_time ? formatDateTime(detail.create_time) : '—'} />
                <DetailCell label="Nice" value={String(detail.nice ?? '—')} />
                <DetailCell label="Connections" value={String(detail.connections)} />
                <DetailCell label="Open files" value={String(detail.open_files)} />
              </dl>
              {detail.cmdline && (
                <div className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2">
                  <p className="mb-1 text-2xs uppercase tracking-[0.12em] text-white/30">Command line</p>
                  <p className="break-all font-mono text-2xs leading-relaxed text-white/60">{detail.cmdline}</p>
                </div>
              )}
              <div className="rounded-lg border border-alert-warning/25 bg-alert-warning/8 px-3 py-2">
                <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.12em] text-alert-warning">
                  <ShieldAlert className="h-3 w-3" /> Safety
                </p>
                <p className="mt-1 text-2xs leading-relaxed text-white/55">{detail.note}</p>
              </div>
            </div>
          ) : null}
        </Panel>

        <Panel title="Top memory consumers" subtitle="From the current snapshot">
          {processes.length === 0 ? (
            <EmptyState message="No data" />
          ) : (
            <ul className="space-y-2.5">
              {[...processes]
                .sort((a, b) => b.memory_mb - a.memory_mb)
                .slice(0, 6)
                .map((process) => (
                  <li key={`mem-${process.pid}`} className="flex items-center justify-between gap-3">
                    <button
                      type="button"
                      className="min-w-0 flex-1 truncate text-left text-xs text-white/70 hover:text-white"
                      onClick={() => setSelected(process.pid)}
                    >
                      {process.name}
                    </button>
                    <span className="shrink-0 font-mono text-2xs text-white/50">
                      {formatBytesMB(process.memory_mb, 0)}
                    </span>
                  </li>
                ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  )
}

function DetailCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-panel-border bg-canvas-soft px-2.5 py-2">
      <p className="text-2xs uppercase tracking-[0.12em] text-white/30">{label}</p>
      <p className="mt-0.5 truncate font-mono text-xs text-white/80" title={value}>
        {value}
      </p>
    </div>
  )
}

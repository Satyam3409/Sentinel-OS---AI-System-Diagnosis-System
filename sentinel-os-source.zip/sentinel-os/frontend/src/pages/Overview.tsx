import {
  Activity,
  AlertTriangle,
  BrainCircuit,
  Cpu,
  HardDrive,
  MemoryStick,
  Network,
  Timer,
  Workflow,
  Zap,
} from 'lucide-react'
import { MetricChart } from '../components/charts/MetricChart'
import { HealthGauge } from '../components/ui/Gauge'
import { Badge, EmptyState, Panel, ProgressBar } from '../components/ui/Primitives'
import { StatCard } from '../components/ui/StatCard'
import {
  formatBytesMB,
  formatClock,
  formatNumber,
  formatPercent,
  formatRelative,
  formatUptime,
  healthColor,
  metricLabel,
  severityBadgeClass,
} from '../services/format'
import type { PageContext } from '../layouts/AppLayout'
import { api } from '../services/api'
import { useAsync } from '../hooks/useAsync'

export function OverviewPage({ live, navigate }: PageContext) {
  const { summary, history, events, loading, error } = live
  const recommendations = useAsync((signal) => api.recommendations(signal), [], { pollMs: 30000 })
  const anomaly = useAsync((signal) => api.anomalyStatus(5, signal), [], { pollMs: 20000 })
  const topCpu = useAsync((signal) => api.top('cpu', 5, signal), [], { pollMs: 10000 })

  const latestAnomaly = anomaly.data?.recent_events?.[0] ?? events[0] ?? null

  if (error && !summary) {
    return (
      <Panel title="Monitoring agent unavailable">
        <EmptyState
          message={error}
          hint="SENTINEL OS reads real Windows metrics from a local agent. A remote or cloud-hosted preview cannot access your machine's localhost — start the agent on the machine you want to monitor."
        />
      </Panel>
    )
  }

  const cpu = summary?.cpu
  const memory = summary?.memory
  const disk = summary?.disk
  const network = summary?.network

  return (
    <div className="space-y-5">
      {/* Hero row */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 2xl:grid-cols-3">
          <StatCard
            label="CPU utilisation"
            value={cpu ? cpu.percent.toFixed(1) : '—'}
            unit="%"
            icon={Cpu}
            percent={cpu?.percent}
            loading={loading && !summary}
            footer={cpu ? `${cpu.core_count_logical} logical / ${cpu.core_count_physical} physical cores` : '—'}
            hint={cpu?.frequency_mhz ? `${formatNumber(cpu.frequency_mhz, 0)} MHz` : undefined}
          />
          <StatCard
            label="Memory utilisation"
            value={memory ? memory.percent.toFixed(1) : '—'}
            unit="%"
            icon={MemoryStick}
            percent={memory?.percent}
            loading={loading && !summary}
            footer={
              memory ? `${formatBytesMB(memory.used_mb)} of ${formatBytesMB(memory.total_mb)}` : '—'
            }
            hint={memory ? `${formatBytesMB(memory.available_mb)} free` : undefined}
          />
          <StatCard
            label="Disk utilisation"
            value={disk && disk.partitions.length > 0 ? formatPercent(Math.max(...disk.partitions.map((p) => p.percent))).replace('%', '') : '—'}
            unit="%"
            icon={HardDrive}
            percent={disk && disk.partitions.length > 0 ? Math.max(...disk.partitions.map((p) => p.percent)) : undefined}
            loading={loading && !summary}
            footer={
              disk && disk.partitions.length > 0
                ? `${disk.partitions.length} partition(s) · ${formatNumber(disk.read_mb_s, 2)} MB/s read`
                : '—'
            }
            hint={disk ? `${formatNumber(disk.write_mb_s, 2)} MB/s write` : undefined}
          />
          <StatCard
            label="Network activity"
            value={network ? formatNumber(network.download_kb_s, 1) : '—'}
            unit="KB/s ↓"
            icon={Network}
            loading={loading && !summary}
            footer={network ? `${formatNumber(network.upload_kb_s, 1)} KB/s ↑` : '—'}
            hint={network ? `${formatNumber(network.bytes_recv_mb, 0)} MB received` : undefined}
          />
          <StatCard
            label="System uptime"
            value={summary ? formatUptime(summary.system.uptime_seconds) : '—'}
            icon={Timer}
            loading={loading && !summary}
            footer={summary ? `Booted ${formatClock(summary.system.boot_time)}` : '—'}
            hint={summary?.system.hostname}
          />
          <StatCard
            label="Active processes"
            value={summary ? String(summary.process_count) : '—'}
            icon={Workflow}
            loading={loading && !summary}
            footer={summary ? `${summary.system.platform} ${summary.system.platform_release}` : '—'}
            hint={summary?.system.architecture}
          />
        </div>

        {/* Health + agent */}
        <div className="space-y-5">
          <Panel
            title="System health"
            subtitle="Composite verdict from measured thresholds"
            actions={
              <Badge tone={summary?.health.partial_data ? 'warn' : 'ok'} dot>
                {summary?.health.partial_data ? 'Partial data' : 'Complete data'}
              </Badge>
            }
          >
            <div className="flex flex-col items-center gap-4">
              <HealthGauge
                value={summary?.health.score ?? 0}
                status={summary?.health.status ?? 'good'}
                sublabel={summary?.health.reasons[0]}
              />
              <ul className="w-full space-y-1.5">
                {(summary?.health.reasons ?? []).slice(0, 4).map((reason) => (
                  <li key={reason} className="flex items-start gap-2 text-2xs leading-relaxed text-white/55">
                    <span className={`mt-1 h-1 w-1 shrink-0 rounded-full ${healthColor(summary?.health.status ?? 'good')} bg-current`} />
                    {reason}
                  </li>
                ))}
              </ul>
            </div>
          </Panel>

          <Panel title="Monitoring agent" subtitle="Local psutil collector">
            <dl className="space-y-2.5 text-xs">
              <Row label="Status" value={live.connection === 'connected' ? 'Streaming' : 'Disconnected'} />
              <Row label="Sample interval" value={`${(live.agent?.sample_interval ?? 2).toFixed(1)} s`} />
              <Row label="Ticks processed" value={String(live.agent?.ticks ?? 0)} />
              <Row label="History points" value={String(live.agent?.history_points ?? history.length)} />
              <Row label="Last tick" value={live.agent?.last_tick ? formatRelative(live.agent.last_tick) : '—'} />
              <Row
                label="Elevation"
                value={summary?.system.is_admin ? 'Administrator' : 'Standard user'}
                tone={summary?.system.is_admin ? 'ok' : 'warn'}
              />
            </dl>
            {summary?.data_warnings && summary.data_warnings.length > 0 && (
              <div className="mt-3 rounded-lg border border-alert-warning/30 bg-alert-warning/8 px-3 py-2">
                <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.12em] text-alert-warning">
                  <AlertTriangle className="h-3 w-3" /> Permission-limited metrics
                </p>
                <ul className="mt-1.5 space-y-1">
                  {summary.data_warnings.slice(0, 3).map((warning) => (
                    <li key={warning} className="font-mono text-2xs leading-relaxed text-alert-warning/80">
                      {warning}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </Panel>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-5 2xl:grid-cols-2">
        <Panel
          title="CPU utilisation"
          subtitle={`Last ${history.length} real samples`}
          actions={<Badge tone="info" dot>{cpu ? `${cpu.percent.toFixed(1)}% now` : '—'}</Badge>}
        >
          <MetricChart
            data={history}
            series={[{ key: 'cpu_percent', label: 'CPU', color: '#2f8cff' }]}
            referenceY={[{ y: 90, label: 'critical', color: 'rgba(255,59,71,0.6)' }]}
            height={228}
          />
        </Panel>
        <Panel
          title="Memory utilisation"
          subtitle="Used plus swap pressure"
          actions={<Badge tone="info" dot>{memory ? `${memory.percent.toFixed(1)}% now` : '—'}</Badge>}
        >
          <MetricChart
            data={history}
            series={[
              { key: 'memory_percent', label: 'Memory', color: '#22d39a' },
              { key: 'swap_percent', label: 'Swap', color: '#ffb020' },
            ]}
            referenceY={[{ y: 90, label: 'critical', color: 'rgba(255,59,71,0.6)' }]}
            height={228}
          />
        </Panel>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
        <Panel
          title="Top CPU consumers"
          subtitle="Measured per-process CPU share"
          actions={
            <button className="btn !py-1" onClick={() => navigate('processes')} type="button">
              Open explorer
            </button>
          }
          bodyClassName="!px-0 !py-0"
        >
          {topCpu.loading && !topCpu.data ? (
            <div className="space-y-2 px-4 py-4">
              {[0, 1, 2, 3, 4].map((index) => (
                <div key={index} className="skeleton h-6 w-full" />
              ))}
            </div>
          ) : (topCpu.data?.items.length ?? 0) === 0 ? (
            <EmptyState message="No process data available" hint="Per-process metrics can be restricted by Windows permissions." />
          ) : (
            <ul className="divide-y divide-panel-border/60">
              {topCpu.data!.items.map((process) => (
                <li key={process.pid} className="flex items-center justify-between gap-3 px-4 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-xs font-medium text-white/85">{process.name}</p>
                    <p className="font-mono text-2xs text-white/30">PID {process.pid}</p>
                  </div>
                  <div className="w-28 shrink-0">
                    <div className="mb-1 flex justify-between font-mono text-2xs text-white/45">
                      <span>{process.cpu_percent.toFixed(1)}%</span>
                      <span>{formatBytesMB(process.memory_mb, 0)}</span>
                    </div>
                    <ProgressBar value={process.cpu_percent} height="h-1" />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel
          title="Recent anomaly alerts"
          subtitle="Isolation Forest severity classification"
          actions={
            <button className="btn !py-1" onClick={() => navigate('anomaly')} type="button">
              Inspect
            </button>
          }
        >
          {anomaly.loading && !anomaly.data ? (
            <div className="space-y-2">
              {[0, 1, 2].map((index) => (
                <div key={index} className="skeleton h-12 w-full" />
              ))}
            </div>
          ) : !latestAnomaly ? (
            <EmptyState
              message="No anomalies recorded"
              hint="The model has not classified any recent sample as unusual. This is the expected state for a healthy system."
            />
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Badge tone="severity">{latestAnomaly.severity}</Badge>
                <span className="font-mono text-2xs text-white/35">{formatRelative(latestAnomaly.timestamp)}</span>
              </div>
              <p className="text-xs font-medium text-white/85">{metricLabel(latestAnomaly.metric)}</p>
              <div className="space-y-1.5">
                <div className="flex justify-between font-mono text-2xs text-white/50">
                  <span>observed {latestAnomaly.observed_value.toFixed(2)}</span>
                  <span>
                    expected {latestAnomaly.expected_range[0].toFixed(1)}–{latestAnomaly.expected_range[1].toFixed(1)}
                  </span>
                </div>
                <ProgressBar value={latestAnomaly.score * 100} height="h-1" />
                <p className="font-mono text-2xs text-white/30">model score {latestAnomaly.score.toFixed(4)}</p>
              </div>
              <p className="text-2xs leading-relaxed text-white/55">{latestAnomaly.explanation}</p>
            </div>
          )}
          <p className="mt-4 border-t border-panel-border/60 pt-3 text-2xs leading-relaxed text-white/25">
            Anomalies describe unusual resource behaviour. They are not evidence of malware.
          </p>
        </Panel>

        <Panel
          title="AI diagnostic insight"
          subtitle={
            anomaly.data
              ? `Mode: ${anomaly.data.mode} · trained on ${anomaly.data.trained_samples} samples`
              : 'Isolation Forest status'
          }
          actions={
            <button className="btn !py-1" onClick={() => navigate('doctor')} type="button">
              Ask AI Doctor
            </button>
          }
        >
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <BrainCircuit className="h-4 w-4 text-electric-300" />
              <span className="text-xs font-semibold text-white/85">Behavioural assessment</span>
            </div>
            <p className="text-xs leading-relaxed text-white/60">
              {anomaly.data?.model_ready
                ? `Isolation Forest active with contamination ${anomaly.data.contamination.toFixed(3)} and sensitivity ${anomaly.data.sensitivity.toFixed(2)}. ${
                    anomaly.data.is_anomaly
                      ? `The latest sample was flagged as ${anomaly.data.last_severity} (score ${anomaly.data.last_score?.toFixed(4)}).`
                      : 'The latest sample is consistent with the learned healthy baseline.'
                  }`
                : 'The model is still initialising. A rule-based cold-start detector is covering the gap, so anomaly classification remains available.'}
            </p>
            {anomaly.data?.last_features && Object.keys(anomaly.data.last_features).length > 0 && (
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(anomaly.data.last_features)
                  .slice(0, 6)
                  .map(([key, value]) => (
                    <div key={key} className="rounded-lg border border-panel-border bg-canvas-soft px-2.5 py-2">
                      <p className="text-2xs uppercase tracking-[0.12em] text-white/30">{metricLabel(key)}</p>
                      <p className="mt-0.5 font-mono text-xs text-white/80">{value.toFixed(2)}</p>
                    </div>
                  ))}
              </div>
            )}
            <div className="rounded-lg border border-electric-500/25 bg-electric-600/8 px-3 py-2.5">
              <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.12em] text-electric-200">
                <Zap className="h-3 w-3" /> Recommendation engine
              </p>
              <p className="mt-1 text-2xs leading-relaxed text-white/55">
                {recommendations.data && recommendations.data.count > 0
                  ? `${recommendations.data.count} evidence-based recommendation(s) available — highest severity: ${
                      recommendations.data.items[0].severity
                    }.`
                  : 'No optimisation recommendations are currently triggered by the measured values.'}
              </p>
              <button className="btn mt-2 !py-1" onClick={() => navigate('recommendations')} type="button">
                View recommendations
              </button>
            </div>
          </div>
        </Panel>
      </div>

      {/* Disk partitions */}
      <Panel
        title="Storage partitions"
        subtitle="Real capacity from psutil.disk_partitions"
        actions={
          <Badge tone="neutral">
            <Activity className="mr-1 h-3 w-3" /> live
          </Badge>
        }
        bodyClassName="!px-0 !py-0"
      >
        {disk && disk.partitions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] border-collapse">
              <thead>
                <tr>
                  <th className="th">Mount</th>
                  <th className="th">Device</th>
                  <th className="th">FS</th>
                  <th className="th">Used</th>
                  <th className="th">Free</th>
                  <th className="th w-[220px]">Utilisation</th>
                </tr>
              </thead>
              <tbody>
                {disk.partitions.map((partition) => (
                  <tr key={partition.mountpoint} className="transition-colors hover:bg-panel-hover/50">
                    <td className="td font-mono text-white/85">{partition.mountpoint}</td>
                    <td className="td font-mono text-white/50">{partition.device}</td>
                    <td className="td text-white/50">{partition.fstype}</td>
                    <td className="td font-mono">
                      {partition.used_gb.toFixed(1)} / {partition.total_gb.toFixed(1)} GB
                    </td>
                    <td className="td font-mono">{partition.free_gb.toFixed(1)} GB</td>
                    <td className="td">
                      <div className="flex items-center gap-2">
                        <ProgressBar value={partition.percent} />
                        <span className="w-12 shrink-0 text-right font-mono text-2xs text-white/60">
                          {partition.percent.toFixed(0)}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState message="No partition data available" hint="Removable drives that are not ready are skipped automatically." />
        )}
      </Panel>

      {/* Events table */}
      {events.length > 0 && (
        <Panel
          title="Live anomaly feed"
          subtitle="Streamed from the monitoring pipeline"
          bodyClassName="!px-0 !py-0"
        >
          <ul className="divide-y divide-panel-border/60">
            {events.slice(0, 6).map((event) => (
              <li key={`${event.id}-${event.timestamp}`} className="flex items-start gap-3 px-4 py-3">
                <span className={`mt-1 inline-flex shrink-0 rounded-md border px-1.5 py-0.5 text-2xs font-semibold uppercase ${severityBadgeClass(event.severity)}`}>
                  {event.severity}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-white/85">{metricLabel(event.metric)}</p>
                  <p className="mt-0.5 text-2xs leading-relaxed text-white/50">{event.evidence}</p>
                </div>
                <span className="shrink-0 font-mono text-2xs text-white/30">{formatClock(event.timestamp)}</span>
              </li>
            ))}
          </ul>
        </Panel>
      )}
    </div>
  )
}

function Row({ label, value, tone }: { label: string; value: string; tone?: 'ok' | 'warn' }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-2xs uppercase tracking-[0.12em] text-white/35">{label}</dt>
      <dd
        className={`truncate font-mono text-2xs ${
          tone === 'ok' ? 'text-alert-ok' : tone === 'warn' ? 'text-alert-warning' : 'text-white/75'
        }`}
      >
        {value}
      </dd>
    </div>
  )
}

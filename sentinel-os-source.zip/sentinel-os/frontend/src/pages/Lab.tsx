import { useEffect, useMemo, useState } from 'react'
import {
  AlertTriangle,
  Brain,
  Cpu,
  MemoryStick,
  Play,
  RefreshCw,
  ShieldCheck,
  Square,
} from 'lucide-react'
import { Badge, EmptyState, ErrorState, LoadingState, Panel, ProgressBar } from '../components/ui/Primitives'
import { ConfirmDialog } from '../components/ui/ConfirmDialog'
import { MetricChart } from '../components/charts/MetricChart'
import { formatNumber, formatPercent } from '../services/format'
import type { PageContext } from '../layouts/AppLayout'
import type { ForecastSeries } from '../types'
import { api } from '../services/api'
import { useAsync } from '../hooks/useAsync'

function MetricRow({ label, value, tone = 'text-white/70' }: { label: string; value: string; tone?: string }) {
  return (
    <div className="flex items-center justify-between border-b border-panel-border/60 py-1.5 last:border-0">
      <span className="text-2xs uppercase tracking-[0.12em] text-white/35">{label}</span>
      <span className={`font-mono text-xs ${tone}`}>{value}</span>
    </div>
  )
}

function ForecastPanel({ series }: { series: ForecastSeries }) {
  const data = useMemo(() => {
    const rows: Array<{ timestamp: number; actual?: number; predicted?: number }> = series.history.map((point) => ({
      timestamp: point.timestamp,
      actual: point.value,
    }))
    // Bridge point so the prediction line connects to the last real measurement.
    const last = rows[rows.length - 1]
    if (last) rows.push({ timestamp: last.timestamp, predicted: last.actual })
    for (const point of series.forecast) rows.push({ timestamp: point.timestamp, predicted: point.value })
    return rows
  }, [series])

  return (
    <Panel
      title={`${series.metric} forecast`}
      subtitle={`${series.method} · horizon ${series.horizon} samples · confidence ${Math.round(series.confidence * 100)}%`}
      actions={
        <Badge tone={series.sufficient_data ? 'ok' : 'warn'} dot>
          {series.sufficient_data ? 'sufficient data' : 'insufficient data'}
        </Badge>
      }
    >
      {!series.sufficient_data ? (
        <EmptyState message={series.message} hint="Forecasting is disabled until enough real measurements are stored." />
      ) : (
        <>
          <MetricChart
            data={data}
            series={[
              { key: 'actual', label: 'Measured', color: '#2f8cff' },
              { key: 'predicted', label: 'Predicted', color: '#a06bff' },
            ]}
            unit={series.unit}
            domain={['auto', 'auto']}
            variant="line"
            height={200}
          />
          <div className="mt-3 grid grid-cols-2 gap-x-6">
            <MetricRow label="Trend / minute" value={`${series.slope_per_minute >= 0 ? '+' : ''}${formatNumber(series.slope_per_minute, 3)}${series.unit}`} />
            <MetricRow label="History points" value={String(series.history.length)} />
            {series.error && (
              <>
                <MetricRow label="MAE" value={`${formatNumber(series.error.mae, 3)}${series.unit}`} />
                <MetricRow label="RMSE" value={`${formatNumber(series.error.rmse, 3)}${series.unit}`} />
                <MetricRow label="MAPE" value={`${formatNumber(series.error.mape_percent, 1)}%`} />
                <MetricRow label="Hold-out n" value={String(series.error.holdout_samples)} />
              </>
            )}
          </div>
        </>
      )}
    </Panel>
  )
}

export function LabPage(_context: PageContext) {
  const info = useAsync((signal) => api.labInfo(signal), [], { pollMs: 2000 })
  const forecast = useAsync((signal) => api.forecast(10, 'database', signal), [], { pollMs: 30000 })
  const compare = useAsync((signal) => api.labCompare(signal), [], { pollMs: 0 })

  const [kind, setKind] = useState<'cpu' | 'memory'>('cpu')
  const [workers, setWorkers] = useState(2)
  const [duration, setDuration] = useState(30)
  const [memoryMb, setMemoryMb] = useState(512)
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)

  const limits = info.data?.limits
  const status = info.data?.current

  useEffect(() => {
    if (limits) {
      setWorkers((value) => Math.min(value, limits.cpu.max_workers))
      setDuration((value) => Math.min(value, limits.cpu.max_duration_seconds))
      setMemoryMb((value) => Math.min(value, limits.memory.max_memory_mb))
    }
  }, [limits])

  const start = async () => {
    setConfirmOpen(false)
    setActionError(null)
    try {
      await api.startExperiment({
        kind,
        workers,
        duration_seconds: duration,
        memory_mb: kind === 'memory' ? memoryMb : 0,
        confirmed: true,
      })
      await Promise.all([info.reload(), compare.reload()])
    } catch (err) {
      setActionError((err as Error).message)
    }
  }

  const stop = async () => {
    setActionError(null)
    try {
      await api.stopExperiment()
      await Promise.all([info.reload(), compare.reload()])
    } catch (err) {
      setActionError((err as Error).message)
    }
  }

  const cleanup = async () => {
    await api.labCleanup()
    await Promise.all([info.reload(), compare.reload()])
  }

  const running = status?.running ?? false
  const progress = running && status ? 1 - status.seconds_remaining / Math.max(1, status.duration_seconds) : 0

  return (
    <div className="space-y-5">
      <Panel
        title="Performance Lab"
        subtitle="Bounded, measurable stress experiments with automatic timeout and recovery tracking"
        actions={
          <>
            <button className="btn" onClick={() => void info.reload()} type="button">
              <RefreshCw className="h-3.5 w-3.5" /> Refresh
            </button>
            <button className="btn" onClick={() => void cleanup()} type="button" title="Release any leftover experiment resources">
              Cleanup
            </button>
          </>
        }
      >
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
          <div className="space-y-4">
            <div className="flex flex-wrap items-end gap-3">
              <div>
                <label className="label">Experiment type</label>
                <div className="flex gap-1">
                  <button
                    type="button"
                    disabled={running}
                    onClick={() => setKind('cpu')}
                    className={`chip ${kind === 'cpu' ? 'border-electric-500/50 bg-electric-500/10 text-electric-200' : ''}`}
                  >
                    <Cpu className="h-3.5 w-3.5" /> CPU
                  </button>
                  <button
                    type="button"
                    disabled={running}
                    onClick={() => setKind('memory')}
                    className={`chip ${kind === 'memory' ? 'border-electric-500/50 bg-electric-500/10 text-electric-200' : ''}`}
                  >
                    <MemoryStick className="h-3.5 w-3.5" /> Memory
                  </button>
                </div>
              </div>
              {kind === 'cpu' && (
                <div>
                  <label className="label">Worker threads</label>
                  <input
                    className="input !w-28"
                    type="number"
                    min={1}
                    max={limits?.cpu.max_workers ?? 4}
                    disabled={running}
                    value={workers}
                    onChange={(event) => setWorkers(Number(event.target.value))}
                  />
                </div>
              )}
              {kind === 'memory' && (
                <div>
                  <label className="label">Target memory (MB)</label>
                  <input
                    className="input !w-32"
                    type="number"
                    min={64}
                    step={64}
                    max={limits?.memory.max_memory_mb ?? 1024}
                    disabled={running}
                    value={memoryMb}
                    onChange={(event) => setMemoryMb(Number(event.target.value))}
                  />
                </div>
              )}
              <div>
                <label className="label">Duration (seconds)</label>
                <input
                  className="input !w-28"
                  type="number"
                  min={5}
                  max={limits?.cpu.max_duration_seconds ?? 120}
                  disabled={running}
                  value={duration}
                  onChange={(event) => setDuration(Number(event.target.value))}
                />
              </div>
              {!running ? (
                <button className="btn btn-primary" onClick={() => setConfirmOpen(true)} type="button">
                  <Play className="h-3.5 w-3.5" /> Start experiment
                </button>
              ) : (
                <button className="btn btn-danger" onClick={() => void stop()} type="button">
                  <Square className="h-3.5 w-3.5" /> Stop now
                </button>
              )}
            </div>

            {actionError && (
              <p className="flex items-center gap-2 rounded-lg border border-alert-critical/40 bg-alert-critical/10 px-3 py-2 text-2xs text-alert-critical">
                <AlertTriangle className="h-3.5 w-3.5" /> {actionError}
              </p>
            )}

            {running && status && (
              <div className="rounded-lg border border-electric-500/30 bg-electric-500/5 px-4 py-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-electric-200">
                    {status.kind === 'cpu' ? 'CPU' : 'Memory'} experiment running · {status.workers} worker(s)
                  </span>
                  <span className="font-mono text-white/60">{status.seconds_remaining.toFixed(0)}s remaining</span>
                </div>
                <div className="mt-3">
                  <ProgressBar value={progress * 100} tone="electric" height="h-2" />
                </div>
                <div className="mt-3 grid grid-cols-2 gap-x-6 sm:grid-cols-3">
                  <MetricRow label="CPU now" value={formatPercent(status.current.cpu_percent ?? 0)} />
                  <MetricRow label="RAM now" value={formatPercent(status.current.memory_percent ?? 0)} />
                  <MetricRow label="Samples" value={String(status.samples)} />
                </div>
              </div>
            )}

            {!running && (
              <p className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5 text-2xs leading-relaxed text-white/45">
                {status?.message || 'No experiment running. Choose a bounded workload and confirm to begin measuring.'}
              </p>
            )}
          </div>

          <div className="rounded-lg border border-panel-border bg-canvas-soft p-4">
            <p className="mb-2 flex items-center gap-2 text-2xs font-semibold uppercase tracking-[0.14em] text-white/40">
              <ShieldCheck className="h-3.5 w-3.5 text-alert-ok" /> Server-enforced safety limits
            </p>
            {limits ? (
              <div className="space-y-0.5">
                <MetricRow label="Logical cores" value={String(limits.cpu.available_logical_cores)} />
                <MetricRow label="Max CPU workers" value={String(limits.cpu.max_workers)} />
                <MetricRow label="Max CPU duration" value={`${limits.cpu.max_duration_seconds}s`} />
                <MetricRow label="Available RAM" value={`${formatNumber(limits.memory.available_mb, 0)} MB`} />
                <MetricRow label="Max memory (hard cap)" value={`${limits.memory.max_memory_mb} MB`} tone="text-alert-warning" />
                <MetricRow label="Max memory duration" value={`${limits.memory.max_duration_seconds}s`} />
              </div>
            ) : (
              <LoadingState label="Reading limits…" />
            )}
            <p className="mt-3 text-2xs leading-relaxed text-white/35">
              Requested values are clamped to these limits on the server. Workers are daemon threads with an automatic
              timeout, and memory allocation never exceeds 25% of the currently available RAM.
            </p>
          </div>
        </div>
      </Panel>

      <Panel
        title="Baseline vs peak vs recovery"
        subtitle="Measured before, during and after the most recent experiment"
        actions={
          <button className="btn" onClick={() => void compare.reload()} type="button">
            <RefreshCw className="h-3.5 w-3.5" /> Recompute
          </button>
        }
      >
        {compare.loading && !compare.data && <LoadingState />}
        {compare.error && <ErrorState message={compare.error} onRetry={() => void compare.reload()} />}
        {compare.data && (
          <>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              {(['baseline', 'peak', 'recovery'] as const).map((stage) => (
                <div key={stage} className="rounded-lg border border-panel-border bg-canvas-soft px-4 py-3">
                  <p className="mb-2 text-2xs font-semibold uppercase tracking-[0.14em] text-white/40">{stage}</p>
                  <div className="space-y-0.5">
                    <MetricRow label="CPU" value={formatPercent(compare.data?.[stage]?.cpu_percent ?? 0)} />
                    <MetricRow label="RAM" value={formatPercent(compare.data?.[stage]?.memory_percent ?? 0)} />
                    <MetricRow label="Swap" value={formatPercent(compare.data?.[stage]?.swap_percent ?? 0)} />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <p className="mb-2 text-2xs font-semibold uppercase tracking-[0.14em] text-white/40">Delta · peak vs baseline</p>
              <div className="grid grid-cols-2 gap-x-8 sm:grid-cols-3">
                {Object.entries(compare.data.delta_peak_vs_baseline).map(([key, value]) => (
                  <MetricRow
                    key={key}
                    label={key.replace(/_/g, ' ')}
                    value={`${value >= 0 ? '+' : ''}${formatNumber(value, 2)}`}
                    tone={value >= 0 ? 'text-alert-warning' : 'text-alert-ok'}
                  />
                ))}
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <Badge tone={compare.data.recovered ? 'ok' : 'warn'} dot>
                {compare.data.recovered ? 'recovered to baseline' : 'recovery not yet observed'}
              </Badge>
              <span className="text-2xs text-white/40">{compare.data.note}</span>
            </div>
          </>
        )}
      </Panel>

      <div className="grid grid-cols-1 gap-5 2xl:grid-cols-2">
        {forecast.loading && !forecast.data && (
          <Panel title="Trend forecasting">
            <LoadingState />
          </Panel>
        )}
        {forecast.data && forecast.data.series.length === 0 && (
          <Panel title="Trend forecasting">
            <EmptyState
              message="No forecast available yet."
              hint={`Requires ${forecast.data.required_samples} stored samples; currently ${forecast.data.available_samples}.`}
            />
          </Panel>
        )}
        {forecast.data?.series.map((series) => (
          <ForecastPanel key={series.metric} series={series} />
        ))}
      </div>

      {forecast.data && forecast.data.series.length > 0 && (
        <Panel title="About these predictions">
          <div className="flex items-start gap-3 text-2xs leading-relaxed text-white/45">
            <Brain className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
            <div>
              <p>
                Forecasts blend ordinary-least-squares linear regression with a moving-average baseline over real stored
                samples ({forecast.data.available_samples} available, {forecast.data.required_samples} required). Accuracy
                is measured on a hold-out split and reported as MAE / RMSE / MAPE.
              </p>
              <p className="mt-1.5">
                Predictions are statistical extrapolations of past behaviour — they are not guarantees, and no forecast is
                produced when history is insufficient.
              </p>
            </div>
          </div>
        </Panel>
      )}

      <ConfirmDialog
        open={confirmOpen}
        title={`Start bounded ${kind === 'cpu' ? 'CPU' : 'memory'} experiment?`}
        description={
          kind === 'cpu'
            ? `This spawns ${workers} CPU worker thread(s) for ${duration} seconds, increasing CPU utilisation on this machine. It stops automatically at the timeout and can be stopped early.`
            : `This allocates up to ${memoryMb} MB of real memory for ${duration} seconds, increasing RAM pressure on this machine. Allocation is capped at 25% of available RAM, stops automatically, and can be stopped early.`
        }
        confirmLabel="Start experiment"
        onConfirm={() => void start()}
        onCancel={() => setConfirmOpen(false)}
      />
    </div>
  )
}

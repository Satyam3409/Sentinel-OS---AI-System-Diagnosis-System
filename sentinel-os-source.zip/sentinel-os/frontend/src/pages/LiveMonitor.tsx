import { useState } from 'react'
import { Activity, ArrowDown, ArrowUp, Cpu, HardDrive, MemoryStick, Workflow } from 'lucide-react'
import { MetricChart } from '../components/charts/MetricChart'
import { Badge, EmptyState, Panel, ProgressBar } from '../components/ui/Primitives'
import { MiniGauge } from '../components/ui/Gauge'
import {
  formatBytesMB,
  formatClock,
  formatNumber,
  formatPercent,
  formatUptime,
  metricLabel,
} from '../services/format'
import type { PageContext } from '../layouts/AppLayout'

type Range = 30 | 60 | 120 | 180

export function LiveMonitorPage({ live }: PageContext) {
  const [rangePoints, setRangePoints] = useState<Range>(60)
  const { history, summary, latest, connection, agent } = live

  const window = history.slice(-rangePoints)
  const cpu = summary?.cpu
  const memory = summary?.memory
  const disk = summary?.disk
  const network = summary?.network

  const current = latest ?? (window.length > 0 ? window[window.length - 1] : null)

  return (
    <div className="space-y-5">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">Window</span>
          {([30, 60, 120, 180] as Range[]).map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setRangePoints(value)}
              className={`btn !px-2.5 !py-1 ${
                rangePoints === value ? 'border-electric-500/60 bg-electric-600/15 text-white' : ''
              }`}
            >
              {value} pts
            </button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge tone={connection === 'connected' ? 'ok' : 'critical'} dot>
            {connection}
          </Badge>
          <Badge tone="neutral">
            {(agent?.sample_interval ?? 2).toFixed(1)}s sampling · {window.length} samples shown
          </Badge>
        </div>
      </div>

      {/* Live tiles */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2 2xl:grid-cols-4">
        <MonitoringTile
          title="CPU"
          icon={Cpu}
          value={current ? current.cpu_percent : (cpu?.percent ?? 0)}
          detail={
            cpu
              ? `${cpu.core_count_logical} threads · ${cpu.frequency_mhz ? `${formatNumber(cpu.frequency_mhz, 0)} MHz` : 'frequency n/a'}`
              : '—'
          }
        />
        <MonitoringTile
          title="Memory"
          icon={MemoryStick}
          value={current ? current.memory_percent : (memory?.percent ?? 0)}
          detail={memory ? `${formatBytesMB(memory.available_mb)} available of ${formatBytesMB(memory.total_mb)}` : '—'}
        />
        <MonitoringTile
          title="Disk throughput"
          icon={HardDrive}
          value={
            current ? Math.min(100, ((current.disk_read_mb_s + current.disk_write_mb_s) / 200) * 100) : 0
          }
          display={current ? `${formatNumber(current.disk_read_mb_s, 2)} / ${formatNumber(current.disk_write_mb_s, 2)} MB/s` : '—'}
          detail={disk ? `${disk.partitions.length} partition(s) monitored` : '—'}
          tone="#ffb020"
        />
        <MonitoringTile
          title="Network"
          icon={Activity}
          value={current ? Math.min(100, current.net_download_kb_s / 50) : 0}
          display={current ? `${formatNumber(current.net_download_kb_s, 1)} ↓ / ${formatNumber(current.net_upload_kb_s, 1)} ↑ KB/s` : '—'}
          detail={network ? `${formatNumber(network.packets_recv, 0)} packets received` : '—'}
          tone="#22d39a"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-5 2xl:grid-cols-2">
        <Panel title="CPU utilisation" subtitle="Total processor time across all cores" actions={<Badge tone="info">{formatPercent(current?.cpu_percent)}</Badge>}>
          <MetricChart
            data={window}
            series={[{ key: 'cpu_percent', label: 'CPU', color: '#2f8cff' }]}
            referenceY={[
              { y: 75, label: 'elevated', color: 'rgba(255,176,32,0.55)' },
              { y: 90, label: 'critical', color: 'rgba(255,59,71,0.55)' },
            ]}
            height={250}
          />
        </Panel>

        <Panel title="Memory & swap" subtitle="Physical memory pressure and paging" actions={<Badge tone="info">{formatPercent(current?.memory_percent)}</Badge>}>
          <MetricChart
            data={window}
            series={[
              { key: 'memory_percent', label: 'Memory', color: '#22d39a' },
              { key: 'swap_percent', label: 'Swap', color: '#ffb020' },
            ]}
            referenceY={[{ y: 90, label: 'critical', color: 'rgba(255,59,71,0.55)' }]}
            height={250}
          />
        </Panel>

        <Panel title="Disk throughput" subtitle="Read and write measured from I/O counters" actions={<Badge tone="neutral">MB/s</Badge>}>
          <MetricChart
            data={window}
            series={[
              { key: 'disk_read_mb_s', label: 'Read', color: '#63a9ff' },
              { key: 'disk_write_mb_s', label: 'Write', color: '#a78bfa' },
            ]}
            unit=""
            domain={['auto', 'auto']}
            height={250}
          />
        </Panel>

        <Panel title="Network throughput" subtitle="Upload and download deltas" actions={<Badge tone="neutral">KB/s</Badge>}>
          <MetricChart
            data={window}
            series={[
              { key: 'net_download_kb_s', label: 'Download', color: '#22d39a' },
              { key: 'net_upload_kb_s', label: 'Upload', color: '#ffb020' },
            ]}
            unit=""
            domain={['auto', 'auto']}
            height={250}
          />
        </Panel>
      </div>

      {/* Per-core + process count */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <Panel
          title="Per-core utilisation"
          subtitle="Measured with psutil.cpu_percent(percpu=True)"
          actions={<Badge tone="neutral">{cpu?.per_core.length ?? 0} logical cores</Badge>}
        >
          {cpu && cpu.per_core.length > 0 ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-6">
              {cpu.per_core.map((value, index) => (
                <div key={index} className="rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">
                      Core {index}
                    </span>
                    <span className="font-mono text-2xs text-white/70">{value.toFixed(0)}%</span>
                  </div>
                  <div className="mt-2">
                    <ProgressBar value={value} height="h-1" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              message="Per-core metrics unavailable"
              hint="Windows can restrict per-core sampling under certain permission configurations. Total CPU utilisation remains valid."
            />
          )}
        </Panel>

        <div className="space-y-5">
          <Panel title="Process table size" subtitle="Counted from psutil.pids()">
            <div className="flex items-center justify-between">
              <MiniGauge
                value={Math.min(100, ((current?.process_count ?? 0) / 500) * 100)}
                label="Process count"
                detail={`${current?.process_count ?? 0} running processes`}
                tone="#2f8cff"
              />
              <Workflow className="h-6 w-6 text-white/15" />
            </div>
          </Panel>

          <Panel title="System" subtitle="Identity and uptime">
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between gap-3">
                <dt className="text-2xs uppercase tracking-[0.12em] text-white/35">Hostname</dt>
                <dd className="truncate font-mono text-2xs text-white/75">{summary?.system.hostname ?? '—'}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-2xs uppercase tracking-[0.12em] text-white/35">Uptime</dt>
                <dd className="font-mono text-2xs text-white/75">
                  {summary ? formatUptime(summary.system.uptime_seconds) : '—'}
                </dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-2xs uppercase tracking-[0.12em] text-white/35">Platform</dt>
                <dd className="truncate font-mono text-2xs text-white/75">
                  {summary ? `${summary.system.platform} ${summary.system.platform_release}` : '—'}
                </dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-2xs uppercase tracking-[0.12em] text-white/35">Last sample</dt>
                <dd className="font-mono text-2xs text-white/75">{formatClock(current?.timestamp)}</dd>
              </div>
            </dl>
          </Panel>

          <Panel title="Live flags" subtitle="Latest evaluated sample">
            <ul className="space-y-2">
              <FlagRow label={metricLabel('cpu_percent')} value={current?.cpu_percent ?? 0} threshold={90} />
              <FlagRow label={metricLabel('memory_percent')} value={current?.memory_percent ?? 0} threshold={90} />
              <FlagRow label={metricLabel('swap_percent')} value={current?.swap_percent ?? 0} threshold={60} />
            </ul>
            <div className="mt-3 flex items-center gap-3 text-2xs text-white/35">
              <span className="inline-flex items-center gap-1">
                <ArrowUp className="h-3 w-3 text-alert-critical" /> above threshold
              </span>
              <span className="inline-flex items-center gap-1">
                <ArrowDown className="h-3 w-3 text-alert-ok" /> nominal
              </span>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  )
}

function MonitoringTile({
  title,
  icon: Icon,
  value,
  display,
  detail,
  tone = '#2f8cff',
}: {
  title: string
  icon: typeof Cpu
  value: number
  display?: string
  detail: string
  tone?: string
}) {
  return (
    <Panel
      title={title}
      actions={<Icon className="h-4 w-4 text-white/30" />}
      bodyClassName="!py-3.5"
    >
      <div className="flex items-end justify-between gap-3">
        <div className="min-w-0">
          <p className="font-mono text-xl font-semibold text-white">{display ?? formatPercent(value)}</p>
          <p className="mt-1 truncate text-2xs text-white/40">{detail}</p>
        </div>
      </div>
      {!display && (
        <div className="mt-3">
          <ProgressBar value={value} tone={value >= 90 ? 'critical' : value >= 75 ? 'warn' : undefined} />
        </div>
      )}
      {display && (
        <div className="mt-3">
          <ProgressBar value={value} tone="warn" height="h-1" />
        </div>
      )}
      <span className="sr-only" style={{ color: tone }}>
        live
      </span>
    </Panel>
  )
}

function FlagRow({ label, value, threshold }: { label: string; value: number; threshold: number }) {
  const breached = value >= threshold
  return (
    <li className="flex items-center justify-between gap-3">
      <span className="text-2xs text-white/50">{label}</span>
      <span className={`inline-flex items-center gap-1.5 font-mono text-2xs ${breached ? 'text-alert-critical' : 'text-alert-ok'}`}>
        {breached ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
        {value.toFixed(1)}%
        <span className="text-white/25">/ {threshold}%</span>
      </span>
    </li>
  )
}

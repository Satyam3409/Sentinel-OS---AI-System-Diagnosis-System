import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { AppLayout, type PageContext } from './layouts/AppLayout'
import { OverviewPage } from './pages/Overview'
import { LiveMonitorPage } from './pages/LiveMonitor'
import { ProcessExplorerPage } from './pages/ProcessExplorer'
import { DoctorPage } from './pages/Doctor'
import { AnomalyPage } from './pages/Anomaly'
import { RecommendationsPage } from './pages/Recommendations'
import { HistoryPage } from './pages/History'
import { LabPage } from './pages/Lab'
import { SettingsPage } from './pages/Settings'
import { AboutPage } from './pages/About'

const VERSION = '1.0.0'

/** Single source of truth for the sidebar → page mapping. */
function PageRouter(context: PageContext) {
  switch (context.active) {
    case 'monitor':
      return <LiveMonitorPage {...context} />
    case 'processes':
      return <ProcessExplorerPage {...context} />
    case 'doctor':
      return <DoctorPage {...context} />
    case 'anomaly':
      return <AnomalyPage {...context} />
    case 'recommendations':
      return <RecommendationsPage {...context} />
    case 'history':
      return <HistoryPage {...context} />
    case 'lab':
      return <LabPage {...context} />
    case 'settings':
      return <SettingsPage {...context} />
    case 'about':
      return <AboutPage {...context} />
    case 'overview':
    default:
      return <OverviewPage {...context} />
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppLayout version={VERSION} renderPage={PageRouter} />
  </StrictMode>,
)

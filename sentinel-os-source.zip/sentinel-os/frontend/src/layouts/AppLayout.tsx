import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { Sidebar, NAV_ITEMS } from '../components/layout/Sidebar'
import { TopBar } from '../components/layout/TopBar'
import { useMetricsStream } from '../hooks/useMetricsStream'

export interface PageContext {
  active: string
  live: ReturnType<typeof useMetricsStream>
  navigate: (id: string) => void
}

interface AppLayoutProps {
  renderPage: (context: PageContext) => ReactNode
  version: string
}

/** Application shell: collapsible sidebar, sticky top bar, routed content. */
export function AppLayout({ renderPage, version }: AppLayoutProps) {
  const live = useMetricsStream()
  const [active, setActive] = useState(() => window.location.hash.replace('#', '') || 'overview')
  const [collapsed, setCollapsed] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    const onHashChange = () => {
      const hash = window.location.hash.replace('#', '')
      if (hash) setActive(hash)
    }
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  const navigate = (id: string) => {
    setActive(id)
    window.location.hash = id
  }

  const onRefresh = async () => {
    setRefreshing(true)
    try {
      await live.refresh()
    } finally {
      setTimeout(() => setRefreshing(false), 400)
    }
  }

  const activeItem = useMemo(() => NAV_ITEMS.find((item) => item.id === active) ?? NAV_ITEMS[0], [active])
  const source = live.summary?.source ?? 'live'

  return (
    <div className="flex h-screen w-full overflow-hidden bg-canvas">
      <div className="pointer-events-none fixed inset-0 bg-grid-faint bg-grid opacity-[0.55]" aria-hidden />
      <Sidebar
        active={activeItem.id}
        onNavigate={navigate}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((value) => !value)}
        agentOnline={live.connection === 'connected'}
        version={version}
      />
      <div className="relative flex min-w-0 flex-1 flex-col">
        <TopBar
          title={activeItem.label}
          description={activeItem.description}
          connection={live.connection}
          connectionDetail={live.connectionDetail}
          lastFrameAt={live.lastFrameAt}
          agentTicks={live.agent?.ticks ?? 0}
          sampleInterval={live.agent?.sample_interval ?? live.summary?.agent?.sample_interval ?? 2}
          onRefresh={onRefresh}
          refreshing={refreshing}
          source={source}
        />
        <main className="relative flex-1 overflow-y-auto px-6 py-5 scrollbar-thin">
          <div key={activeItem.id} className="animate-slide-up">
            {renderPage({ active: activeItem.id, live, navigate })}
          </div>
        </main>
      </div>
    </div>
  )
}

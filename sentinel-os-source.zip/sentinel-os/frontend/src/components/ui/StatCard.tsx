import type { LucideIcon } from 'lucide-react'
import type { ReactNode } from 'react'
import { ProgressBar } from './Primitives'

interface StatCardProps {
  label: string
  value: string
  unit?: string
  icon: LucideIcon
  percent?: number
  footer?: ReactNode
  tone?: 'electric' | 'ok' | 'warn' | 'critical'
  loading?: boolean
  hint?: string
}

/**
 * Primary metric card used across the dashboard.
 * Values are always rendered from measured data - never generated client-side.
 */
export function StatCard({ label, value, unit, icon: Icon, percent, footer, tone, loading, hint }: StatCardProps) {
  return (
    <div className="panel panel-sheen group px-4 py-4 transition-colors duration-300 ease-sentinel hover:border-electric-500/30">
      <div className="relative flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-2xs font-semibold uppercase tracking-[0.16em] text-white/40">{label}</p>
          <div className="mt-2.5 flex items-baseline">
            {loading ? (
              <div className="skeleton h-7 w-24" />
            ) : (
              <>
                <span className="metric-value">{value}</span>
                {unit && <span className="metric-unit">{unit}</span>}
              </>
            )}
          </div>
        </div>
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-panel-border bg-panel-light text-electric-300 transition-colors group-hover:border-electric-500/35 group-hover:text-electric-200">
          <Icon className="h-4 w-4" />
        </div>
      </div>
      {typeof percent === 'number' && (
        <div className="relative mt-3.5">
          <ProgressBar value={percent} tone={tone} />
        </div>
      )}
      {(footer || hint) && (
        <div className="relative mt-3 flex items-center justify-between gap-2 text-2xs text-white/40">
          <span className="truncate">{footer}</span>
          {hint && <span className="shrink-0 text-white/30">{hint}</span>}
        </div>
      )}
    </div>
  )
}

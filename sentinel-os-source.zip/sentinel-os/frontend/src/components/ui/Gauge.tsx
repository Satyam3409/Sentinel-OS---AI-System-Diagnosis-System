import { healthStroke } from '../../services/format'

interface GaugeProps {
  value: number
  status?: string
  label?: string
  sublabel?: string
  size?: number
}

/** SVG radial gauge for the system health score (0-100). */
export function HealthGauge({ value, status = 'good', label = 'System health', sublabel, size = 168 }: GaugeProps) {
  const stroke = 10
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const clamped = Math.max(0, Math.min(100, value))
  const dash = (clamped / 100) * circumference
  const color = healthStroke(status)

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#161d27"
            strokeWidth={stroke}
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${dash} ${circumference}`}
            style={{ transition: 'stroke-dasharray 700ms cubic-bezier(0.22,0.61,0.36,1), stroke 400ms ease' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-mono text-4xl font-semibold leading-none text-white">{Math.round(clamped)}</span>
          <span className="mt-1 text-2xs uppercase tracking-[0.18em] text-white/40">/ 100</span>
          <span className="mt-2 text-2xs font-semibold uppercase tracking-[0.18em]" style={{ color }}>
            {status}
          </span>
        </div>
      </div>
      <p className="mt-3 text-xs font-medium text-white/70">{label}</p>
      {sublabel && <p className="mt-0.5 text-2xs text-white/35">{sublabel}</p>}
    </div>
  )
}

interface MiniGaugeProps {
  value: number
  label: string
  detail?: string
  tone?: string
}

export function MiniGauge({ value, label, detail, tone = '#2f8cff' }: MiniGaugeProps) {
  const size = 92
  const stroke = 7
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const clamped = Math.max(0, Math.min(100, value))
  return (
    <div className="flex items-center gap-3">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#161d27" strokeWidth={stroke} />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={tone}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${(clamped / 100) * circumference} ${circumference}`}
            style={{ transition: 'stroke-dasharray 600ms cubic-bezier(0.22,0.61,0.36,1)' }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-mono text-sm font-semibold text-white">{Math.round(clamped)}%</span>
        </div>
      </div>
      <div className="min-w-0">
        <p className="text-xs font-medium text-white/70">{label}</p>
        {detail && <p className="mt-0.5 text-2xs text-white/35">{detail}</p>}
      </div>
    </div>
  )
}

import { useEffect, useState } from 'react'
import { AlertTriangle, X } from 'lucide-react'

interface ConfirmDialogProps {
  open: boolean
  title: string
  description: string
  confirmLabel?: string
  cancelLabel?: string
  destructive?: boolean
  onConfirm: () => void
  onCancel: () => void
}

/**
 * Explicit confirmation gate for any action with side effects
 * (stress experiments, history deletion).
 */
export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  destructive = false,
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  const [acknowledged, setAcknowledged] = useState(false)

  useEffect(() => {
    if (open) setAcknowledged(false)
  }, [open])

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && open) onCancel()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onCancel])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="panel panel-sheen w-full max-w-lg animate-slide-up">
        <div className="panel-header">
          <div className="panel-title">
            <AlertTriangle className={`h-4 w-4 ${destructive ? 'text-alert-critical' : 'text-alert-warning'}`} />
            {title}
          </div>
          <button className="btn !px-2 !py-1" onClick={onCancel} type="button" aria-label="Close">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="space-y-4 px-4 py-4">
          <p className="text-xs leading-relaxed text-white/70">{description}</p>
          <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-panel-border bg-canvas-soft px-3 py-2.5">
            <input
              type="checkbox"
              className="mt-0.5 h-3.5 w-3.5 accent-electric-500"
              checked={acknowledged}
              onChange={(event) => setAcknowledged(event.target.checked)}
            />
            <span className="text-2xs leading-relaxed text-white/60">
              I understand what this action does and I want to proceed. SENTINEL OS performs read-only analysis
              everywhere else; this action is the only exception and is bounded by server-side safety limits.
            </span>
          </label>
          <div className="flex justify-end gap-2">
            <button className="btn" onClick={onCancel} type="button">
              {cancelLabel}
            </button>
            <button
              className={`btn ${destructive ? 'btn-danger' : 'btn-primary'}`}
              disabled={!acknowledged}
              onClick={onConfirm}
              type="button"
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

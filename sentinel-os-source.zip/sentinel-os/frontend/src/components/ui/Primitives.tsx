import type { ReactNode } from 'react'
import { AlertTriangle, Inbox, Loader2 } from 'lucide-react'
import { severityBadgeClass } from '../../services/format'

/* ------------------------------------------------------------------ Panel */

interface PanelProps {
  title?: ReactNode
  subtitle?: ReactNode
  actions?: ReactNode
  children: ReactNode
  className?: string
  bodyClassName?: string
  sheen?: boolean
}

export function Panel({ title, subtitle, actions, children, className = '', bodyClassName = '', sheen = true }: PanelProps) {
  return (
    <section className={`panel ${sheen ? 'panel-sheen' : ''} overflow-hidden ${className}`}>
      {(title || actions) && (
        <header className="panel-header">
          <div className="min-w-0">
            <h2 className="panel-title truncate">{title}</h2>
            {subtitle && <p className="panel-subtitle mt-1">{subtitle}</p>}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className={`relative px-4 py-4 ${bodyClassName}`}>{children}</div>
    </section>
  )
}

/* ------------------------------------------------------------------ Badge */

export function Badge({
  children,
  tone = 'neutral',
  className = '',
  dot = false,
}: {
  children: ReactNode
  tone?: 'neutral' | 'ok' | 'warn' | 'critical' | 'info' | 'severity'
  className?: string
  dot?: boolean
}) {
  const tones: Record<string, string> = {
    neutral: 'border-panel-border bg-panel-light text-white/60',
    ok: 'border-alert-ok/40 bg-alert-ok/10 text-alert-ok',
    warn: 'border-alert-warning/40 bg-alert-warning/10 text-alert-warning',
    critical: 'border-alert-critical/45 bg-alert-critical/12 text-alert-critical',
    info: 'border-electric-400/40 bg-electric-500/10 text-electric-200',
    severity: severityBadgeClass(String(children)),
  }
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-2xs font-semibold uppercase tracking-[0.1em] ${
        tones[tone] ?? tones.neutral
      } ${className}`}
    >
      {dot && <span className="h-1.5 w-1.5 rounded-full bg-current" />}
      {children}
    </span>
  )
}

/* ------------------------------------------------------------- ProgressBar */

export function ProgressBar({
  value,
  max = 100,
  tone,
  height = 'h-1.5',
  showTrackLabel = false,
}: {
  value: number
  max?: number
  tone?: 'electric' | 'ok' | 'warn' | 'critical'
  height?: string
  showTrackLabel?: boolean
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100))
  const resolved =
    tone ??
    (pct >= 90 ? 'critical' : pct >= 75 ? 'warn' : pct >= 50 ? 'electric' : 'ok')
  const colors: Record<string, string> = {
    electric: 'bg-electric-500',
    ok: 'bg-alert-ok',
    warn: 'bg-alert-warning',
    critical: 'bg-alert-critical',
  }
  return (
    <div className={`w-full overflow-hidden rounded-full bg-panel-light ${height}`} role="presentation">
      <div
        className={`${height} rounded-full ${colors[resolved]} transition-[width] duration-700 ease-sentinel`}
        style={{ width: `${pct}%` }}
        aria-hidden={!showTrackLabel}
      />
    </div>
  )
}

/* ------------------------------------------------------------- State views */

export function LoadingState({ label = 'Loading measured data…' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-10 text-xs text-white/45">
      <Loader2 className="h-4 w-4 animate-spin text-electric-400" />
      {label}
    </div>
  )
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center gap-3 py-10 text-center">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-alert-critical/40 bg-alert-critical/10">
        <AlertTriangle className="h-5 w-5 text-alert-critical" />
      </div>
      <p className="max-w-md text-xs leading-relaxed text-white/60">{message}</p>
      {onRetry && (
        <button className="btn" onClick={onRetry} type="button">
          Retry
        </button>
      )}
    </div>
  )
}

export function EmptyState({ message, hint }: { message: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center gap-2 py-10 text-center">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-panel-border bg-panel-light">
        <Inbox className="h-5 w-5 text-white/30" />
      </div>
      <p className="text-xs text-white/55">{message}</p>
      {hint && <p className="max-w-sm text-2xs leading-relaxed text-white/30">{hint}</p>}
    </div>
  )
}

export function SkeletonBlock({ className = 'h-4 w-full' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />
}

/* ------------------------------------------------------------ StatusPill */

export function StatusPill({
  state,
  label,
}: {
  state: 'connected' | 'connecting' | 'disconnected' | 'error'
  label?: string
}) {
  const config = {
    connected: { color: 'bg-alert-ok', text: 'text-alert-ok', border: 'border-alert-ok/35', text2: label ?? 'Agent connected' },
    connecting: { color: 'bg-alert-warning', text: 'text-alert-warning', border: 'border-alert-warning/35', text2: label ?? 'Connecting…' },
    disconnected: { color: 'bg-white/35', text: 'text-white/50', border: 'border-panel-border', text2: label ?? 'Agent offline' },
    error: { color: 'bg-alert-critical', text: 'text-alert-critical', border: 'border-alert-critical/35', text2: label ?? 'Agent error' },
  }[state]

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-lg border ${config.border} bg-panel-light px-2.5 py-1.5 text-2xs font-semibold tracking-wide ${config.text}`}
      title="Connection status to the local monitoring agent"
    >
      <span className="relative flex h-2 w-2">
        <span className={`absolute inline-flex h-full w-full rounded-full ${config.color} ${state === 'connected' ? 'animate-pulse-ring' : ''}`} />
        <span className={`relative inline-flex h-2 w-2 rounded-full ${config.color}`} />
      </span>
      {config.text2}
    </span>
  )
}

import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { Cpu } from 'lucide-react'
import { Badge, EmptyState, ErrorState, LoadingState, Panel, ProgressBar, StatusPill } from './Primitives'
import { StatCard } from './StatCard'

describe('Panel', () => {
  it('renders a title, subtitle and body', () => {
    render(
      <Panel title="Overview" subtitle="measured values">
        <p>body content</p>
      </Panel>,
    )
    expect(screen.getByText('Overview')).toBeInTheDocument()
    expect(screen.getByText('measured values')).toBeInTheDocument()
    expect(screen.getByText('body content')).toBeInTheDocument()
  })

  it('renders without a header when no title or actions are supplied', () => {
    const { container } = render(
      <Panel>
        <span>only body</span>
      </Panel>,
    )
    expect(container.querySelector('header')).toBeNull()
    expect(screen.getByText('only body')).toBeInTheDocument()
  })
})

describe('Badge', () => {
  it('shows its children and applies the requested tone', () => {
    const { container } = render(<Badge tone="critical">critical</Badge>)
    expect(screen.getByText('critical')).toBeInTheDocument()
    expect(container.firstElementChild?.className).toContain('alert-critical')
  })
})

describe('ProgressBar', () => {
  it('clamps out-of-range values to 0-100%', () => {
    const { container: over } = render(<ProgressBar value={150} />)
    expect((over.querySelector('[aria-hidden="true"]') as HTMLElement).style.width).toBe('100%')

    const { container: under } = render(<ProgressBar value={-20} />)
    expect((under.querySelector('[aria-hidden="true"]') as HTMLElement).style.width).toBe('0%')
  })

  it('escalates colour tone as utilisation rises', () => {
    const { container: ok } = render(<ProgressBar value={20} />)
    expect(ok.querySelector('[aria-hidden="true"]')?.className).toContain('alert-ok')

    const { container: critical } = render(<ProgressBar value={97} />)
    expect(critical.querySelector('[aria-hidden="true"]')?.className).toContain('alert-critical')
  })
})

describe('state views', () => {
  it('LoadingState reports that data is being measured', () => {
    render(<LoadingState />)
    expect(screen.getByText(/Loading measured data/i)).toBeInTheDocument()
  })

  it('ErrorState shows the message and raises the retry callback', () => {
    let clicked = 0
    render(<ErrorState message="agent offline" onRetry={() => (clicked += 1)} />)
    expect(screen.getByText('agent offline')).toBeInTheDocument()
    screen.getByRole('button', { name: /retry/i }).click()
    expect(clicked).toBe(1)
  })

  it('EmptyState shows a message and optional hint', () => {
    render(<EmptyState message="no anomalies" hint="keep monitoring" />)
    expect(screen.getByText('no anomalies')).toBeInTheDocument()
    expect(screen.getByText('keep monitoring')).toBeInTheDocument()
  })

  it('StatusPill labels each connection state', () => {
    const { rerender } = render(<StatusPill state="connected" />)
    expect(screen.getByText('Agent connected')).toBeInTheDocument()
    rerender(<StatusPill state="disconnected" />)
    expect(screen.getByText('Agent offline')).toBeInTheDocument()
    rerender(<StatusPill state="error" />)
    expect(screen.getByText('Agent error')).toBeInTheDocument()
  })
})

describe('StatCard', () => {
  it('renders the measured value and unit', () => {
    render(<StatCard label="CPU utilisation" value="37.4" unit="%" icon={Cpu} percent={37.4} />)
    expect(screen.getByText('CPU utilisation')).toBeInTheDocument()
    expect(screen.getByText('37.4')).toBeInTheDocument()
    expect(screen.getByText('%')).toBeInTheDocument()
  })

  it('shows a skeleton instead of a value while loading', () => {
    const { container } = render(<StatCard label="Memory" value="—" icon={Cpu} loading />)
    expect(container.querySelector('.skeleton')).not.toBeNull()
    expect(screen.queryByText('—')).toBeNull()
  })
})

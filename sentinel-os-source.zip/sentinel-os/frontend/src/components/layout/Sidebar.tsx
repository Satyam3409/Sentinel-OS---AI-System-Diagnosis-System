import type { LucideIcon } from 'lucide-react'
import {
  Activity,
  BarChart3,
  BrainCircuit,
  ChevronLeft,
  Cpu,
  Gauge,
  Info,
  LayoutDashboard,
  ListTree,
  Settings as SettingsIcon,
  ShieldAlert,
  Sparkles,
} from 'lucide-react'

export interface NavItem {
  id: string
  label: string
  icon: LucideIcon
  group: 'Monitoring' | 'Intelligence' | 'Analysis' | 'System'
  description: string
}

export const NAV_ITEMS: NavItem[] = [
  {
    id: 'overview',
    label: 'Overview',
    icon: LayoutDashboard,
    group: 'Monitoring',
    description: 'Live system health, utilisation and top consumers',
  },
  { id: 'monitor', label: 'Live Monitor', icon: Activity, group: 'Monitoring', description: 'High-resolution metric streams' },
  { id: 'processes', label: 'Process Explorer', icon: ListTree, group: 'Monitoring', description: 'Read-only process inspection' },
  { id: 'doctor', label: 'AI System Doctor', icon: BrainCircuit, group: 'Intelligence', description: 'Gemini-grounded diagnostics with offline fallback' },
  { id: 'anomaly', label: 'Anomaly Detection', icon: ShieldAlert, group: 'Intelligence', description: 'Isolation Forest behaviour scoring' },
  { id: 'recommendations', label: 'Smart Recommendations', icon: Sparkles, group: 'Intelligence', description: 'Evidence-based optimisation guidance' },
  { id: 'history', label: 'Diagnostic History', icon: BarChart3, group: 'Analysis', description: 'Stored alerts, reports and exports' },
  { id: 'lab', label: 'Performance Lab', icon: Gauge, group: 'Analysis', description: 'Bounded, measurable stress experiments' },
  { id: 'settings', label: 'Settings', icon: SettingsIcon, group: 'System', description: 'Monitoring, ML and API configuration' },
  { id: 'about', label: 'About', icon: Info, group: 'System', description: 'Architecture, scope and limitations' },
]

const GROUP_ORDER: NavItem['group'][] = ['Monitoring', 'Intelligence', 'Analysis', 'System']

interface SidebarProps {
  active: string
  onNavigate: (id: string) => void
  collapsed: boolean
  onToggleCollapse: () => void
  agentOnline: boolean
  version: string
}

export function Sidebar({ active, onNavigate, collapsed, onToggleCollapse, agentOnline, version }: SidebarProps) {
  return (
    <aside
      className={`relative z-20 flex h-full shrink-0 flex-col border-r border-panel-border bg-canvas-soft transition-[width] duration-300 ease-sentinel ${
        collapsed ? 'w-[74px]' : 'w-[248px]'
      }`}
    >
      {/* Brand */}
      <div className="flex h-16 items-center gap-3 border-b border-panel-border px-4">
        <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-electric-500/40 bg-electric-600/15 shadow-glow">
          <Cpu className="h-4.5 w-4.5 text-electric-300" style={{ width: 18, height: 18 }} />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <p className="truncate text-sm font-bold tracking-[0.2em] text-white">SENTINEL</p>
            <p className="truncate text-2xs font-medium tracking-[0.32em] text-electric-400">OS</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-2.5 py-4 scrollbar-thin">
        {GROUP_ORDER.map((group) => (
          <div key={group} className="mb-4">
            {!collapsed && <p className="mb-1.5 px-3 text-2xs font-semibold uppercase tracking-[0.2em] text-white/25">{group}</p>}
            <ul className="space-y-1">
              {NAV_ITEMS.filter((item) => item.group === group).map((item) => {
                const Icon = item.icon
                const isActive = active === item.id
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      title={collapsed ? item.label : undefined}
                      onClick={() => onNavigate(item.id)}
                      className={`nav-item ${isActive ? 'nav-item-active' : ''} ${collapsed ? 'justify-center !px-0' : ''}`}
                    >
                      <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-electric-300' : ''}`} />
                      {!collapsed && (
                        <span className="flex-1 truncate text-left">
                          <span className="block truncate">{item.label}</span>
                        </span>
                      )}
                    </button>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-panel-border p-3">
        {!collapsed ? (
          <div className="rounded-lg border border-panel-border bg-panel px-3 py-2.5">
            <div className="flex items-center justify-between">
              <span className="text-2xs font-semibold uppercase tracking-[0.14em] text-white/35">Agent</span>
              <span
                className={`inline-flex items-center gap-1.5 text-2xs font-semibold ${
                  agentOnline ? 'text-alert-ok' : 'text-alert-critical'
                }`}
              >
                <span className={`h-1.5 w-1.5 rounded-full ${agentOnline ? 'bg-alert-ok' : 'bg-alert-critical'}`} />
                {agentOnline ? 'ONLINE' : 'OFFLINE'}
              </span>
            </div>
            <p className="mt-1.5 font-mono text-2xs text-white/30">v{version} · localhost only</p>
          </div>
        ) : (
          <div className="flex justify-center">
            <span className={`h-2 w-2 rounded-full ${agentOnline ? 'bg-alert-ok' : 'bg-alert-critical'}`} />
          </div>
        )}
        <button className="btn mt-2 w-full !px-0" onClick={onToggleCollapse} type="button" title="Toggle sidebar">
          <ChevronLeft className={`h-3.5 w-3.5 transition-transform duration-300 ${collapsed ? 'rotate-180' : ''}`} />
          {!collapsed && <span className="text-2xs">Collapse</span>}
        </button>
      </div>
    </aside>
  )
}

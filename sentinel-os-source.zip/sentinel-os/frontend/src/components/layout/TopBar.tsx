import { CloudOff, ExternalLink, RefreshCw, ShieldCheck, Wifi } from 'lucide-react'
import type { ConnectionState } from '../../types'
import { StatusPill } from '../ui/Primitives'
import { formatClock, formatRelative } from '../../services/format'

interface TopBarProps {
  title: string
  description: string
  connection: ConnectionState
  connectionDetail: string | null
  lastFrameAt: number | null
  agentTicks: number
  sampleInterval: number
  onRefresh: () => void
  refreshing: boolean
  source: 'live' | 'demo'
}

export function TopBar({
  title,
  description,
  connection,
  connectionDetail,
  lastFrameAt,
  agentTicks,
  sampleInterval,
  onRefresh,
  refreshing,
  source,
}: TopBarProps) {
  const secondsSinceFrame = lastFrameAt ? (Date.now() - lastFrameAt) / 1000 : null

  return (
    <header className="sticky top-0 z-30 border-b border-panel-border bg-canvas/85 backdrop-blur-xl">
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="truncate text-lg font-semibold tracking-tight text-white">{title}</h1>
            {source === 'demo' && (
              <span className="inline-flex items-center gap-1 rounded-md border border-alert-warning/45 bg-alert-warning/10 px-2 py-0.5 text-2xs font-semibold uppercase tracking-[0.12em] text-alert-warning">
                <CloudOff className="h-3 w-3" /> Demo mode
              </span>
            )}
          </div>
          <p className="mt-1 max-w-3xl truncate text-xs text-white/45">{description}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="hidden items-center gap-2 rounded-lg border border-panel-border bg-panel-light px-3 py-1.5 lg:flex">
            <Wifi className="h-3.5 w-3.5 text-electric-300" />
            <span className="font-mono text-2xs text-white/50">
              {sampleInterval.toFixed(1)}s interval · {agentTicks} ticks
            </span>
          </div>
          <div className="hidden items-center gap-2 rounded-lg border border-panel-border bg-panel-light px-3 py-1.5 xl:flex">
            <ShieldCheck className="h-3.5 w-3.5 text-alert-ok" />
            <span className="font-mono text-2xs text-white/50">Read-only mode</span>
          </div>
          <StatusPill state={connection} />
          <div className="hidden items-center gap-1.5 rounded-lg border border-panel-border bg-panel-light px-3 py-1.5 sm:flex">
            <span className="text-2xs text-white/35">last frame</span>
            <span className="font-mono text-2xs text-white/60">
              {lastFrameAt ? `${formatClock(lastFrameAt / 1000)} (${formatRelative(lastFrameAt / 1000)})` : '—'}
            </span>
          </div>
          <button className="btn" onClick={onRefresh} disabled={refreshing} type="button">
            <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <a
            className="btn"
            href="http://127.0.0.1:8000/docs"
            target="_blank"
            rel="noreferrer"
            title="Open the FastAPI OpenAPI docs"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            API
          </a>
        </div>
      </div>

      {connection !== 'connected' && (
        <div className="flex items-start gap-2 border-t border-alert-warning/25 bg-alert-warning/8 px-6 py-2.5">
          <CloudOff className="mt-0.5 h-3.5 w-3.5 shrink-0 text-alert-warning" />
          <p className="text-2xs leading-relaxed text-alert-warning/90">
            <span className="font-semibold">Live stream {connection}.</span>{' '}
            {connectionDetail ?? 'The local monitoring agent could not be reached.'}{' '}
            {secondsSinceFrame !== null && `Last frame received ${formatRelative(lastFrameAt! / 1000)}.`} Start it with{' '}
            <code className="rounded bg-black/40 px-1 py-0.5 font-mono">
              cd backend &amp;&amp; .venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
            </code>
            . A cloud preview cannot reach your machine&apos;s localhost — the agent must run locally to read real Windows metrics.
          </p>
        </div>
      )}
    </header>
  )
}

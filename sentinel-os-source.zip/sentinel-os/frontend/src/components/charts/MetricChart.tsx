import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { formatClock } from '../../services/format'

interface SeriesPoint {
  timestamp: number
  [key: string]: number
}

const axisStyle = {
  fontSize: 10,
  fill: 'rgba(255,255,255,0.35)',
  fontFamily: 'JetBrains Mono, Consolas, monospace',
}

function ChartTooltip({
  active,
  payload,
  label,
  unit = '%',
}: {
  active?: boolean
  payload?: Array<{ name?: string; value?: number; color?: string }>
  label?: number
  unit?: string
}) {
  if (!active || !payload || payload.length === 0) return null
  return (
    <div className="rounded-lg border border-panel-border bg-panel/95 px-3 py-2 shadow-panel backdrop-blur">
      <p className="mb-1 font-mono text-2xs text-white/40">{formatClock(label ?? null)}</p>
      {payload
        .filter((entry) => entry.value !== undefined && entry.value !== null)
        .map((entry) => (
          <p key={`${entry.name}`} className="flex items-center gap-2 font-mono text-2xs text-white/80">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: entry.color }} />
            <span className="text-white/50">{entry.name}</span>
            <span className="font-semibold text-white">
              {typeof entry.value === 'number' ? entry.value.toFixed(2) : '—'}
              {unit}
            </span>
          </p>
        ))}
    </div>
  )
}

interface MetricChartProps {
  data: SeriesPoint[]
  series: Array<{ key: string; label: string; color: string }>
  unit?: string
  domain?: [number | string, number | string]
  height?: number
  variant?: 'area' | 'line'
  referenceY?: Array<{ y: number; label: string; color: string }>
  showGrid?: boolean
}

/** Reusable time-series chart. Renders an explicit empty state when no data. */
export function MetricChart({
  data,
  series,
  unit = '%',
  domain = [0, 100],
  height = 220,
  variant = 'area',
  referenceY = [],
  showGrid = true,
}: MetricChartProps) {
  if (!data || data.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-panel-border/70 text-center"
        style={{ height }}
      >
        <p className="text-xs text-white/45">No measurements yet</p>
        <p className="text-2xs text-white/25">
          The chart fills as the monitoring agent reports real samples (one every 2 seconds)
        </p>
      </div>
    )
  }

  const common = (
    <>
      {showGrid && <CartesianGrid stroke="rgba(255,255,255,0.045)" strokeDasharray="2 4" vertical={false} />}
      <XAxis
        dataKey="timestamp"
        tickFormatter={(value: number) => formatClock(value)}
        tick={axisStyle}
        stroke="rgba(255,255,255,0.08)"
        minTickGap={44}
      />
      <YAxis
        domain={domain}
        tick={axisStyle}
        stroke="rgba(255,255,255,0.08)"
        width={38}
        tickFormatter={(value: number) => `${value}${unit}`}
      />
      <Tooltip content={<ChartTooltip unit={unit} />} />
      {referenceY.map((ref) => (
        <ReferenceLine
          key={ref.label}
          y={ref.y}
          stroke={ref.color}
          strokeDasharray="4 4"
          label={{ value: ref.label, fill: ref.color, fontSize: 9, position: 'insideTopRight' }}
        />
      ))}
    </>
  )

  return (
    <ResponsiveContainer width="100%" height={height}>
      {variant === 'area' ? (
        <AreaChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
          <defs>
            {series.map((entry) => (
              <linearGradient key={entry.key} id={`grad-${entry.key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={entry.color} stopOpacity={0.42} />
                <stop offset="100%" stopColor={entry.color} stopOpacity={0.02} />
              </linearGradient>
            ))}
          </defs>
          {common}
          {series.map((entry) => (
            <Area
              key={entry.key}
              type="monotone"
              dataKey={entry.key}
              name={entry.label}
              stroke={entry.color}
              strokeWidth={1.8}
              fill={`url(#grad-${entry.key})`}
              dot={false}
              isAnimationActive={false}
              connectNulls
            />
          ))}
        </AreaChart>
      ) : (
        <LineChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
          {common}
          {series.map((entry) => (
            <Line
              key={entry.key}
              type="monotone"
              dataKey={entry.key}
              name={entry.label}
              stroke={entry.color}
              strokeWidth={1.8}
              dot={false}
              isAnimationActive={false}
              connectNulls
            />
          ))}
        </LineChart>
      )}
    </ResponsiveContainer>
  )
}

interface SparklineProps {
  data: SeriesPoint[]
  dataKey: string
  color: string
  height?: number
}

/** Compact inline sparkline for cards and tables. */
export function Sparkline({ data, dataKey, color, height = 38 }: SparklineProps) {
  if (!data || data.length < 2) {
    return <div className="h-[38px] rounded bg-panel-light/60" style={{ height }} />
  }
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 2, right: 0, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={`spark-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.4} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area
          type="monotone"
          dataKey={dataKey}
          stroke={color}
          strokeWidth={1.4}
          fill={`url(#spark-${dataKey})`}
          dot={false}
          isAnimationActive={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  )
}

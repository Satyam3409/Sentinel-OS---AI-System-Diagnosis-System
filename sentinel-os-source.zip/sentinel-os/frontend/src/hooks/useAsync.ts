/** Generic async data hook with loading / error / empty states. */

import { useCallback, useEffect, useRef, useState } from 'react'
import { ApiError } from '../services/api'

export interface AsyncState<T> {
  data: T | null
  loading: boolean
  error: string | null
  reload: () => Promise<void>
  setData: (value: T | null) => void
}

export function useAsync<T>(
  loader: (signal: AbortSignal) => Promise<T>,
  deps: unknown[] = [],
  options: { pollMs?: number; enabled?: boolean } = {},
): AsyncState<T> {
  const { pollMs, enabled = true } = options
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(enabled)
  const [error, setError] = useState<string | null>(null)
  const loaderRef = useRef(loader)
  loaderRef.current = loader

  const run = useCallback(async () => {
    const controller = new AbortController()
    try {
      const result = await loaderRef.current(controller.signal)
      setData(result)
      setError(null)
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') return
      setError(err instanceof ApiError ? err.detail : (err as Error).message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (!enabled) return
    let cancelled = false
    void (async () => {
      if (!cancelled) await run()
    })()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, run, ...deps])

  useEffect(() => {
    if (!enabled || !pollMs) return
    const timer = window.setInterval(() => void run(), pollMs)
    return () => window.clearInterval(timer)
  }, [enabled, pollMs, run])

  return { data, loading, error, reload: run, setData }
}

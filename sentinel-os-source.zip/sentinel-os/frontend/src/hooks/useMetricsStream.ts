/**
 * Central live-data hook.
 *
 * Owns: REST snapshot fetch (authoritative), WebSocket stream (high-frequency),
 * rolling history buffer, anomaly alerts and connection state.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api, ApiError } from '../services/api'
import { MetricsSocket } from '../services/ws'
import type {
  AgentStatus,
  AnomalyEvent,
  ConnectionState,
  MetricSample,
  SystemSummary,
} from '../types'

interface UseMetricsStreamResult {
  summary: SystemSummary | null
  history: MetricSample[]
  latest: MetricSample | null
  events: AnomalyEvent[]
  agent: AgentStatus | null
  connection: ConnectionState
  connectionDetail: string | null
  loading: boolean
  error: string | null
  refresh: () => Promise<void>
  lastFrameAt: number | null
}

const MAX_POINTS = 180

export function useMetricsStream(pollMs = 15000): UseMetricsStreamResult {
  const [summary, setSummary] = useState<SystemSummary | null>(null)
  const [history, setHistory] = useState<MetricSample[]>([])
  const [latest, setLatest] = useState<MetricSample | null>(null)
  const [events, setEvents] = useState<AnomalyEvent[]>([])
  const [agent, setAgent] = useState<AgentStatus | null>(null)
  const [connection, setConnection] = useState<ConnectionState>('connecting')
  const [connectionDetail, setConnectionDetail] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastFrameAt, setLastFrameAt] = useState<number | null>(null)

  const socketRef = useRef<MetricsSocket | null>(null)

  const refresh = useCallback(async () => {
    try {
      const [snapshot, historyResponse] = await Promise.all([api.summary(), api.history({ limit: MAX_POINTS })])
      setSummary(snapshot)
      setError(null)
      const points = (historyResponse.points ?? []) as unknown as MetricSample[]
      if (points.length > 1 && points[0]?.cpu_percent !== undefined) {
        setHistory(points.slice(-MAX_POINTS))
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.detail : (err as Error).message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void refresh()
    const timer = window.setInterval(() => void refresh(), pollMs)
    return () => window.clearInterval(timer)
  }, [refresh, pollMs])

  useEffect(() => {
    const socket = new MetricsSocket('/ws/metrics')
    socketRef.current = socket

    socket.onState = (state, detail) => {
      setConnection(state)
      setConnectionDetail(detail ?? null)
    }

    socket.onFrame = (frame) => {
      setLastFrameAt(Date.now())
      if (frame.type === 'hello') {
        if (frame.agent) setAgent(frame.agent)
        return
      }
      if (frame.type === 'heartbeat') {
        if (frame.agent) setAgent(frame.agent)
        return
      }
      if (frame.type !== 'metrics') return

      if (frame.agent) setAgent(frame.agent)
      if (frame.sample) {
        const sample = frame.sample
        setLatest(sample)
        setHistory((prev) => {
          const next = [...prev, sample]
          return next.length > MAX_POINTS ? next.slice(next.length - MAX_POINTS) : next
        })
      }
      if (frame.events && frame.events.length > 0) {
        setEvents((prev) => {
          const merged = [...frame.events!, ...prev]
          const seen = new Set<number>()
          return merged
            .filter((event) => {
              if (event.id === null || event.id === undefined) return true
              if (seen.has(event.id)) return false
              seen.add(event.id)
              return true
            })
            .slice(0, 25)
        })
      }
    }

    socket.connect()
    return () => socket.close()
  }, [])

  const mergedHistory = useMemo(() => history.slice(-MAX_POINTS), [history])

  return {
    summary,
    history: mergedHistory,
    latest,
    events,
    agent,
    connection,
    connectionDetail,
    loading,
    error,
    refresh,
    lastFrameAt,
  }
}

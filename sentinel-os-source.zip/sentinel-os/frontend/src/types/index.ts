/**
 * Shared TypeScript contracts mirroring the FastAPI schemas.
 * Every numeric field here originates from a real psutil measurement unless the
 * payload is explicitly flagged as demo data.
 */

export type Severity = 'info' | 'low' | 'medium' | 'high' | 'critical'
export type HealthStatus = 'optimal' | 'good' | 'fair' | 'degraded' | 'critical'
export type AnomalyMode = 'unsupervised-learning' | 'rule-based-cold-start' | 'disabled'
export type Engine = 'gemini' | 'local-fallback'
export type Source = 'live' | 'demo'

export interface CpuMetrics {
  percent: number
  per_core: number[]
  core_count_logical: number
  core_count_physical: number
  frequency_mhz: number | null
  load_avg: number[] | null
}

export interface MemoryMetrics {
  total_mb: number
  used_mb: number
  available_mb: number
  percent: number
  swap_total_mb: number
  swap_used_mb: number
  swap_percent: number
}

export interface DiskPartition {
  device: string
  mountpoint: string
  fstype: string
  total_gb: number
  used_gb: number
  free_gb: number
  percent: number
}

export interface DiskMetrics {
  read_mb_s: number
  write_mb_s: number
  read_mb_total: number
  write_mb_total: number
  partitions: DiskPartition[]
}

export interface NetworkMetrics {
  upload_kb_s: number
  download_kb_s: number
  bytes_sent_mb: number
  bytes_recv_mb: number
  packets_sent: number
  packets_recv: number
}

export interface SystemInfo {
  hostname: string
  platform: string
  platform_release: string
  platform_version: string
  architecture: string
  processor: string
  python_version: string
  boot_time: number
  uptime_seconds: number
  user: string
  is_admin: boolean
}

export interface HealthReport {
  score: number
  status: HealthStatus
  reasons: string[]
  partial_data: boolean
}

/**
 * A single measured metric sample. Declared as a type alias (not an interface)
 * so it is structurally assignable to chart series, which need a numeric index
 * signature to look up an arbitrary series key.
 */
export type MetricSample = {
  timestamp: number
  cpu_percent: number
  memory_percent: number
  swap_percent: number
  disk_read_mb_s: number
  disk_write_mb_s: number
  net_upload_kb_s: number
  net_download_kb_s: number
  process_count: number
}

export interface AgentStatus {
  monitor_running: boolean
  ticks: number
  last_tick: number | null
  started_at: number | null
  sample_interval: number
  history_points: number
  subscribers: number
  server_time: number
  server_time_iso: string
}

export interface SystemSummary {
  source: Source
  timestamp: number
  cpu: CpuMetrics
  memory: MemoryMetrics
  disk: DiskMetrics
  network: NetworkMetrics
  system: SystemInfo
  process_count: number
  health: HealthReport
  agent?: AgentStatus
  data_warnings?: string[]
}

export interface HealthResponse {
  status: string
  service: string
  version: string
  agent: {
    monitoring: boolean
    sample_interval_seconds: number
    samples_collected: number
    ticks: number
    last_tick: number | null
    history_points: number
    websocket_subscribers: number
    last_error: string | null
    warnings: string[]
  }
  database: DatabaseStats
  gemini_configured: boolean
  server_time: number
}

export interface HistoryResponse {
  metric: string
  source?: string
  count: number
  points: Array<Record<string, number>>
  generated_at?: string
}

export interface ProcessInfo {
  pid: number
  name: string
  username: string | null
  status: string | null
  cpu_percent: number
  memory_percent: number
  memory_mb: number
  num_threads: number | null
  create_time: number | null
  exe: string | null
  cmdline: string | null
}

export interface ProcessList {
  timestamp: number
  total: number
  returned: number
  processes: ProcessInfo[]
  skipped?: number
}

export interface ProcessDetail extends ProcessInfo {
  cwd: string | null
  nice: number | null
  connections: number
  open_files: number
  read_only: boolean
  note: string
}

export interface AnomalyEvent {
  id: number | null
  timestamp: number
  detected_at: string
  is_anomaly: boolean
  score: number
  severity: Severity
  metric: string
  observed_value: number
  expected_range: [number, number]
  evidence: string
  explanation: string
  model: string
  acknowledged: number
  features: Record<string, number>
  kind?: string
}

export interface AnomalyStatus {
  enabled: boolean
  model_ready: boolean
  mode: AnomalyMode
  trained_samples: number
  trained_at: string | null
  training_source: string
  sensitivity: number
  contamination: number
  last_score: number | null
  last_severity: Severity | null
  is_anomaly: boolean
  recent_events: AnomalyEvent[]
  features?: string[]
  current_metrics?: Record<string, number>
  last_features?: Record<string, number>
}

export interface Recommendation {
  id: string
  severity: Severity
  trigger: string
  evidence: string
  explanation: string
  suggested_action: string
  risk: string
  verification: string
  read_only: boolean
}

export interface RecommendationResponse {
  timestamp: number
  count: number
  items: Recommendation[]
}

export interface DiagnosticReport {
  id: number | null
  created_at: string
  timestamp: number
  engine: Engine
  model: string | null
  question: string
  summary: string
  evidence: string[]
  possible_causes: string[]
  confidence: number
  recommended_actions: string[]
  safety_considerations: string[]
  degraded: boolean
  notice: string | null
  latency_ms: number
}

export interface DoctorResponse {
  report: DiagnosticReport
  engine: Engine
  gemini_configured: boolean
}

export interface DoctorStatus {
  assistant: string
  engine: Engine
  gemini_configured: boolean
  gemini_model: string | null
  gemini_timeout_seconds: number
  fallback_available: boolean
  suggested_questions: string[]
  safety: Record<string, unknown>
}

export interface ExperimentStatus {
  id: string | null
  kind: string | null
  running: boolean
  started_at: string | null
  started_ts: number | null
  duration_seconds: number
  seconds_remaining: number
  workers: number
  memory_mb: number
  baseline: Record<string, number>
  peak: Record<string, number>
  current: Record<string, number>
  recovery: Record<string, number> | null
  samples: number
  message: string
  limits?: LabLimits
}

export interface LabLimits {
  cpu: {
    max_workers: number
    max_duration_seconds: number
    available_logical_cores: number
  }
  memory: {
    max_memory_mb: number
    configured_max_mb: number
    max_duration_seconds: number
    available_mb: number
  }
}

export interface LabInfo {
  limits: LabLimits
  safety: Record<string, unknown>
  current: ExperimentStatus
}

export interface LabCompare {
  experiment: ExperimentStatus
  baseline: Record<string, number>
  peak: Record<string, number>
  recovery: Record<string, number>
  delta_peak_vs_baseline: Record<string, number>
  recovered: boolean
  note: string
}

export interface ForecastPoint {
  timestamp: number
  value: number
  kind: 'actual' | 'predicted'
}

export interface ForecastSeries {
  metric: string
  unit: string
  horizon: number
  history: ForecastPoint[]
  forecast: ForecastPoint[]
  slope_per_minute: number
  confidence: number
  method: string
  sufficient_data: boolean
  message: string
  error?: { mae: number; rmse: number; mape_percent: number; holdout_samples: number }
}

export interface ForecastResponse {
  generated_at: string
  available_samples: number
  required_samples: number
  series: ForecastSeries[]
}

export interface DatabaseStats {
  anomaly_events: number
  diagnostic_reports: number
  metric_samples: number
  oldest_sample: number | null
  newest_sample: number | null
  db_path: string
  retention_days?: number
}

export interface SettingsResponse {
  settings: {
    sample_interval: number
    sensitivity: number
    retention_days: number
    demo_mode: boolean
  }
  effective: {
    sample_interval_seconds: number
    anomaly_sensitivity: number
    anomaly_enabled: boolean
    retention_days: number
  }
  api_configuration: {
    gemini_configured: boolean
    gemini_model: string
    gemini_env_var: string
    api_key_exposure: string
    how_to_enable: string[]
  }
  server: {
    host: string
    port: number
    allowed_origins: string[]
    data_dir: string
  }
  can_apply_at_runtime: Record<string, unknown>
}

export interface AboutResponse {
  application: string
  full_name: string
  version: string
  purpose: string
  category: string
  target_os: string
  host_platform: string
  architecture: Record<string, string[]>
  capabilities: string[]
  limitations: string[]
  disclaimer: string
  status: Record<string, unknown>
}

export interface HistoryListItem {
  kind: 'anomaly' | 'report'
  id: number
  timestamp: number
  detected_at?: string
  created_at?: string
  severity: Severity
  metric?: string
  observed_value?: number
  expected_range?: [number, number]
  score?: number
  evidence?: string
  explanation?: string
  model?: string
  acknowledged?: number
  engine?: Engine
  question?: string
  summary?: string
  confidence?: number
}

export interface HistoryList {
  total: number
  limit: number
  offset: number
  items: HistoryListItem[]
}

export interface WsMetricsFrame {
  type: 'metrics' | 'hello' | 'heartbeat'
  timestamp?: number
  sample?: MetricSample
  summary?: {
    source: Source
    timestamp: number
    cpu_percent: number
    memory_percent: number
    swap_percent: number
    process_count: number
    uptime_seconds: number
  } | null
  anomaly?: {
    is_anomaly: boolean
    score: number
    severity: Severity
    metric: string
    explanation: string
  }
  experiment?: ExperimentStatus | null
  events?: AnomalyEvent[]
  ticks?: number
  message?: string
  sample_interval?: number
  agent?: AgentStatus
  note?: string
}

export type ConnectionState = 'connecting' | 'connected' | 'disconnected' | 'error'

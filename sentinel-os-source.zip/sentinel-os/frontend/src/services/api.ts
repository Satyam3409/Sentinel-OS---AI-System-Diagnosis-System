/**
 * REST client for the local SENTINEL OS monitoring agent.
 *
 * The agent runs on the same machine as the browser (127.0.0.1:8000). In dev the
 * Vite proxy forwards /api to it, so relative URLs always work. A remote/cloud
 * preview cannot reach the user's localhost - the UI surfaces that explicitly.
 */

import type {
  AboutResponse,
  AnomalyEvent,
  AnomalyStatus,
  DatabaseStats,
  DoctorResponse,
  DoctorStatus,
  ExperimentStatus,
  ForecastResponse,
  HealthResponse,
  HistoryList,
  HistoryResponse,
  LabCompare,
  LabInfo,
  ProcessDetail,
  ProcessList,
  RecommendationResponse,
  SettingsResponse,
  SystemSummary,
} from '../types'

export const API_BASE = import.meta.env.VITE_API_BASE ?? '/api'

export class ApiError extends Error {
  status: number
  detail: string

  constructor(status: number, detail: string) {
    super(detail)
    this.name = 'ApiError'
    this.status = status
    this.detail = detail
  }
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  body?: unknown
  signal?: AbortSignal
  timeoutMs?: number
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, signal, timeoutMs = 15000 } = options
  const controller = new AbortController()
  const timer = window.setTimeout(() => controller.abort(), timeoutMs)
  if (signal) {
    signal.addEventListener('abort', () => controller.abort(), { once: true })
  }

  try {
    const response = await fetch(`${API_BASE}${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    })

    if (!response.ok) {
      let detail = `${response.status} ${response.statusText}`
      try {
        const payload = await response.json()
        if (payload?.detail) {
          detail = typeof payload.detail === 'string' ? payload.detail : JSON.stringify(payload.detail)
        }
      } catch {
        /* keep the status text */
      }
      throw new ApiError(response.status, detail)
    }

    if (response.status === 204) {
      return undefined as T
    }
    return (await response.json()) as T
  } catch (error) {
    if (error instanceof ApiError) throw error
    if ((error as Error)?.name === 'AbortError') {
      throw new ApiError(408, 'The monitoring agent did not respond in time. Is it running on 127.0.0.1:8000?')
    }
    throw new ApiError(
      0,
      'Cannot reach the local monitoring agent. Start it with: cd backend && .venv\\Scripts\\python -m uvicorn app.main:app --host 127.0.0.1 --port 8000',
    )
  } finally {
    window.clearTimeout(timer)
  }
}

export const api = {
  // -- meta ---------------------------------------------------------------
  health: (signal?: AbortSignal) => request<HealthResponse>('/health', { signal }),
  about: (signal?: AbortSignal) => request<AboutResponse>('/about', { signal }),

  // -- system -------------------------------------------------------------
  summary: (signal?: AbortSignal) => request<SystemSummary>('/system/summary', { signal }),
  history: (params: { limit?: number; metric?: string; source?: 'memory' | 'database' } = {}, signal?: AbortSignal) => {
    const query = new URLSearchParams()
    if (params.limit) query.set('limit', String(params.limit))
    if (params.metric) query.set('metric', params.metric)
    if (params.source) query.set('source', params.source)
    return request<HistoryResponse>(`/system/history?${query.toString()}`, { signal })
  },
  disks: (signal?: AbortSignal) => request<Partial<SystemSummary['disk']>>('/system/disks', { signal }),
  network: (signal?: AbortSignal) => request<SystemSummary['network']>('/system/network', { signal }),
  systemInfo: (signal?: AbortSignal) => request<SystemSummary['system']>('/system/info', { signal }),
  top: (by: 'cpu' | 'memory' = 'cpu', limit = 5, signal?: AbortSignal) =>
    request<{ by: string; items: ProcessList['processes'] }>(`/system/top?by=${by}&limit=${limit}`, { signal }),

  // -- processes ----------------------------------------------------------
  processes: (
    params: { limit?: number; sort?: 'cpu' | 'memory' | 'name' | 'pid'; search?: string; status?: string } = {},
    signal?: AbortSignal,
  ) => {
    const query = new URLSearchParams()
    query.set('limit', String(params.limit ?? 200))
    query.set('sort', params.sort ?? 'cpu')
    if (params.search) query.set('search', params.search)
    if (params.status && params.status !== 'all') query.set('status', params.status)
    return request<ProcessList>(`/processes?${query.toString()}`, { signal })
  },
  process: (pid: number, signal?: AbortSignal) => request<ProcessDetail>(`/processes/${pid}`, { signal }),

  // -- anomaly ------------------------------------------------------------
  anomalyStatus: (limit = 10, signal?: AbortSignal) => request<AnomalyStatus>(`/anomaly/status?limit=${limit}`, { signal }),
  anomalyEvents: (
    params: { limit?: number; offset?: number; severity?: string; search?: string; only_anomalies?: boolean } = {},
    signal?: AbortSignal,
  ) => {
    const query = new URLSearchParams()
    query.set('limit', String(params.limit ?? 50))
    query.set('offset', String(params.offset ?? 0))
    if (params.severity && params.severity !== 'all') query.set('severity', params.severity)
    if (params.search) query.set('search', params.search)
    if (params.only_anomalies) query.set('only_anomalies', 'true')
    return request<{ total: number; limit: number; offset: number; items: AnomalyEvent[] }>(
      `/anomaly/events?${query.toString()}`,
      { signal },
    )
  },
  acknowledgeAnomaly: (id: number, acknowledged = true) =>
    request<{ id: number; acknowledged: boolean }>(`/anomaly/events/${id}/acknowledge?acknowledged=${acknowledged}`, {
      method: 'POST',
    }),
  deleteAnomaly: (id: number) => request<{ id: number; deleted: boolean }>(`/anomaly/events/${id}`, { method: 'DELETE' }),
  trainAnomaly: () => request<Record<string, unknown>>('/anomaly/train', { method: 'POST', timeoutMs: 60000 }),
  setSensitivity: (value: number) => request<Record<string, number>>('/anomaly/sensitivity', { method: 'POST', body: { value } }),
  setAnomalyEnabled: (enabled: boolean) => request<{ enabled: boolean }>('/anomaly/enabled', { method: 'POST', body: { enabled } }),
  evaluateAnomaly: () => request<AnomalyEvent>('/anomaly/evaluate', { method: 'POST' }),

  // -- AI doctor ----------------------------------------------------------
  doctorStatus: (signal?: AbortSignal) => request<DoctorStatus>('/ai/status', { signal }),
  askDoctor: (question: string, includeHistory = true) =>
    request<DoctorResponse>('/ai/doctor', {
      method: 'POST',
      body: { question, include_history: includeHistory },
      timeoutMs: 45000,
    }),
  quickDiagnosis: (kind: 'full' | 'cpu' | 'memory' | 'disk' | 'process' = 'full') =>
    request<{ report: DoctorResponse['report']; engine: string }>(`/ai/diagnose/quick?kind=${kind}`, { method: 'POST' }),
  reports: (limit = 25, signal?: AbortSignal) =>
    request<{ total: number; items: DoctorResponse['report'][] }>(`/ai/reports?limit=${limit}`, { signal }),

  // -- recommendations ----------------------------------------------------
  recommendations: (signal?: AbortSignal) => request<RecommendationResponse>('/recommendations', { signal }),

  // -- history ------------------------------------------------------------
  historyEvents: (
    params: { kind?: string; limit?: number; offset?: number; severity?: string; search?: string; range?: string } = {},
    signal?: AbortSignal,
  ) => {
    const query = new URLSearchParams()
    query.set('kind', params.kind ?? 'all')
    query.set('limit', String(params.limit ?? 50))
    query.set('offset', String(params.offset ?? 0))
    if (params.severity && params.severity !== 'all') query.set('severity', params.severity)
    if (params.search) query.set('search', params.search)
    if (params.range) query.set('range', params.range)
    return request<HistoryList>(`/history/events?${query.toString()}`, { signal })
  },
  historyStats: (signal?: AbortSignal) => request<DatabaseStats>('/history/stats', { signal }),
  exportUrl: (format: 'json' | 'csv', kind = 'all', range = 'all') =>
    `${API_BASE}/history/export?format=${format}&kind=${kind}&range=${range}`,
  clearHistory: (table: 'all' | 'anomaly_events' | 'diagnostic_reports' | 'metric_samples' = 'all') =>
    request<{ cleared: Record<string, number> }>(`/history/clear?table=${table}&confirm=true`, { method: 'DELETE' }),
  applyRetention: (days: number) => request<Record<string, unknown>>(`/history/retention?retention_days=${days}`, { method: 'POST' }),

  // -- performance lab ----------------------------------------------------
  labInfo: (signal?: AbortSignal) => request<LabInfo>('/lab/limits', { signal }),
  labStatus: (signal?: AbortSignal) => request<ExperimentStatus>('/lab/status', { signal }),
  startExperiment: (payload: {
    kind: 'cpu' | 'memory'
    workers: number
    duration_seconds: number
    memory_mb: number
    confirmed: boolean
  }) => request<ExperimentStatus>('/lab/start', { method: 'POST', body: payload }),
  stopExperiment: () => request<ExperimentStatus>('/lab/stop', { method: 'POST' }),
  labCompare: (signal?: AbortSignal) => request<LabCompare>('/lab/compare', { signal }),
  labCleanup: () => request<Record<string, unknown>>('/lab/cleanup', { method: 'POST' }),

  // -- forecast -----------------------------------------------------------
  forecast: (horizon = 10, source: 'database' | 'memory' = 'database', signal?: AbortSignal) =>
    request<ForecastResponse>(`/forecast?horizon=${horizon}&source=${source}`, { signal, timeoutMs: 20000 }),

  // -- settings -----------------------------------------------------------
  settings: (signal?: AbortSignal) => request<SettingsResponse>('/settings', { signal }),
  updateSettings: (payload: { sample_interval: number; sensitivity: number; retention_days: number; data_source: 'live' | 'demo' }) =>
    request<SettingsResponse>('/settings', { method: 'PUT', body: payload }),
}

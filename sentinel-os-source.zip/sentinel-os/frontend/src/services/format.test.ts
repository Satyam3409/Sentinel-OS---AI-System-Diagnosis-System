import { describe, expect, it } from 'vitest'
import {
  formatBytesMB,
  formatPercent,
  formatUptime,
  metricLabel,
  metricUnit,
  severityBadgeClass,
  truncate,
} from './format'

describe('format helpers', () => {
  it('renders an em dash for missing numbers instead of fabricating a value', () => {
    expect(formatPercent(null)).toBe('—')
    expect(formatPercent(undefined)).toBe('—')
    expect(formatPercent(Number.NaN)).toBe('—')
    expect(formatBytesMB(null)).toBe('—')
  })

  it('formats percentages to one decimal by default', () => {
    expect(formatPercent(42.456)).toBe('42.5%')
    expect(formatPercent(0)).toBe('0.0%')
  })

  it('switches from MB to GB above 1024 MB', () => {
    expect(formatBytesMB(512)).toBe('512 MB')
    expect(formatBytesMB(2048)).toBe('2.00 GB')
  })

  it('formats uptime in a human readable form', () => {
    expect(formatUptime(45)).toBe('45s')
    expect(formatUptime(3700)).toBe('1h 1m 40s')
    expect(formatUptime(90000)).toBe('1d 1h 0m')
    expect(formatUptime(0)).toBe('—')
  })

  it('maps ML feature names to human labels and units', () => {
    expect(metricLabel('cpu_percent')).toBe('CPU utilisation')
    expect(metricLabel('unknown_metric')).toBe('unknown_metric')
    expect(metricUnit('disk_write_mb_s')).toBe('MB/s')
    expect(metricUnit('process_count')).toBe('')
  })

  it('returns a severity class per level', () => {
    expect(severityBadgeClass('critical')).toContain('alert-critical')
    expect(severityBadgeClass('medium')).toContain('alert-warning')
    expect(severityBadgeClass('nonsense')).toContain('panel-border')
  })

  it('truncates long strings', () => {
    const long = 'x'.repeat(200)
    expect(truncate(long, 10).length).toBe(10)
    expect(truncate('short', 10)).toBe('short')
  })
})

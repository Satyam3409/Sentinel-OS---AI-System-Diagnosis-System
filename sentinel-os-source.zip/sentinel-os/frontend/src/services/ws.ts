/**
 * Robust, self-healing WebSocket client for the live metrics stream.
 *
 * Behaviour:
 *  - exponential backoff reconnect with jitter
 *  - explicit connection state so the UI can show connected / disconnected
 *  - keeps the newest frame so consumers always read fresh data
 */

import type { ConnectionState, WsMetricsFrame } from '../types'

type FrameHandler = (frame: WsMetricsFrame) => void
type StateHandler = (state: ConnectionState, detail?: string) => void

function wsUrl(path: string): string {
  const base = import.meta.env.VITE_WS_BASE as string | undefined
  if (base) return `${base}${path}`
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  // In dev, Vite proxies /ws to the local agent; in production the API process
  // serves the SPA and the socket from the same origin.
  return `${protocol}//${window.location.host}${path}`
}

export class MetricsSocket {
  private socket: WebSocket | null = null
  private attempt = 0
  private closedByUser = false
  private reconnectTimer: number | null = null
  private heartbeatTimer: number | null = null
  private readonly path: string

  constructor(path = '/ws/metrics') {
    this.path = path
  }

  onFrame: FrameHandler = () => {}
  onState: StateHandler = () => {}

  connect(): void {
    this.closedByUser = false
    this.onState(this.attempt === 0 ? 'connecting' : 'connecting')
    try {
      this.socket = new WebSocket(wsUrl(this.path))
    } catch (error) {
      this.onState('error', (error as Error).message)
      this.scheduleReconnect()
      return
    }

    this.socket.onopen = () => {
      this.attempt = 0
      this.onState('connected')
      this.startHeartbeatWatch()
    }

    this.socket.onmessage = (event) => {
      try {
        const frame = JSON.parse(event.data as string) as WsMetricsFrame
        this.onFrame(frame)
      } catch {
        /* ignore malformed frames */
      }
    }

    this.socket.onerror = () => {
      this.onState('error', 'WebSocket error - is the local monitoring agent running?')
    }

    this.socket.onclose = (event) => {
      this.stopHeartbeatWatch()
      this.socket = null
      if (this.closedByUser) {
        this.onState('disconnected')
        return
      }
      this.onState('disconnected', event.reason || `closed with code ${event.code}`)
      this.scheduleReconnect()
    }
  }

  private scheduleReconnect(): void {
    if (this.closedByUser) return
    this.attempt += 1
    const base = Math.min(1000 * 2 ** (this.attempt - 1), 15000)
    const delay = base + Math.random() * 400
    if (this.reconnectTimer) window.clearTimeout(this.reconnectTimer)
    this.reconnectTimer = window.setTimeout(() => this.connect(), delay)
  }

  private startHeartbeatWatch(): void {
    this.stopHeartbeatWatch()
    this.heartbeatTimer = window.setInterval(() => {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        try {
          this.socket.send('ping')
        } catch {
          /* ignore */
        }
      }
    }, 20000)
  }

  private stopHeartbeatWatch(): void {
    if (this.heartbeatTimer) {
      window.clearInterval(this.heartbeatTimer)
      this.heartbeatTimer = null
    }
  }

  close(): void {
    this.closedByUser = true
    if (this.reconnectTimer) window.clearTimeout(this.reconnectTimer)
    this.stopHeartbeatWatch()
    this.socket?.close()
    this.socket = null
  }
}

/** Small utility used by the Process Explorer to poll the agent. */
export function createPollingSubscription(
  loader: () => Promise<void>,
  intervalMs: number,
): { start: () => void; stop: () => void } {
  let timer: number | null = null
  let running = false

  const tick = async () => {
    if (!running) return
    try {
      await loader()
    } catch {
      /* callers surface their own errors */
    }
  }

  return {
    start() {
      if (running) return
      running = true
      void tick()
      timer = window.setInterval(tick, intervalMs)
    },
    stop() {
      running = false
      if (timer) window.clearInterval(timer)
      timer = null
    },
  }
}

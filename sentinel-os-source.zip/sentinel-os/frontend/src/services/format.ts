/** Formatting helpers shared by every view. */

export function formatPercent(value: number | null | undefined, digits = 1): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—'
  return `${value.toFixed(digits)}%`
}

export function formatNumber(value: number | null | undefined, digits = 1): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—'
  return value.toLocaleString(undefined, { minimumFractionDigits: digits, maximumFractionDigits: digits })
}

export function formatBytesMB(mb: number | null | undefined, digits = 0): string {
  if (mb === null || mb === undefined || Number.isNaN(mb)) return '—'
  if (mb >= 1024) return `${(mb / 1024).toFixed(digits === 0 ? 2 : digits)} GB`
  return `${mb.toFixed(digits)} MB`
}

export function formatGb(gb: number | null | undefined): string {
  if (gb === null || gb === undefined || Number.isNaN(gb)) return '—'
  return `${gb.toFixed(1)} GB`
}

export function formatUptime(seconds: number | null | undefined): string {
  if (!seconds || seconds < 0) return '—'
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = Math.floor(seconds % 60)
  if (days > 0) return `${days}d ${hours}h ${minutes}m`
  if (hours > 0) return `${hours}h ${minutes}m ${secs}s`
  if (minutes > 0) return `${minutes}m ${secs}s`
  return `${secs}s`
}

export function formatClock(ts: number | null | undefined): string {
  if (!ts) return '—'
  return new Date(ts * 1000).toLocaleTimeString(undefined, { hour12: false })
}

export function formatDateTime(ts: number | null | undefined): string {
  if (!ts) return '—'
  return new Date(ts * 1000).toLocaleString(undefined, { hour12: false })
}

export function formatRelative(ts: number | null | undefined): string {
  if (!ts) return '—'
  const delta = Date.now() / 1000 - ts
  if (delta < 5) return 'just now'
  if (delta < 60) return `${Math.floor(delta)}s ago`
  if (delta < 3600) return `${Math.floor(delta / 60)}m ago`
  if (delta < 86400) return `${Math.floor(delta / 3600)}h ago`
  return `${Math.floor(delta / 86400)}d ago`
}

export function severityColor(severity: string): string {
  switch (severity) {
    case 'critical':
      return 'text-alert-critical'
    case 'high':
      return 'text-alert-critical/90'
    case 'medium':
      return 'text-alert-warning'
    case 'low':
      return 'text-electric-300'
    default:
      return 'text-white/50'
  }
}

export function severityBadgeClass(severity: string): string {
  switch (severity) {
    case 'critical':
      return 'border-alert-critical/45 bg-alert-critical/12 text-alert-critical'
    case 'high':
      return 'border-alert-critical/35 bg-alert-critical/8 text-alert-critical/90'
    case 'medium':
      return 'border-alert-warning/40 bg-alert-warning/10 text-alert-warning'
    case 'low':
      return 'border-electric-400/35 bg-electric-500/10 text-electric-200'
    default:
      return 'border-panel-border bg-panel-light text-white/50'
  }
}

export function healthColor(status: string): string {
  switch (status) {
    case 'optimal':
      return 'text-alert-ok'
    case 'good':
      return 'text-electric-300'
    case 'fair':
      return 'text-alert-warning'
    case 'degraded':
    case 'critical':
      return 'text-alert-critical'
    default:
      return 'text-white/60'
  }
}

export function healthStroke(status: string): string {
  switch (status) {
    case 'optimal':
      return '#22d39a'
    case 'good':
      return '#2f8cff'
    case 'fair':
      return '#ffb020'
    case 'degraded':
      return '#ff7a45'
    case 'critical':
      return '#ff3b47'
    default:
      return '#6b7280'
  }
}

export function metricLabel(metric: string): string {
  const map: Record<string, string> = {
    cpu_percent: 'CPU utilisation',
    memory_percent: 'Memory utilisation',
    swap_percent: 'Swap utilisation',
    disk_read_mb_s: 'Disk read throughput',
    disk_write_mb_s: 'Disk write throughput',
    process_count: 'Process count',
    cpu_delta: 'CPU change rate',
  }
  return map[metric] ?? metric
}

export function metricUnit(metric: string): string {
  const map: Record<string, string> = {
    cpu_percent: '%',
    memory_percent: '%',
    swap_percent: '%',
    disk_read_mb_s: 'MB/s',
    disk_write_mb_s: 'MB/s',
    process_count: '',
    cpu_delta: '%',
  }
  return map[metric] ?? ''
}

export function truncate(value: string, max = 64): string {
  if (value.length <= max) return value
  return `${value.slice(0, max - 1)}…`
}

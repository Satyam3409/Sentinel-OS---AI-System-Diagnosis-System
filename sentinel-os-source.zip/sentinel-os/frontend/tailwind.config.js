/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // SENTINEL OS palette: deep black canvas, charcoal panels, electric blue.
        canvas: {
          DEFAULT: '#05070a',
          soft: '#080b11',
        },
        panel: {
          DEFAULT: '#0d1117',
          light: '#121821',
          border: '#1c2430',
          hover: '#161d27',
        },
        electric: {
          50: '#eaf4ff',
          100: '#cfe6ff',
          200: '#9fcbff',
          300: '#63a9ff',
          400: '#2f8cff',
          500: '#0a6cff',
          600: '#0053d6',
          700: '#0040a8',
          800: '#052f76',
          900: '#071f4a',
        },
        alert: {
          critical: '#ff3b47',
          warning: '#ffb020',
          ok: '#22d39a',
          info: '#38bdf8',
        },
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Consolas', 'SFMono-Regular', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      // The palette relies on fine-grained alpha for glass panels and severity
      // tints. Tailwind's default scale only ships multiples of 5, so the few
      // intermediate steps used by the design are added explicitly.
      opacity: {
        8: '0.08',
        12: '0.12',
        16: '0.16',
      },
      boxShadow: {
        panel: '0 1px 0 0 rgba(255,255,255,0.03) inset, 0 12px 32px -18px rgba(0,0,0,0.9)',
        glow: '0 0 0 1px rgba(10,108,255,0.35), 0 0 24px -6px rgba(10,108,255,0.45)',
        'glow-critical': '0 0 0 1px rgba(255,59,71,0.4), 0 0 24px -6px rgba(255,59,71,0.5)',
      },
      backgroundImage: {
        'grid-faint':
          'linear-gradient(rgba(255,255,255,0.022) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.022) 1px, transparent 1px)',
        'panel-sheen':
          'linear-gradient(160deg, rgba(255,255,255,0.035) 0%, rgba(255,255,255,0) 42%)',
      },
      backgroundSize: {
        grid: '34px 34px',
      },
      keyframes: {
        'pulse-ring': {
          '0%': { opacity: '0.85', transform: 'scale(0.85)' },
          '70%': { opacity: '0', transform: 'scale(1.7)' },
          '100%': { opacity: '0', transform: 'scale(1.7)' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-420px 0' },
          '100%': { backgroundPosition: '420px 0' },
        },
      },
      animation: {
        'pulse-ring': 'pulse-ring 2.2s cubic-bezier(0.24, 0.6, 0.35, 1) infinite',
        'slide-up': 'slide-up 260ms ease-out both',
        shimmer: 'shimmer 1.5s linear infinite',
      },
      transitionTimingFunction: {
        sentinel: 'cubic-bezier(0.22, 0.61, 0.36, 1)',
      },
    },
  },
  plugins: [],
}
